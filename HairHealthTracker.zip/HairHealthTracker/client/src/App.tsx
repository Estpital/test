import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import HairAnalysisForm from "@/pages/HairAnalysisForm";
import AnalysisResults from "@/pages/AnalysisResults";
import HairTransplant from "@/pages/HairTransplant";
import FaceLift from "@/pages/FaceLift";
import Shop from "@/pages/Shop";
import Checkout from "@/pages/Checkout";
import PaymentSuccess from "@/pages/PaymentSuccess";
import MainNavbar from "@/components/MainNavbar";
import Footer from "@/components/Footer";

// Yeni Prosedür Sayfaları
import FaceLiftPage from "@/pages/procedures/FaceLiftPage";
import MiniFaceLiftPage from "@/pages/procedures/MiniFaceLiftPage";
import BlepharoplastyPage from "@/pages/procedures/BlepharoplastyPage";
import RhinoplastyPage from "@/pages/procedures/RhinoplastyPage";
import LipLiftPage from "@/pages/procedures/LipLiftPage";
import HairTransplantDetailPage from "@/pages/procedures/HairTransplantDetailPage";
import LipodemTreatmentPage from "@/pages/procedures/LipodemTreatmentPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage}/>
      <Route path="/analysis" component={HairAnalysisForm}/>
      <Route path="/results/:id" component={AnalysisResults}/>
      <Route path="/hair-transplant" component={HairTransplant}/>
      <Route path="/services/hair-transplant" component={HairTransplant}/>
      <Route path="/face-lift" component={FaceLift}/>
      <Route path="/services/face-lift" component={FaceLift}/>
      <Route path="/shop" component={Shop}/>
      <Route path="/checkout" component={Checkout}/>
      <Route path="/payment-success" component={PaymentSuccess}/>
      
      {/* Prosedür Sayfaları */}
      <Route path="/procedures/facelift" component={FaceLiftPage}/>
      <Route path="/procedures/mini-facelift" component={MiniFaceLiftPage}/>
      <Route path="/procedures/blepharoplasty" component={BlepharoplastyPage}/>
      <Route path="/procedures/rhinoplasty" component={RhinoplastyPage}/>
      <Route path="/procedures/liplift" component={LipLiftPage}/>
      <Route path="/procedures/hair-transplant" component={HairTransplantDetailPage}/>
      <Route path="/procedures/lipodem-treatment" component={LipodemTreatmentPage}/>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <MainNavbar />
        <main className="min-h-[calc(100vh-64px-300px)]">
          <Router />
        </main>
        <Footer />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
