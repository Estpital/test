import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

export interface DoctorsSectionProps {
  id?: string;
}

const doctors = [
  {
    id: 1,
    name: "Doç. Dr. Ummahan Özaslan",
    speciality: "Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı",
    image: "/assets/doctors/dr-ummahan-ozaslan.jpg",
    education: "İstanbul Üniversitesi Tıp Fakültesi",
    experience: "15 yıl",
    procedures: ["Yüz Germe", "Göz Kapağı Estetiği", "Burun Estetiği", "Dudak Kaldırma"]
  },
  {
    id: 2,
    name: "Dr. Gizem Kağıtçı",
    speciality: "Saç Ekimi ve Saç Estetiği Uzmanı",
    image: "/assets/doctors/dr-gizem-kagitci.jpg",
    education: "Ankara Üniversitesi Tıp Fakültesi",
    experience: "12 yıl",
    procedures: ["DHI Saç Ekimi", "FUE Saç Ekimi", "Saç Mezoterapisi", "PRP Tedavisi"]
  }
];

export default function DoctorsSection({ id }: DoctorsSectionProps) {
  return (
    <section id={id} className="py-16 px-4 bg-gray-50">
      <div className="container mx-auto">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">Uzman Ekibimiz</h2>
          <p className="text-lg text-gray-600">
            Alanında uzman ve deneyimli doktorlarımızla size en iyi hizmeti sunuyoruz.
            Doktorlarımız, uluslararası eğitim almış ve en son teknikleri uygulayan profesyonellerdir.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {doctors.map((doctor) => (
            <div 
              key={doctor.id} 
              className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden"
            >
              <div className="h-64 bg-blue-50 flex items-center justify-center">
                <Avatar className="h-40 w-40">
                  <AvatarImage src={doctor.image} alt={doctor.name} />
                  <AvatarFallback>{doctor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">{doctor.name}</h3>
                <p className="text-blue-600 mb-3">{doctor.speciality}</p>
                <div className="mb-4">
                  <p className="text-gray-600 text-sm"><strong>Eğitim:</strong> {doctor.education}</p>
                  <p className="text-gray-600 text-sm"><strong>Deneyim:</strong> {doctor.experience}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {doctor.procedures.map((procedure, index) => (
                    <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {procedure}
                    </Badge>
                  ))}
                </div>
                <button className="mt-4 text-blue-600 hover:text-blue-800 font-medium flex items-center">
                  Profili Görüntüle
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-5 w-5 ml-1" 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md hover:shadow-lg transition-all">
            Tüm Doktorlarımızı Görüntüle
          </button>
        </div>
      </div>
    </section>
  );
}