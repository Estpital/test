import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";

export interface FAQSectionProps {
  id?: string;
}

const faqs = [
  {
    id: 1,
    question: "Estetik operasyonlar öncesi konsültasyon gerekli midir?",
    answer: "Evet, tüm estetik operasyonlar öncesinde uzman doktorlarımızla bir konsültasyon görüşmesi yapılması gerekmektedir. Bu görüşmede beklentileriniz, sağlık durumunuz ve size uygun tedavi seçenekleri detaylı olarak değerlendirilir."
  },
  {
    id: 2,
    question: "Operasyonlardan sonra ne kadar dinlenme süresi gerekiyor?",
    answer: "Dinlenme süresi, yapılan operasyonun türüne ve kapsamına göre değişiklik gösterir. Bazı minimal invaziv işlemler sonrası günlük aktivitelere hemen dönülebilirken, daha kapsamlı operasyonlar için 1-2 haftalık bir dinlenme süreci gerekebilir. Her hastaya özel iyileşme süreci doktorunuz tarafından belirlenecektir."
  },
  {
    id: 3,
    question: "Estetik operasyonların riskleri nelerdir?",
    answer: "Her cerrahi operasyonda olduğu gibi estetik operasyonlarda da belirli riskler mevcuttur. Ancak deneyimli doktorlarımız ve modern teknolojilerimiz sayesinde bu riskler minimuma indirilmektedir. Operasyon öncesi konsültasyon sırasında tüm potansiyel riskler detaylı olarak sizinle paylaşılacaktır."
  },
  {
    id: 4,
    question: "Operasyonların sonuçları kalıcı mıdır?",
    answer: "Çoğu estetik operasyon kalıcı sonuçlar sunar, ancak doğal yaşlanma süreci devam edeceğinden, zamanla bazı değişiklikler olabilir. Sonuçların kalıcılığı, operasyonun türüne, kişisel bakımınıza ve yaşam tarzınıza da bağlıdır. Doktorunuz size özel bakım önerileri sunacaktır."
  },
  {
    id: 5,
    question: "Operasyonlar için ödeme seçenekleri nelerdir?",
    answer: "Hastalarımıza nakit, kredi kartı ve taksit seçenekleri sunuyoruz. Ayrıca, belirli operasyonlar için finansal destek planlarımız da bulunmaktadır. Detaylı bilgi için hasta danışmanlarımızla görüşebilirsiniz."
  },
  {
    id: 6,
    question: "Yurtdışından gelen hastalar için konaklama imkanı var mı?",
    answer: "Evet, yurtdışından gelen hastalarımız için anlaşmalı otellerimiz ve transfer hizmetlerimiz bulunmaktadır. Medikal turizm ekibimiz, konaklama, transfer ve tercüme hizmetleri konusunda size yardımcı olacaktır."
  },
  {
    id: 7,
    question: "Operasyon sonrası kontroller nasıl yapılıyor?",
    answer: "Operasyon sonrası takip süreci her hasta için özel olarak planlanır. İlk kontroller genellikle operasyondan sonraki ilk hafta içinde gerçekleştirilir. Uzun vadeli takip için ise belirli aralıklarla kontroller planlanır. Yurtdışında yaşayan hastalarımız için online kontrol seçeneğimiz de bulunmaktadır."
  },
  {
    id: 8,
    question: "Hangi yaştan itibaren estetik operasyonlar yaptırılabilir?",
    answer: "Estetik operasyonlar için ideal yaş, operasyonun türüne ve kişinin fiziksel gelişimine bağlıdır. Bazı operasyonlar 18 yaşından sonra, bazıları ise vücut gelişiminin tamamlandığı 21 yaşından sonra önerilmektedir. Her durumda, doktorlarımız kişisel değerlendirme yaparak en uygun zamanlamayı belirleyecektir."
  }
];

export default function FAQSection({ id }: FAQSectionProps) {
  return (
    <section id={id} className="py-16 px-4 bg-gray-50">
      <div className="container mx-auto">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">Sık Sorulan Sorular</h2>
          <p className="text-lg text-gray-600">
            Estetik operasyonlar hakkında merak edilen soruların cevaplarını burada bulabilirsiniz.
            Daha fazla bilgi için bizimle iletişime geçmekten çekinmeyin.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq) => (
              <AccordionItem 
                key={faq.id} 
                value={`item-${faq.id}`}
                className="bg-white rounded-lg shadow-md"
              >
                <AccordionTrigger className="px-6 py-4 text-left font-medium hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 pt-2 text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">
              Başka sorularınız mı var? Uzmanlarımıza danışın.
            </p>
            <a 
              href="#contact" 
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md hover:shadow-lg transition-all inline-block"
            >
              Bize Ulaşın
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}