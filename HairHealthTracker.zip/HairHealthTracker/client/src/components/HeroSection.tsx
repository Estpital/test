import { Button } from "@/components/ui/button";

interface HeroSectionProps {
  onStartAnalysis: () => void;
}

export default function HeroSection({ onStartAnalysis }: HeroSectionProps) {
  return (
    <section className="relative bg-gradient-to-br from-blue-50 to-purple-50 py-20 md:py-28 overflow-hidden">
      {/* Arka plan dekoratif öğeleri */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-100 rounded-full opacity-50 blur-3xl"></div>
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-100 rounded-full opacity-50 blur-3xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            ESTPITAL
          </h1>
          <p className="text-3xl md:text-4xl font-light text-gray-800 mb-4">
            Güzelliğinizin, Özgüveninizin Adresi
          </p>
          <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed max-w-3xl mx-auto">
            Modern plastik cerrahi çözümleri ile hayalinizdeki görünüme kavuşun. 
            Uzman hekimlerimizle kişiselleştirilmiş tedavilerle sizin için en uygun
            estetik çözümleri sunuyoruz.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              size="lg"
              onClick={onStartAnalysis}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl px-8 py-6 text-lg transition-all duration-300 transform hover:-translate-y-1"
            >
              Ücretsiz Danışmanlık Alın
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => {
                const element = document.getElementById('services');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="bg-white hover:bg-gray-50 text-gray-800 border-2 border-gray-300 shadow-md hover:shadow-lg px-8 py-6 text-lg transition-all duration-300 transform hover:-translate-y-1"
            >
              Hizmetlerimizi Keşfedin
            </Button>
          </div>
          
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center max-w-3xl mx-auto">
            <div className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <p className="font-bold text-2xl text-blue-600">10+</p>
              <p className="text-gray-600 text-sm font-medium">Yıllık Deneyim</p>
            </div>
            <div className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <p className="font-bold text-2xl text-blue-600">15+</p>
              <p className="text-gray-600 text-sm font-medium">Uzman Hekim</p>
            </div>
            <div className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <p className="font-bold text-2xl text-blue-600">5000+</p>
              <p className="text-gray-600 text-sm font-medium">Mutlu Hasta</p>
            </div>
            <div className="bg-white p-5 rounded-xl shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
              <p className="font-bold text-2xl text-blue-600">20+</p>
              <p className="text-gray-600 text-sm font-medium">Farklı Operasyon</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
