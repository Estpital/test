import { useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, useGLTF, Html } from '@react-three/drei';
import * as THREE from 'three';
import { Group } from 'three';

// Model tipi için arayüzler
interface BodyPart {
  id: string;
  name: string;
  position: [number, number, number];
  scale: [number, number, number];
}

interface ModelProps {
  setSelectedPart: (part: string | null) => void;
  hoveredPart: string | null;
  setHoveredPart: (part: string | null) => void;
}

function Model({ setSelectedPart, hoveredPart, setHoveredPart }: ModelProps) {
  // Gerçek model henüz kullanılmıyor
  // const { nodes, materials } = useGLTF('/human_model.glb');
  const meshRef = useRef<Group>(null);
  
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.002;
    }
  });

  // Basitleştirilmiş model için - gerçek modelde insan vücudu bölümleri olacak
  const bodyParts: BodyPart[] = [
    { id: 'head', name: 'Baş', position: [0, 2, 0], scale: [0.5, 0.5, 0.5] },
    { id: 'chest', name: 'Göğüs', position: [0, 0.5, 0], scale: [1, 0.75, 0.5] },
    { id: 'abdomen', name: 'Karın', position: [0, -0.5, 0], scale: [0.9, 0.5, 0.4] },
    { id: 'arms', name: 'Kollar', position: [1.2, 0.5, 0], scale: [0.25, 0.75, 0.25] },
    { id: 'legs', name: 'Bacaklar', position: [0.5, -1.5, 0], scale: [0.35, 1, 0.35] },
  ];

  const handlePartClick = (partId: string): void => {
    setSelectedPart(partId);
  };

  const handleHover = (partId: string): void => {
    setHoveredPart(partId);
  };

  const handleHoverOut = (): void => {
    setHoveredPart(null);
  };

  return (
    <group ref={meshRef}>
      {bodyParts.map((part) => (
        <mesh
          key={part.id}
          position={new THREE.Vector3(...part.position)}
          scale={new THREE.Vector3(...part.scale)}
          onClick={() => handlePartClick(part.id)}
          onPointerOver={() => handleHover(part.id)}
          onPointerOut={handleHoverOut}
        >
          <boxGeometry />
          <meshStandardMaterial 
            color={hoveredPart === part.id ? '#1e88e5' : '#64b5f6'} 
            metalness={0.1} 
            roughness={0.5} 
          />
          <Html position={[0, 0, 1]} center>
            {hoveredPart === part.id && (
              <div className="bg-black bg-opacity-70 text-white px-2 py-1 rounded text-sm pointer-events-none">
                {part.name}
              </div>
            )}
          </Html>
        </mesh>
      ))}
    </group>
  );
}

export default function HumanModel3D() {
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const [hoveredPart, setHoveredPart] = useState<string | null>(null);
  
  const handleSelectedPart = (part: string | null) => {
    setSelectedPart(part);
  };
  
  const handleHoveredPart = (part: string | null) => {
    setHoveredPart(part);
  };

  return (
    <div className="relative h-[600px] w-full">
      <Canvas className="bg-gray-100 rounded-lg" camera={{ position: [0, 0, 5], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
        <pointLight position={[-10, -10, -10]} />
        <Model 
          setSelectedPart={handleSelectedPart} 
          hoveredPart={hoveredPart} 
          setHoveredPart={handleHoveredPart} 
        />
        <OrbitControls enableZoom={true} enablePan={true} />
      </Canvas>
      
      {selectedPart && (
        <div className="absolute bottom-4 left-4 right-4 bg-white p-4 rounded-lg shadow-lg">
          <h3 className="text-lg font-semibold mb-2">
            {selectedPart === 'head' && 'Baş ve Yüz Operasyonları'}
            {selectedPart === 'chest' && 'Göğüs Operasyonları'}
            {selectedPart === 'abdomen' && 'Karın Operasyonları'}
            {selectedPart === 'arms' && 'Kol Operasyonları'}
            {selectedPart === 'legs' && 'Bacak Operasyonları'}
          </h3>
          <p className="text-gray-600">
            Bu bölgeyle ilgili plastik cerrahi operasyonları görüntülemek için tıklayın
          </p>
          <button className="mt-2 bg-blue-500 hover:bg-blue-700 text-white py-1 px-4 rounded">
            Operasyonları Görüntüle
          </button>
        </div>
      )}
    </div>
  );
}