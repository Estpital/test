import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import Step1BasicInfo from "./formSteps/Step1BasicInfo";
import Step2HairLossPattern from "./formSteps/Step2HairLossPattern";
import Step3HairScalpCondition from "./formSteps/Step3HairScalpCondition";
import Step4LifestyleHealth from "./formSteps/Step4LifestyleHealth";
import Step5PhotoUpload from "./formSteps/Step5PhotoUpload";
import Step6ContactInfo from "./formSteps/Step6ContactInfo";

interface MultiStepFormProps {
  onSubmit: (formData: any) => void;
  isSubmitting: boolean;
}

export default function MultiStepForm({ onSubmit, isSubmitting }: MultiStepFormProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 6;
  const [formData, setFormData] = useState({
    // Step 1: Basic Info
    age: "",
    gender: "",
    hairLoss: "",
    hairLossTime: "",
    
    // Step 2: Hair Loss Pattern
    pattern: "",
    familyHistory: "",
    
    // Step 3: Hair & Scalp Condition
    scalpCondition: "",
    scalpIssues: "",
    washFrequency: "",
    
    // Step 4: Lifestyle & Health
    stressLevel: "",
    healthConditions: "",
    weightChanges: "",
    
    // Step 5: Photo Upload
    photoUrls: [],
    
    // Step 6: Contact Info
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    country: "",
    marketingConsent: false,
  });
  
  const updateFormData = (stepData: any) => {
    setFormData({
      ...formData,
      ...stepData
    });
  };
  
  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };
  
  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };
  
  const handleSubmit = () => {
    onSubmit(formData);
  };
  
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <Step1BasicInfo 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 nextStep={nextStep} 
               />;
      case 2:
        return <Step2HairLossPattern 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 nextStep={nextStep} 
               />;
      case 3:
        return <Step3HairScalpCondition 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 nextStep={nextStep} 
               />;
      case 4:
        return <Step4LifestyleHealth 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 nextStep={nextStep} 
               />;
      case 5:
        return <Step5PhotoUpload 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 nextStep={nextStep} 
               />;
      case 6:
        return <Step6ContactInfo 
                 formData={formData} 
                 updateFormData={updateFormData} 
                 handleSubmit={handleSubmit} 
                 isSubmitting={isSubmitting} 
               />;
      default:
        return null;
    }
  };
  
  const progress = (currentStep / totalSteps) * 100;
  
  return (
    <Card className="bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Progress Stepper */}
      <div className="bg-gray-50 px-6 py-4 border-b">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            {currentStep > 1 && (
              <button
                onClick={prevStep}
                className="flex items-center gap-1 text-gray-500 hover:text-primary cursor-pointer"
              >
                <ChevronLeft className="h-4 w-4" />
                <span className="text-sm">Back</span>
              </button>
            )}
          </div>
          <div className="text-sm font-medium text-gray-600">
            Step {currentStep} of {totalSteps}
          </div>
        </div>
        <div className="mt-4 relative">
          <div className="overflow-hidden h-2 mb-4 flex rounded bg-gray-200">
            <div 
              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary transition-all duration-300" 
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between -mt-2">
            {[...Array(totalSteps)].map((_, index) => (
              <div 
                key={index}
                className={`w-6 h-6 rounded-full text-xs flex items-center justify-center text-white shadow ${
                  index + 1 <= currentStep ? 'bg-primary' : 'bg-gray-300'
                }`}
              >
                {index + 1}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Form Step Content */}
      <div className="p-6 md:p-8">
        {renderStep()}
        
        {/* Navigation Buttons */}
        <div className="mt-8 flex justify-between">
          {currentStep > 1 && (
            <Button
              variant="outline"
              onClick={prevStep}
              className="border border-gray-300 text-gray-700"
            >
              Previous
            </Button>
          )}
          <div></div>
          {currentStep < totalSteps && (
            <Button
              onClick={nextStep}
              className="bg-primary hover:bg-primary-dark text-white shadow-md hover:shadow-lg"
            >
              Next
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
