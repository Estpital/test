import { Link } from "wouter";

interface Procedure {
  id: string;
  name: string;
  route: string;
  image: string;
  shortDesc: string;
}

interface ProcedureCategoryProps {
  title: string;
  subtitle: string;
  doctor: {
    name: string;
    title: string;
    image: string;
  };
  procedures: Procedure[];
  bgColor?: string;
  textColor?: string;
  accentColor?: string;
}

export default function ProcedureCategorySection({
  title,
  subtitle,
  doctor,
  procedures,
  bgColor = "bg-white",
  textColor = "text-gray-900",
  accentColor = "bg-teal-600",
}: ProcedureCategoryProps) {
  return (
    <section className={`py-16 ${bgColor}`}>
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row items-center mb-12">
            <div className="md:w-1/3 mb-8 md:mb-0 flex justify-center">
              <div className="w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4 border-white shadow-xl">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                  }}
                />
              </div>
            </div>
            
            <div className="md:w-2/3 text-center md:text-left md:pl-8">
              <div className={`inline-block ${accentColor} text-white px-4 py-1 rounded-full font-medium text-sm mb-3`}>
                UZMANLIK ALANI
              </div>
              <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${textColor}`}>
                {title}
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                {subtitle}
              </p>
              <div className="flex flex-col md:flex-row items-center">
                <div className="text-center md:text-left">
                  <h3 className="text-xl font-semibold">{doctor.name}</h3>
                  <p className="text-gray-600">{doctor.title}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Procedures Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
            {procedures.map((procedure) => (
              <Link key={procedure.id} href={procedure.route}>
                <a className="block group">
                  <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2 group-hover:shadow-lg">
                    <div className="aspect-square relative">
                      <img
                        src={procedure.image}
                        alt={procedure.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-75 group-hover:opacity-90 transition-opacity"></div>
                      <div className="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 className="text-white text-center font-medium text-sm md:text-base leading-tight">
                          {procedure.name}
                        </h3>
                      </div>
                    </div>
                  </div>
                </a>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}