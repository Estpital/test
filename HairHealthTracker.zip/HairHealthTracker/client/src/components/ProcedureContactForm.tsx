import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

// İşlemler listesi - bu listeyi her yeni işlem eklendiğinde güncelleyeceğiz
const PROCEDURES = [
  { value: "facelift", label: "Yüz Germe (Face Lift)" },
  { value: "hairtransplant", label: "Saç Ekimi" },
  { value: "rhinoplasty", label: "Burun Estetiği (Rinoplasti)" },
  { value: "eyelid", label: "Göz Kapağı Estetiği (Blefaroplasti)" },
  { value: "necklift", label: "Boyun Germe" },
  { value: "liplift", label: "Dudak Kaldırma (Lip Lift)" },
  { value: "botox", label: "Botoks Uygulamaları" },
  { value: "fillers", label: "Dolgu Uygulamaları" },
  { value: "mesotherapy", label: "Mezoterapi" },
  { value: "other", label: "Diğer" },
];

// Ülkeler Listesi
const COUNTRIES = [
  { value: "tr", label: "Türkiye" },
  { value: "de", label: "Almanya" },
  { value: "nl", label: "Hollanda" },
  { value: "be", label: "Belçika" },
  { value: "fr", label: "Fransa" },
  { value: "uk", label: "Birleşik Krallık" },
  { value: "us", label: "Amerika Birleşik Devletleri" },
  { value: "ru", label: "Rusya" },
  { value: "sa", label: "Suudi Arabistan" },
  { value: "ae", label: "Birleşik Arap Emirlikleri" },
  { value: "other", label: "Diğer" },
];

interface ProcedureContactFormProps {
  defaultProcedure?: string;
  className?: string;
}

export default function ProcedureContactForm({ defaultProcedure, className }: ProcedureContactFormProps) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [country, setCountry] = useState("");
  const [procedure, setProcedure] = useState(defaultProcedure || "");
  const [message, setMessage] = useState("");
  const [photos, setPhotos] = useState<FileList | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Form doğrulama
    if (!name || !phone || !email || !country || !procedure) {
      toast({
        title: "Eksik Bilgi",
        description: "Lütfen tüm zorunlu alanları doldurun.",
        variant: "destructive",
      });
      setIsSubmitting(false);
      return;
    }

    // TODO: Form gönderim işlemi
    try {
      // Burada form verileri sunucuya gönderilecek
      // Şimdilik simüle ederek gösterim yapıyoruz
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Talebiniz Alındı",
        description: "Uzmanlarımız en kısa sürede sizinle iletişime geçecek.",
      });
      
      // Formu sıfırla
      setName("");
      setPhone("");
      setEmail("");
      setCountry("");
      setProcedure(defaultProcedure || "");
      setMessage("");
      setPhotos(null);
    } catch (error) {
      toast({
        title: "Hata Oluştu",
        description: "Talebiniz gönderilirken bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className={`w-full ${className || ""}`}>
      <CardHeader>
        <CardTitle className="text-2xl font-bold">Ücretsiz Konsültasyon</CardTitle>
        <CardDescription>
          Formu doldurun, uzmanlarımız 24 saat içinde sizinle iletişime geçsin.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Ad Soyad *</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Adınız ve soyadınız" 
                required 
              />
            </div>
            <div>
              <Label htmlFor="phone">Telefon *</Label>
              <Input 
                id="phone" 
                value={phone} 
                onChange={(e) => setPhone(e.target.value)} 
                placeholder="+90 555 123 4567" 
                required 
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">E-posta *</Label>
              <Input 
                id="email" 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="email@example.com" 
                required 
              />
            </div>
            <div>
              <Label htmlFor="country">Ülke *</Label>
              <Select value={country} onValueChange={setCountry} required>
                <SelectTrigger id="country">
                  <SelectValue placeholder="Ülke seçiniz" />
                </SelectTrigger>
                <SelectContent>
                  {COUNTRIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="procedure">İlgilendiğiniz İşlem *</Label>
            <Select value={procedure} onValueChange={setProcedure} required>
              <SelectTrigger id="procedure">
                <SelectValue placeholder="İşlem seçiniz" />
              </SelectTrigger>
              <SelectContent>
                {PROCEDURES.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="message">Mesajınız</Label>
            <Textarea 
              id="message" 
              value={message} 
              onChange={(e) => setMessage(e.target.value)} 
              placeholder="Sorularınız veya ek bilgiler" 
              rows={4} 
            />
          </div>
          
          <div>
            <Label htmlFor="photos">Fotoğraf Yükle (İsteğe Bağlı)</Label>
            <Input 
              id="photos" 
              type="file" 
              multiple 
              accept="image/*" 
              onChange={(e) => setPhotos(e.target.files)} 
            />
            <p className="text-xs text-gray-500 mt-1">
              Durumunuzla ilgili fotoğraflar yükleyebilirsiniz. En fazla 3 fotoğraf, her biri 5MB boyutunda.
            </p>
          </div>
          
          <Button 
            type="submit" 
            className="w-full bg-gradient-to-r from-teal-500 to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white" 
            disabled={isSubmitting}
          >
            {isSubmitting ? "Gönderiliyor..." : "Ücretsiz Konsültasyon Talep Et"}
          </Button>
          
          <p className="text-xs text-gray-500 text-center">
            Bu formu göndererek kişisel verilerinizin işlenmesini kabul etmiş olursunuz.
            <br />Detaylı bilgi için <a href="/privacy-policy" className="underline">Gizlilik Politikamızı</a> inceleyebilirsiniz.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}