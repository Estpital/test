import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export interface ServicesSectionProps {
  id?: string;
}

const services = [
  {
    id: 1,
    title: "Saç Ekimi",
    description: "FUE ve DHI gibi en ileri tekniklerle doğal ve kalıcı sonuçlar elde edin. Saç ekimi konusunda uzmanlaşmış doktorlarımız, kişiye özel tedavi planları ile saçlarınıza yeniden kavuşmanızı sağlar.",
    path: "/services/hair-transplant",
    imageColor: "bg-blue-200",
    icon: "✂️"
  },
  {
    id: 2,
    title: "Burun Estetiği",
    description: "Burun şekil bozukluklarını düzeltmek ve nefes alma problemlerini gidermek için açık ve kapalı tekniklerle yapılan ameliyatlar. Yüzünüzün dengesini yeniden kurun.",
    path: "/services/rhinoplasty",
    imageColor: "bg-green-200",
    icon: "👃"
  },
  {
    id: 3,
    title: "Liposuction",
    description: "Vücudunuzdaki inatçı yağ birikintilerinden modern liposuction teknikleriyle kurtulun. Vaser, lazer ve klasik liposuction seçenekleriyle vücut hatlarınızı şekillendirin.",
    path: "/services/liposuction",
    imageColor: "bg-indigo-200",
    icon: "⚕️"
  },
  {
    id: 4,
    title: "Meme Estetiği",
    description: "Meme büyütme, küçültme veya dikleştirme operasyonlarıyla kendinizi daha iyi hissedin. En son tekniklerle doğal sonuçlar elde edin.",
    path: "/services/breast-aesthetics",
    imageColor: "bg-pink-200",
    icon: "💉"
  },
  {
    id: 5,
    title: "Hollywood Smile",
    description: "Laminate veneerler, implantlar, beyazlatma ve diğer diş estetiği uygulamalarıyla Hollywood yıldızları gibi parlak ve mükemmel bir gülüşe sahip olun.",
    path: "/services/hollywood-smile",
    imageColor: "bg-amber-200",
    icon: "😁"
  },
  {
    id: 6,
    title: "Yüz Gençleştirme",
    description: "Botox, dolgu, yüz germe, göz kapağı estetiği ve diğer minimal invaziv yöntemlerle genç ve canlı bir görünüm kazanın.",
    path: "/services/facial-rejuvenation",
    imageColor: "bg-purple-200",
    icon: "👤"
  }
];

export default function ServicesSection({ id }: ServicesSectionProps) {
  return (
    <section id={id} className="py-16 px-4 bg-white">
      <div className="container mx-auto">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">Hizmetlerimiz</h2>
          <p className="text-lg text-gray-600">
            Estetik cerrahi, tıbbi estetik ve kişisel bakım konularında sizlere en yüksek kalitede hizmet sunuyoruz. 
            İşte sunduğumuz bazı hizmetler:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <Card 
              key={service.id} 
              className="shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden group"
            >
              <div className={`h-48 ${service.imageColor} flex items-center justify-center text-6xl relative overflow-hidden`}>
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <span className="z-10 transform group-hover:scale-110 transition-transform duration-300">{service.icon}</span>
              </div>
              <CardHeader>
                <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base text-gray-600 min-h-[100px]">{service.description}</CardDescription>
                <a 
                  href={service.path} 
                  className="mt-4 text-blue-600 hover:text-blue-800 font-medium flex items-center group-hover:underline"
                  onClick={(e) => {
                    // Saç ekimi sayfası için özel yönlendirme
                    if (service.path === "/services/hair-transplant") {
                      e.preventDefault();
                      window.location.href = "/services/hair-transplant";
                    }
                  }}
                >
                  Daha Fazla Bilgi
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className="h-5 w-5 ml-1 transform group-hover:translate-x-1 transition-transform duration-200" 
                    viewBox="0 0 20 20" 
                    fill="currentColor"
                  >
                    <path 
                      fillRule="evenodd" 
                      d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" 
                      clipRule="evenodd" 
                    />
                  </svg>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md hover:shadow-lg transition-all">
            Tüm Hizmetlerimizi Keşfedin
          </button>
        </div>
      </div>
    </section>
  );
}