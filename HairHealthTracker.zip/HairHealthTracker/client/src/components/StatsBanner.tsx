import { cn } from "@/lib/utils";

interface StatType {
  value: string;
  title: string;
}

interface StatsBannerProps {
  className?: string;
  stats: StatType[];
  background?: string;
  textColor?: string;
}

export default function StatsBanner({ 
  className = "", 
  stats,
  background = "bg-white",
  textColor = "text-gray-800"
}: StatsBannerProps) {
  return (
    <section className={cn("py-12", background, className)}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <h2 className={cn("text-4xl md:text-5xl font-bold mb-2", textColor)}>{stat.value}</h2>
              <p className={cn("text-gray-600", textColor === "text-white" ? "text-gray-300" : "")}>{stat.title}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}