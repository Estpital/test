import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Star, StarHalf } from "lucide-react";

export default function Testimonials() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Success Stories</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="https://images.unsplash.com/photo-1599566150163-29194dcaad36" alt="Michael K." />
                    <AvatarFallback>MK</AvatarFallback>
                  </Avatar>
                  <div className="ml-4">
                    <h4 className="text-lg font-bold text-gray-900">Michael K.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"After trying numerous products with no success, the personalized treatment plan from EliHair has made a remarkable difference. My hair is noticeably thicker after just 6 months of treatment."</p>
              </CardContent>
            </Card>
            
            <Card className="shadow-md">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330" alt="Sarah T." />
                    <AvatarFallback>ST</AvatarFallback>
                  </Avatar>
                  <div className="ml-4">
                    <h4 className="text-lg font-bold text-gray-900">Sarah T.</h4>
                    <div className="flex text-yellow-400">
                      {[...Array(4)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                      <StarHalf className="h-4 w-4 fill-current" />
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"The online hair analysis tool accurately identified my scalp condition and hair loss pattern. The recommended PRP therapy has given me amazing results that exceeded my expectations."</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
