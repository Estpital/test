import { useState } from "react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";

interface VideoProps {
  id?: string;
}

interface VideoItem {
  title: string;
  url: string;
  thumbnailUrl: string;
  description: string;
}

export default function VideoSection({ id }: VideoProps) {
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);

  const videoItems: VideoItem[] = [
    {
      title: "Saç Ekimi Artık Ağrılı Bir İşlem Değil!",
      url: "https://www.instagram.com/p/DG2zbG3CXJU/",
      thumbnailUrl: "https://images.unsplash.com/photo-1656618020911-1c7a937175fd?q=80&w=1470&auto=format&fit=crop",
      description: "Dr. Gizem Kağıtçı, modern saç ekimi işleminde ağrı seviyesinin minimum olduğunu anlatıyor."
    },
    {
      title: "Saç Ekiminden Sonra Ağrı Olur mu?",
      url: "https://www.instagram.com/p/DG3YUxbiFAZ/",
      thumbnailUrl: "https://images.unsplash.com/photo-1579684288361-5c1a2955d0bc?q=80&w=1480&auto=format&fit=crop",
      description: "Operasyon sonrası süreçte ağrı yönetimi ve dikkat edilmesi gerekenler hakkında bilgi."
    },
    {
      title: "Saç Ekiminde Tek Seans Yeterli mi?",
      url: "https://www.instagram.com/p/DG5s38zImR3/",
      thumbnailUrl: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=1564&auto=format&fit=crop",
      description: "Saç ekiminde seans sayısı nasıl belirlenir? Hangi durumlarda tek seans yeterlidir?"
    },
    {
      title: "Saç Ekimlerini Siz mi Yapıyorsunuz?",
      url: "https://www.instagram.com/p/DG58AG_ogoo/",
      thumbnailUrl: "https://images.unsplash.com/photo-1613918108466-292b78a8ef95?q=80&w=1476&auto=format&fit=crop",
      description: "Dr. Gizem Kağıtçı, operasyonları bizzat kendisinin yaptığına dair güvence veriyor."
    },
    {
      title: "Saç Ekiminden Sonra İşe Ne Zaman Dönebiliriz?",
      url: "https://www.instagram.com/p/DG6CW6qo-lQ/",
      thumbnailUrl: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1374&auto=format&fit=crop",
      description: "İyileşme sürecinde günlük aktivitelere ve işe dönüş zamanlaması hakkında öneriler."
    },
    {
      title: "Saç Ekiminde Doğal Görünüm İçin Temel Yaklaşımlar Nelerdir?",
      url: "https://www.instagram.com/p/DG6L0SsInjX/",
      thumbnailUrl: "https://images.unsplash.com/photo-1633613286848-e6f43bbafb8d?q=80&w=1470&auto=format&fit=crop",
      description: "Doğal saç çizgisi ve görünüm elde etmek için Dr. Gizem'in profesyonel yaklaşımları."
    }
  ];
  
  // Instagram reels sonuçları
  const resultsVideos: VideoItem[] = [
    {
      title: "Saç Ekimi Sonuçları 1",
      url: "https://www.instagram.com/p/DGtJ0QfgNno/",
      thumbnailUrl: "https://images.unsplash.com/photo-1626015253847-cf60aa47d71f?q=80&w=1470&auto=format&fit=crop",
      description: "Öncesi ve sonrası dramatik değişimi gösteren hasta sonucu."
    },
    {
      title: "Saç Ekimi Sonuçları 2",
      url: "https://www.instagram.com/p/DFAi_6dAZiP/",
      thumbnailUrl: "https://images.unsplash.com/photo-1635443674106-ae4b85129871?q=80&w=1436&auto=format&fit=crop",
      description: "İleri seviye kellik tedavisinde başarılı sonuç örneği."
    },
    {
      title: "Saç Ekimi Sonuçları 3",
      url: "https://www.instagram.com/p/DD2TVR-gJNE/",
      thumbnailUrl: "https://images.unsplash.com/photo-1532710093739-9470acff878f?q=80&w=1470&auto=format&fit=crop",
      description: "Alın çizgisi gerilemesi ve tepe alanında yapılan ekim sonrası."
    },
    {
      title: "Saç Ekimi Sonuçları 4",
      url: "https://www.instagram.com/p/DDVB4I0AjWJ/",
      thumbnailUrl: "https://images.unsplash.com/photo-1519699047748-de8e457a634e?q=80&w=1480&auto=format&fit=crop",
      description: "6 ay sonrasında gözle görülür yoğunluk ve doğal görünüm."
    },
    {
      title: "Saç Ekimi Sonuçları 5",
      url: "https://www.instagram.com/p/DDETfybgA76/",
      thumbnailUrl: "https://images.unsplash.com/photo-1600957377042-5a7a23961659?q=80&w=1470&auto=format&fit=crop",
      description: "Genç yaşta saç dökülmesi yaşayan hastanın tedavi sonrası dönüşümü."
    },
    {
      title: "Saç Ekimi Sonuçları 6",
      url: "https://www.instagram.com/p/DC7NbAyAlpT/",
      thumbnailUrl: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?q=80&w=1470&auto=format&fit=crop",
      description: "DHI yöntemiyle sağlanan doğal saç çizgisi ve yoğunluk."
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-white to-blue-50" id={id}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-50 text-blue-600 px-4 py-1 rounded-full font-medium text-sm mb-3">
            VİDEOLARIMIZ
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            Dr. Gizem Kağıtçı ile Saç Ekimi
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Merak ettiğiniz soruların ve tedavi süreçlerinin detaylı videolarla açıklamalarını inceleyebilirsiniz.
          </p>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-semibold mb-8 text-gray-800">Sık Sorulan Sorular</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {videoItems.map((video, index) => (
              <Dialog key={index}>
                <DialogTrigger asChild>
                  <div 
                    className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setSelectedVideo(video)}
                  >
                    <div className="relative pt-[56.25%]">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="absolute inset-0 w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1503443207922-dff7d543fd0e?q=80&w=1527&auto=format&fit=crop";
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                        <div className="w-16 h-16 rounded-full bg-white bg-opacity-80 flex items-center justify-center">
                          <svg className="w-8 h-8 text-teal-600" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 5v14l11-7z"></path>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-semibold text-gray-900 mb-2 line-clamp-1">{video.title}</h4>
                      <p className="text-gray-600 text-sm line-clamp-2">{video.description}</p>
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <div className="aspect-video w-full">
                    <iframe
                      src={`${video.url.replace("https://www.instagram.com/p/", "https://www.instagram.com/p/embed/code/")}embed/`}
                      className="w-full h-full"
                      allow="autoplay; encrypted-media"
                      allowFullScreen
                    ></iframe>
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{video.title}</h3>
                    <p className="text-gray-600">{video.description}</p>
                    <a 
                      href={video.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="mt-4 inline-block text-teal-600 hover:text-teal-700"
                    >
                      Instagram'da Görüntüle
                    </a>
                  </div>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-semibold mb-8 text-gray-800">Başarılı Sonuçlarımız</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {resultsVideos.map((video, index) => (
              <Dialog key={index}>
                <DialogTrigger asChild>
                  <div 
                    className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => setSelectedVideo(video)}
                  >
                    <div className="relative pt-[56.25%]">
                      <img
                        src={video.thumbnailUrl}
                        alt={video.title}
                        className="absolute inset-0 w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1564460576398-ef55d99548b2?q=80&w=1374&auto=format&fit=crop";
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                        <div className="w-16 h-16 rounded-full bg-white bg-opacity-80 flex items-center justify-center">
                          <svg className="w-8 h-8 text-teal-600" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 5v14l11-7z"></path>
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-semibold text-gray-900 mb-2 line-clamp-1">{video.title}</h4>
                      <p className="text-gray-600 text-sm line-clamp-2">{video.description}</p>
                    </div>
                  </div>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <div className="aspect-video w-full">
                    <iframe
                      src={`${video.url.replace("https://www.instagram.com/p/", "https://www.instagram.com/p/embed/code/")}embed/`}
                      className="w-full h-full"
                      allow="autoplay; encrypted-media"
                      allowFullScreen
                    ></iframe>
                  </div>
                  <div className="p-4">
                    <h3 className="text-xl font-bold mb-2">{video.title}</h3>
                    <p className="text-gray-600">{video.description}</p>
                    <a 
                      href={video.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="mt-4 inline-block text-teal-600 hover:text-teal-700"
                    >
                      Instagram'da Görüntüle
                    </a>
                  </div>
                </DialogContent>
              </Dialog>
            ))}
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <a 
            href="https://www.instagram.com/dr.gizemkagitci"
            target="_blank"
            rel="noopener noreferrer" 
            className="inline-flex items-center justify-center bg-gradient-to-r from-pink-600 to-purple-600 text-white px-8 py-3 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
          >
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            Daha Fazla Video İçin Instagram'ı Takip Edin
          </a>
        </div>
      </div>
    </section>
  );
}