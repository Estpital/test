import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";

interface Step1Props {
  formData: any;
  updateFormData: (data: any) => void;
  nextStep: () => void;
}

const formSchema = z.object({
  age: z.string().min(1, { message: "Please select your age range" }),
  gender: z.string().min(1, { message: "Please select your gender" }),
  hairLoss: z.string().min(1, { message: "Please select if you've noticed hair loss" }),
  hairLossTime: z.string().min(1, { message: "Please select how long you've been experiencing hair loss" }),
});

export default function Step1BasicInfo({ formData, updateFormData, nextStep }: Step1Props) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: formData.age || "",
      gender: formData.gender || "",
      hairLoss: formData.hairLoss || "",
      hairLossTime: formData.hairLossTime || "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    updateFormData(values);
    nextStep();
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Basic Information</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="age"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Age</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your age range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="under-20">Under 20</SelectItem>
                      <SelectItem value="21-30">21-30</SelectItem>
                      <SelectItem value="31-40">31-40</SelectItem>
                      <SelectItem value="41-50">41-50</SelectItem>
                      <SelectItem value="51-60">51-60</SelectItem>
                      <SelectItem value="over-60">Over 60</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="gender"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Gender</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your gender" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="prefer-not-to-say">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="hairLoss"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>Have you noticed hair loss or thinning?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="significant" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Yes, I've noticed significant hair loss
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="somewhat" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Somewhat, I've noticed some thinning
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="none" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        No, I haven't noticed any hair loss
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="hairLossTime"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>How long have you been experiencing hair loss?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="less-than-6-months" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Less than 6 months
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="6-months-to-1-year" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        6 months to 1 year
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="1-3-years" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        1-3 years
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="more-than-3-years" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        More than 3 years
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="not-applicable" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Not applicable
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="mt-6 w-full md:w-auto bg-primary hover:bg-primary-dark"
          >
            Continue
          </Button>
        </form>
      </Form>
    </div>
  );
}
