import { useState } from "react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";

interface Step2Props {
  formData: any;
  updateFormData: (data: any) => void;
  nextStep: () => void;
}

const formSchema = z.object({
  pattern: z.string().min(1, { message: "Please select a hair loss pattern" }),
  familyHistory: z.string().min(1, { message: "Please indicate if there's a family history of hair loss" }),
});

export default function Step2HairLossPattern({ formData, updateFormData, nextStep }: Step2Props) {
  const [selectedPattern, setSelectedPattern] = useState(formData.pattern || "");
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      pattern: formData.pattern || "",
      familyHistory: formData.familyHistory || "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    updateFormData(values);
    nextStep();
  };
  
  const handlePatternSelect = (pattern: string) => {
    setSelectedPattern(pattern);
    form.setValue("pattern", pattern);
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Hair Loss Pattern</h2>
      <p className="text-gray-600 mb-6">Please select the image that most closely resembles your current hair loss pattern:</p>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="pattern"
            render={() => (
              <FormItem className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "receding" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("receding")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://images.unsplash.com/photo-1585751119414-ef2636f8aede?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
                        alt="Receding hairline pattern" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Receding hairline</p>
                    </CardContent>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "crown" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("crown")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://images.unsplash.com/photo-1599351431202-1e0f0137899a?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
                        alt="Crown thinning pattern" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Crown thinning</p>
                    </CardContent>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "overall" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("overall")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
                        alt="Overall thinning pattern" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Overall thinning</p>
                    </CardContent>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "widening" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("widening")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://images.unsplash.com/photo-1620331311520-246422fd82f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=400" 
                        alt="Female pattern hair loss" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Widening part line</p>
                    </CardContent>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "edges" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("edges")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://pixabay.com/get/g1047892f623b2d61cd0a9aa6ddb25017ba45e084f46e19ceb6d4211583036b8d1ba7fa7f84cb5da0e7ba995fc9dce5afe429763908e490586d5905999884c498_1280.jpg" 
                        alt="Traction alopecia pattern" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Hairline/edges thinning</p>
                    </CardContent>
                  </Card>
                  
                  <Card 
                    className={`cursor-pointer transition-all ${selectedPattern === "patchy" ? "border-primary bg-blue-50" : "border"}`}
                    onClick={() => handlePatternSelect("patchy")}
                  >
                    <CardContent className="p-3">
                      <img 
                        src="https://pixabay.com/get/gf25fa8070ac9ddb7e0cbd76867264fdfcb944dae6db7e8a508e8def700c71a144fc49e6942c5931fb1d40fa65bc9337bb1cf1dd7af1b716cf750305c32a26963_1280.jpg" 
                        alt="Patchy hair loss pattern" 
                        className="w-full h-40 object-cover rounded-lg mb-2" 
                      />
                      <p className="text-sm font-medium text-center">Patchy hair loss</p>
                    </CardContent>
                  </Card>
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="familyHistory"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>Is there a history of hair loss in your family?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="father" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Yes, on my father's side
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="mother" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Yes, on my mother's side
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="both" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        Yes, on both sides
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="none" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        No family history
                      </FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="unknown" />
                      </FormControl>
                      <FormLabel className="font-normal">
                        I don't know
                      </FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="mt-6 w-full md:w-auto bg-primary hover:bg-primary-dark"
          >
            Continue
          </Button>
        </form>
      </Form>
    </div>
  );
}
