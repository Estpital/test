import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";

interface Step3Props {
  formData: any;
  updateFormData: (data: any) => void;
  nextStep: () => void;
}

const scalpIssuesSchema = z.array(z.string()).refine((value) => value.length > 0, {
  message: "Please select at least one option",
});

const formSchema = z.object({
  scalpCondition: z.string().min(1, { message: "Please describe your scalp condition" }),
  scalpIssues: scalpIssuesSchema,
  washFrequency: z.string().min(1, { message: "Please select your hair washing frequency" }),
});

export default function Step3HairScalpCondition({ formData, updateFormData, nextStep }: Step3Props) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      scalpCondition: formData.scalpCondition || "",
      scalpIssues: formData.scalpIssues ? formData.scalpIssues.split(",") : ["none"],
      washFrequency: formData.washFrequency || "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    updateFormData({
      ...values,
      scalpIssues: values.scalpIssues.join(",")
    });
    nextStep();
  };
  
  const scalpIssuesItems = [
    { id: "dandruff", label: "Dandruff" },
    { id: "seborrheic", label: "Seborrheic dermatitis" },
    { id: "psoriasis", label: "Psoriasis" },
    { id: "excessive", label: "Excessive sweating" },
    { id: "none", label: "None of the above" },
  ];
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Hair & Scalp Condition</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="scalpCondition"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>How would you describe your scalp?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="normal" />
                      </FormControl>
                      <FormLabel className="font-normal">Normal</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="dry" />
                      </FormControl>
                      <FormLabel className="font-normal">Dry and flaky</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="oily" />
                      </FormControl>
                      <FormLabel className="font-normal">Oily</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="itchy" />
                      </FormControl>
                      <FormLabel className="font-normal">Itchy</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="sensitive" />
                      </FormControl>
                      <FormLabel className="font-normal">Sensitive/Painful</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="scalpIssues"
            render={() => (
              <FormItem>
                <div className="mb-4">
                  <FormLabel>Do you experience any of these conditions? (Select all that apply)</FormLabel>
                </div>
                <div className="space-y-2">
                  {scalpIssuesItems.map((item) => (
                    <FormField
                      key={item.id}
                      control={form.control}
                      name="scalpIssues"
                      render={({ field }) => {
                        return (
                          <FormItem
                            key={item.id}
                            className="flex flex-row items-start space-x-3 space-y-0"
                          >
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes(item.id)}
                                onCheckedChange={(checked) => {
                                  const currentValues = [...field.value];
                                  if (item.id === "none") {
                                    // If "None" is selected, clear all other selections
                                    if (checked) {
                                      field.onChange(["none"]);
                                    } else {
                                      field.onChange([]);
                                    }
                                  } else {
                                    // If any other item is checked, remove "None" if present
                                    const updatedValues = currentValues.filter(val => val !== "none");
                                    
                                    if (checked) {
                                      field.onChange([...updatedValues, item.id]);
                                    } else {
                                      field.onChange(
                                        updatedValues.filter((value) => value !== item.id)
                                      );
                                    }
                                  }
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              {item.label}
                            </FormLabel>
                          </FormItem>
                        );
                      }}
                    />
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="washFrequency"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>How often do you wash your hair?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="daily" />
                      </FormControl>
                      <FormLabel className="font-normal">Daily</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="every-other-day" />
                      </FormControl>
                      <FormLabel className="font-normal">Every other day</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="twice-weekly" />
                      </FormControl>
                      <FormLabel className="font-normal">2-3 times per week</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="once-weekly" />
                      </FormControl>
                      <FormLabel className="font-normal">Once a week</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="less-than-weekly" />
                      </FormControl>
                      <FormLabel className="font-normal">Less than once a week</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="mt-6 w-full md:w-auto bg-primary hover:bg-primary-dark"
          >
            Continue
          </Button>
        </form>
      </Form>
    </div>
  );
}
