import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";

interface Step4Props {
  formData: any;
  updateFormData: (data: any) => void;
  nextStep: () => void;
}

const healthConditionsSchema = z.array(z.string()).refine((value) => value.length > 0, {
  message: "Please select at least one option",
});

const formSchema = z.object({
  stressLevel: z.string().min(1, { message: "Please select your stress level" }),
  healthConditions: healthConditionsSchema,
  weightChanges: z.string().min(1, { message: "Please select if you've experienced weight changes" }),
});

export default function Step4LifestyleHealth({ formData, updateFormData, nextStep }: Step4Props) {
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      stressLevel: formData.stressLevel || "",
      healthConditions: formData.healthConditions ? formData.healthConditions.split(",") : ["none"],
      weightChanges: formData.weightChanges || "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    updateFormData({
      ...values,
      healthConditions: values.healthConditions.join(",")
    });
    nextStep();
  };
  
  const healthConditionsItems = [
    { id: "thyroid", label: "Thyroid disorder" },
    { id: "hormonal", label: "Hormonal imbalance" },
    { id: "anemia", label: "Anemia/Iron deficiency" },
    { id: "autoimmune", label: "Autoimmune condition" },
    { id: "skin", label: "Skin condition" },
    { id: "none", label: "None of the above" },
  ];
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Lifestyle & Health</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="stressLevel"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>How would you describe your stress levels?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="low" />
                      </FormControl>
                      <FormLabel className="font-normal">Low</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="moderate" />
                      </FormControl>
                      <FormLabel className="font-normal">Moderate</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="high" />
                      </FormControl>
                      <FormLabel className="font-normal">High</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="severe" />
                      </FormControl>
                      <FormLabel className="font-normal">Severe</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="healthConditions"
            render={() => (
              <FormItem>
                <div className="mb-4">
                  <FormLabel>Do you have any of the following health conditions? (Select all that apply)</FormLabel>
                </div>
                <div className="space-y-2">
                  {healthConditionsItems.map((item) => (
                    <FormField
                      key={item.id}
                      control={form.control}
                      name="healthConditions"
                      render={({ field }) => {
                        return (
                          <FormItem
                            key={item.id}
                            className="flex flex-row items-start space-x-3 space-y-0"
                          >
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes(item.id)}
                                onCheckedChange={(checked) => {
                                  const currentValues = [...field.value];
                                  if (item.id === "none") {
                                    // If "None" is selected, clear all other selections
                                    if (checked) {
                                      field.onChange(["none"]);
                                    } else {
                                      field.onChange([]);
                                    }
                                  } else {
                                    // If any other item is checked, remove "None" if present
                                    const updatedValues = currentValues.filter(val => val !== "none");
                                    
                                    if (checked) {
                                      field.onChange([...updatedValues, item.id]);
                                    } else {
                                      field.onChange(
                                        updatedValues.filter((value) => value !== item.id)
                                      );
                                    }
                                  }
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              {item.label}
                            </FormLabel>
                          </FormItem>
                        );
                      }}
                    />
                  ))}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="weightChanges"
            render={({ field }) => (
              <FormItem className="space-y-3">
                <FormLabel>Have you experienced any significant weight changes in the past 6 months?</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="flex flex-col space-y-2"
                  >
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="significant-loss" />
                      </FormControl>
                      <FormLabel className="font-normal">Yes, significant weight loss</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="some-loss" />
                      </FormControl>
                      <FormLabel className="font-normal">Yes, some weight loss</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="significant-gain" />
                      </FormControl>
                      <FormLabel className="font-normal">Yes, significant weight gain</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="some-gain" />
                      </FormControl>
                      <FormLabel className="font-normal">Yes, some weight gain</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-3 space-y-0">
                      <FormControl>
                        <RadioGroupItem value="no-change" />
                      </FormControl>
                      <FormLabel className="font-normal">No significant change</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="mt-6 w-full md:w-auto bg-primary hover:bg-primary-dark"
          >
            Continue
          </Button>
        </form>
      </Form>
    </div>
  );
}
