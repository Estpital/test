import { useRef, useState } from "react";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { ImagePlus, X } from "lucide-react";

interface Step5Props {
  formData: any;
  updateFormData: (data: any) => void;
  nextStep: () => void;
}

const formSchema = z.object({
  photoUrls: z.array(z.string()).optional(),
});

export default function Step5PhotoUpload({ formData, updateFormData, nextStep }: Step5Props) {
  const [photos, setPhotos] = useState<{ [key: string]: string }>({
    crown: formData.photoUrls?.includes("crown") ? "crown" : "",
    hairline: formData.photoUrls?.includes("hairline") ? "hairline" : "",
    scalp: formData.photoUrls?.includes("scalp") ? "scalp" : "",
  });
  
  const fileInputRefs = {
    crown: useRef<HTMLInputElement>(null),
    hairline: useRef<HTMLInputElement>(null),
    scalp: useRef<HTMLInputElement>(null),
  };
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      photoUrls: formData.photoUrls || [],
    },
  });
  
  const onSubmit = () => {
    const photoUrlsArray = Object.values(photos).filter(Boolean);
    updateFormData({ photoUrls: photoUrlsArray });
    nextStep();
  };
  
  const handleFileChange = (type: string, event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      // In a real app, we would upload the file to a server here
      // and get back a URL to store. For this demo, we'll just store the type
      
      // Simulate a file upload by setting the photo type
      const updatedPhotos = { ...photos };
      updatedPhotos[type] = type;
      setPhotos(updatedPhotos);
      
      // Update form value
      const photoUrlsArray = Object.values(updatedPhotos).filter(Boolean);
      form.setValue("photoUrls", photoUrlsArray);
    }
  };
  
  const removePhoto = (type: string) => {
    const updatedPhotos = { ...photos };
    updatedPhotos[type] = "";
    setPhotos(updatedPhotos);
    
    // Reset the file input
    if (fileInputRefs[type as keyof typeof fileInputRefs]?.current) {
      fileInputRefs[type as keyof typeof fileInputRefs].current!.value = "";
    }
    
    // Update form value
    const photoUrlsArray = Object.values(updatedPhotos).filter(Boolean);
    form.setValue("photoUrls", photoUrlsArray);
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Upload Photos</h2>
      <p className="text-gray-600 mb-6">
        Please upload clear photos of your scalp and hair condition to help our experts 
        provide a more accurate analysis.
      </p>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <div className="space-y-8">
            <FormField
              control={form.control}
              name="photoUrls"
              render={() => (
                <FormItem>
                  <div className="space-y-8">
                    <div>
                      <FormLabel>Top of head (crown area)</FormLabel>
                      <div 
                        className={`mt-3 border-2 border-dashed rounded-lg p-6 text-center transition cursor-pointer 
                        ${photos.crown ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-primary'}`}
                        onClick={() => fileInputRefs.crown.current?.click()}
                      >
                        <input 
                          type="file" 
                          ref={fileInputRefs.crown}
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => handleFileChange('crown', e)}
                        />
                        
                        {photos.crown ? (
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                              <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                              </svg>
                            </div>
                            <p className="text-sm text-gray-700">Image uploaded successfully</p>
                            <button 
                              type="button"
                              className="mt-2 inline-flex items-center text-sm text-red-600 hover:text-red-800"
                              onClick={(e) => {
                                e.stopPropagation();
                                removePhoto('crown');
                              }}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </button>
                          </div>
                        ) : (
                          <>
                            <ImagePlus className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                            <p className="text-xs text-gray-400 mt-1">PNG, JPG or JPEG (max. 5MB)</p>
                          </>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <FormLabel>Frontal hairline</FormLabel>
                      <div 
                        className={`mt-3 border-2 border-dashed rounded-lg p-6 text-center transition cursor-pointer 
                        ${photos.hairline ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-primary'}`}
                        onClick={() => fileInputRefs.hairline.current?.click()}
                      >
                        <input 
                          type="file" 
                          ref={fileInputRefs.hairline}
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => handleFileChange('hairline', e)}
                        />
                        
                        {photos.hairline ? (
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                              <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                              </svg>
                            </div>
                            <p className="text-sm text-gray-700">Image uploaded successfully</p>
                            <button 
                              type="button"
                              className="mt-2 inline-flex items-center text-sm text-red-600 hover:text-red-800"
                              onClick={(e) => {
                                e.stopPropagation();
                                removePhoto('hairline');
                              }}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </button>
                          </div>
                        ) : (
                          <>
                            <ImagePlus className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                            <p className="text-xs text-gray-400 mt-1">PNG, JPG or JPEG (max. 5MB)</p>
                          </>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <FormLabel>Close-up of scalp (optional)</FormLabel>
                      <div 
                        className={`mt-3 border-2 border-dashed rounded-lg p-6 text-center transition cursor-pointer 
                        ${photos.scalp ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-primary'}`}
                        onClick={() => fileInputRefs.scalp.current?.click()}
                      >
                        <input 
                          type="file" 
                          ref={fileInputRefs.scalp}
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => handleFileChange('scalp', e)}
                        />
                        
                        {photos.scalp ? (
                          <div className="flex flex-col items-center">
                            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-2">
                              <svg className="w-8 h-8 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                              </svg>
                            </div>
                            <p className="text-sm text-gray-700">Image uploaded successfully</p>
                            <button 
                              type="button"
                              className="mt-2 inline-flex items-center text-sm text-red-600 hover:text-red-800"
                              onClick={(e) => {
                                e.stopPropagation();
                                removePhoto('scalp');
                              }}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Remove
                            </button>
                          </div>
                        ) : (
                          <>
                            <ImagePlus className="h-10 w-10 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                            <p className="text-xs text-gray-400 mt-1">PNG, JPG or JPEG (max. 5MB)</p>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <Button 
            type="submit" 
            className="mt-6 w-full md:w-auto bg-primary hover:bg-primary-dark"
          >
            Continue
          </Button>
        </form>
      </Form>
    </div>
  );
}
