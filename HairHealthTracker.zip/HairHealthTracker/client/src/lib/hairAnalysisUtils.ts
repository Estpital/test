// This file contains utility functions for the hair analysis

/**
 * Formats a treatment object into a user-friendly string
 */
export function formatTreatment(treatment: any): string {
  if (!treatment) return "No treatment information available";
  
  return `${treatment.name}: ${treatment.description}`;
}

/**
 * Calculates a similarity score between two hair analysis results
 * This could be used to compare a new analysis with existing ones
 */
export function calculateSimilarityScore(analysis1: any, analysis2: any): number {
  if (!analysis1 || !analysis2) return 0;
  
  let score = 0;
  let totalFactors = 0;
  
  // Compare basic info
  if (analysis1.age === analysis2.age) score++;
  if (analysis1.gender === analysis2.gender) score++;
  if (analysis1.hairLoss === analysis2.hairLoss) score++;
  if (analysis1.hairLossTime === analysis2.hairLossTime) score++;
  totalFactors += 4;
  
  // Compare hair loss pattern
  if (analysis1.pattern === analysis2.pattern) score++;
  if (analysis1.familyHistory === analysis2.familyHistory) score++;
  totalFactors += 2;
  
  // Compare scalp condition
  if (analysis1.scalpCondition === analysis2.scalpCondition) score++;
  if (analysis1.washFrequency === analysis2.washFrequency) score++;
  totalFactors += 2;
  
  // Compare scalp issues and health conditions (these are comma-separated strings)
  const scalpIssues1 = analysis1.scalpIssues.split(',');
  const scalpIssues2 = analysis2.scalpIssues.split(',');
  const healthConditions1 = analysis1.healthConditions.split(',');
  const healthConditions2 = analysis2.healthConditions.split(',');
  
  const commonScalpIssues = scalpIssues1.filter(issue => scalpIssues2.includes(issue)).length;
  const commonHealthConditions = healthConditions1.filter(condition => 
    healthConditions2.includes(condition)).length;
  
  score += (commonScalpIssues / Math.max(scalpIssues1.length, scalpIssues2.length));
  score += (commonHealthConditions / Math.max(healthConditions1.length, healthConditions2.length));
  totalFactors += 2;
  
  // Return percentage similarity
  return (score / totalFactors) * 100;
}

/**
 * Generate a summary description based on the analysis results
 */
export function generateSummary(analysis: any): string {
  if (!analysis || !analysis.analysisResults) {
    return "Analysis not available";
  }
  
  const { pattern, factors, progression } = analysis.analysisResults;
  
  let summary = `You appear to have ${pattern.toLowerCase()}. `;
  
  if (factors && factors.length > 0) {
    summary += `Contributing factors include ${factors.join(', ')}. `;
  }
  
  summary += progression;
  
  return summary;
}
