import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle } from "lucide-react";

export default function AnalysisResults() {
  const [match, params] = useRoute("/results/:id");
  const [, setLocation] = useLocation();
  const id = params?.id;
  
  const { data: analysis, isLoading, error } = useQuery({
    queryKey: [`/api/hair-analysis/${id}`],
    enabled: !!id,
    retry: 3,
    staleTime: 60000
  });
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <Skeleton className="h-16 w-16 rounded-full mx-auto mb-4" />
            <Skeleton className="h-8 w-64 mx-auto mb-2" />
            <Skeleton className="h-4 w-80 mx-auto" />
          </div>
          
          <Skeleton className="h-64 w-full mb-8 rounded-lg" />
          
          <Skeleton className="h-8 w-48 mb-4" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Skeleton className="h-64 w-full rounded-lg" />
            <Skeleton className="h-64 w-full rounded-lg" />
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !analysis) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-md mx-auto">
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-red-600">Error Loading Results</h2>
              <p className="text-gray-600 mt-2">
                We couldn't load your analysis results. Please try again later.
              </p>
            </div>
            <Button 
              className="w-full" 
              onClick={() => setLocation("/")}
            >
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500 text-white mb-4">
            <CheckCircle className="h-8 w-8" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Analysis Complete!</h2>
          <p className="text-gray-600">Based on your answers, we've prepared a personalized assessment of your hair condition and recommended treatments.</p>
        </div>
        
        <div className="bg-blue-50 rounded-lg p-6 mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-3">Your Hair Analysis Results</h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-800">Hair Loss Pattern</h4>
              <p className="text-gray-600">{analysis.analysisResults?.pattern || "No pattern detected"}</p>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-800">Contributing Factors</h4>
              {analysis.analysisResults?.factors && analysis.analysisResults.factors.length > 0 ? (
                <ul className="list-disc ml-5 text-gray-600 space-y-1">
                  {analysis.analysisResults.factors.map((factor: string, index: number) => (
                    <li key={index}>{factor}</li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-600">No significant contributing factors identified</p>
              )}
            </div>
            
            <div>
              <h4 className="font-medium text-gray-800">Hair Loss Progression</h4>
              <p className="text-gray-600">{analysis.analysisResults?.progression || "Unable to determine progression"}</p>
            </div>
          </div>
        </div>
        
        <h3 className="text-xl font-bold text-gray-900 mb-4">Recommended Treatments</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {analysis.recommendedTreatments && analysis.recommendedTreatments.length > 0 ? (
            analysis.recommendedTreatments.map((treatment: any) => (
              <div key={treatment.id} className="border rounded-lg overflow-hidden">
                <img src={treatment.imageUrl} alt={treatment.name} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <h4 className="font-bold text-gray-800 mb-2">{treatment.name}</h4>
                  <p className="text-gray-600 text-sm mb-3">{treatment.description}</p>
                  <Button variant="link" className="p-0 h-auto text-primary font-medium text-sm">
                    Learn more
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-center py-8">
              <p className="text-gray-600">No specific treatments recommended at this time.</p>
            </div>
          )}
        </div>
        
        <div className="bg-gray-50 rounded-lg p-6 mb-6">
          <h3 className="text-lg font-bold text-gray-900 mb-3">Next Steps</h3>
          <p className="text-gray-600 mb-4">Schedule a free consultation with one of our hair specialists to discuss your personalized treatment plan in detail.</p>
          <Button size="lg" className="w-full sm:w-auto">
            Book Free Consultation
          </Button>
        </div>
        
        <div className="text-center mt-8">
          <p className="text-gray-500 text-sm">A detailed copy of your hair analysis has been sent to your email.</p>
          <p className="text-gray-500 text-sm">If you have any questions, please contact us at <a href="mailto:info@elihair.com" className="text-primary hover:underline">info@elihair.com</a></p>
        </div>
      </div>
    </div>
  );
}
