import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Stripe public key
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY as string);

// Ödeme formu bileşeni
const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setPaymentError("");

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/payment-success`,
      },
    });

    if (error) {
      setPaymentError(error.message || "Ödeme işlemi başarısız oldu.");
      toast({
        title: "Ödeme Başarısız",
        description: error.message || "Ödeme işlemi sırasında bir hata oluştu. Lütfen tekrar deneyin.",
        variant: "destructive",
      });
    }

    setIsProcessing(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <PaymentElement />
        
        {paymentError && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-md text-sm">
            {paymentError}
          </div>
        )}
      </div>

      <Button 
        disabled={!stripe || isProcessing} 
        className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600"
        type="submit"
      >
        {isProcessing ? "İşleniyor..." : "Ödemeyi Tamamla"}
      </Button>
    </form>
  );
};

// Ana ödeme sayfası bileşeni
export default function Checkout() {
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState("");
  const [cartItems, setCartItems] = useState<any[]>([]);
  const [contactInfo, setContactInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    zipCode: "",
  });
  const [isContactInfoComplete, setIsContactInfoComplete] = useState(false);

  // Sepet öğelerini ve iletişim bilgilerini yerel depodan yükleme
  useEffect(() => {
    // Sepet öğelerini yükle
    const savedCart = localStorage.getItem("cart");
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    } else {
      // Sepet boşsa anasayfaya yönlendir
      window.location.href = "/shop";
    }

    // Kayıtlı iletişim bilgilerini yükle
    const savedContactInfo = localStorage.getItem("contactInfo");
    if (savedContactInfo) {
      setContactInfo(JSON.parse(savedContactInfo));
    }
  }, []);

  // İletişim bilgilerinin tam olup olmadığını kontrol et
  useEffect(() => {
    const { firstName, lastName, email, phone, address, city, zipCode } = contactInfo;
    
    if (firstName && lastName && email && phone && address && city && zipCode) {
      setIsContactInfoComplete(true);
    } else {
      setIsContactInfoComplete(false);
    }
  }, [contactInfo]);

  // İletişim bilgilerini güncelleme
  const handleContactInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setContactInfo(prev => ({
      ...prev,
      [name]: value
    }));

    // İletişim bilgilerini yerel depoda sakla
    localStorage.setItem("contactInfo", JSON.stringify({
      ...contactInfo,
      [name]: value
    }));
  };

  // Sepetteki toplam fiyatı hesaplama
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  // Ödeme niyeti oluşturma
  const createPaymentIntent = async () => {
    if (cartItems.length === 0) return;

    try {
      const response = await apiRequest("POST", "/api/create-payment-intent", {
        amount: calculateTotal(),
        items: cartItems
      });
      
      const data = await response.json();
      setClientSecret(data.clientSecret);
    } catch (error) {
      toast({
        title: "Hata",
        description: "Ödeme işlemi başlatılırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-100 py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">Ödeme Sayfası</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Sol Sütun - Ürün Özeti */}
            <div className="md:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Sipariş Özeti</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cartItems.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">Sepetinizde ürün bulunmamaktadır.</p>
                  ) : (
                    <>
                      <div className="max-h-72 overflow-y-auto space-y-4">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex gap-3 pb-3 border-b">
                            <img 
                              src={item.image} 
                              alt={item.name} 
                              className="w-16 h-16 object-cover rounded"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = "https://placehold.co/400x400?text=Must+De+Qen";
                              }}
                            />
                            <div className="flex-1">
                              <p className="text-sm font-medium">{item.name}</p>
                              <div className="flex justify-between text-sm text-gray-500 mt-1">
                                <span>{item.quantity} adet</span>
                                <span>{item.price * item.quantity} TL</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="pt-4 border-t space-y-2">
                        <div className="flex justify-between text-gray-600">
                          <span>Ara Toplam</span>
                          <span>{calculateTotal()} TL</span>
                        </div>
                        <div className="flex justify-between text-gray-600">
                          <span>Kargo</span>
                          <span>{calculateTotal() >= 1000 ? "Ücretsiz" : "35 TL"}</span>
                        </div>
                        <div className="flex justify-between font-bold text-lg">
                          <span>Toplam</span>
                          <span>{calculateTotal() >= 1000 ? calculateTotal() : calculateTotal() + 35} TL</span>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
            
            {/* Sağ Sütun - İletişim Bilgileri ve Ödeme */}
            <div className="md:col-span-2">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>İletişim ve Teslimat Bilgileri</CardTitle>
                  <CardDescription>Lütfen kargo teslimatı için bilgilerinizi girin</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">Ad</Label>
                      <Input 
                        id="firstName" 
                        name="firstName" 
                        placeholder="Adınız" 
                        value={contactInfo.firstName}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Soyad</Label>
                      <Input 
                        id="lastName" 
                        name="lastName" 
                        placeholder="Soyadınız" 
                        value={contactInfo.lastName}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-posta</Label>
                      <Input 
                        id="email" 
                        name="email" 
                        type="email" 
                        placeholder="E-posta adresiniz" 
                        value={contactInfo.email}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefon</Label>
                      <Input 
                        id="phone" 
                        name="phone" 
                        placeholder="Telefon numaranız" 
                        value={contactInfo.phone}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="address">Adres</Label>
                      <Input 
                        id="address" 
                        name="address" 
                        placeholder="Teslimat adresi" 
                        value={contactInfo.address}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Şehir</Label>
                      <Input 
                        id="city" 
                        name="city" 
                        placeholder="Şehir" 
                        value={contactInfo.city}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zipCode">Posta Kodu</Label>
                      <Input 
                        id="zipCode" 
                        name="zipCode" 
                        placeholder="Posta kodu" 
                        value={contactInfo.zipCode}
                        onChange={handleContactInfoChange}
                        required
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={createPaymentIntent}
                    disabled={!isContactInfoComplete || cartItems.length === 0}
                    className="w-full bg-teal-600 hover:bg-teal-700"
                  >
                    Ödeme Bilgilerini Göster
                  </Button>
                </CardFooter>
              </Card>
              
              {clientSecret && (
                <Card>
                  <CardHeader>
                    <CardTitle>Ödeme Bilgileri</CardTitle>
                    <CardDescription>Güvenli ödeme işlemi için kart bilgilerinizi girin</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Elements stripe={stripePromise} options={{ clientSecret, locale: 'tr' }}>
                      <CheckoutForm />
                    </Elements>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}