import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function FaceLift() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Yüz%20germe%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-purple-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-pink-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">
                  Yüz Germe
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Modern Tekniklerle Gençleşme ve Doğal Sonuçlar
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde, hastane ortamında, 
                  yüz germe operasyonları ile yaşlanma belirtilerini azaltırken doğal ve genç 
                  bir görünüm elde ediyoruz. Minimal izler ve hızlı iyileşme süreleri 
                  ile yenilenmiş bir görünüme kavuşun.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-pink-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/dr-ummahan-ozaslan.jpg" 
                        alt="Doç. Dr. Ummahan Özaslan" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Modern Teknik</h3>
                        </div>
                        <p className="text-sm text-gray-600">Minimal izlerle doğal sonuçlar</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 15.5l-6-2.25L9 15.5m12-4.5v6.75a2.25 2.25 0 01-2.25 2.25h-15A2.25 2.25 0 011.5 17.75V11m12 4.5A4.5 4.5 0 0117.25 11h1.5a4.5 4.5 0 014.5 4.5m-9-11L12 2m0 0L9.75 4.5M12 2v5.5"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Konforlu İşlem</h3>
                        </div>
                        <p className="text-sm text-gray-600">Hızlı iyileşme süreci</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </section>

      {/* Yüz Germe Teknikleri Açıklaması */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                İLERİ YÜZ GERME TEKNİKLERİ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Modern Yüz Germe Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Yüz germe operasyonlarında kullanılan ileri teknikler, minimal iz ve doğal sonuçlar elde
                etmeyi sağlar. Hasta anatomisine uygun teknik seçimi ile en iyi sonuçları hedefliyoruz.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <img 
                  src="/facelift-technique.jpg" 
                  alt="Yüz Germe Teknikleri" 
                  className="rounded-lg shadow-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1527613426441-4da17471b66d?q=80&w=1452&auto=format&fit=crop";
                  }}
                />
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-6 text-purple-700">
                  Yüz Germe Tekniklerinin Avantajları
                </h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">SMAS (Yüzeysel Müsküloponörotik Sistem) Tekniği ile daha <strong>uzun süre kalıcı</strong> ve doğal sonuçlar</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Kişiye özel planlama ile her hastaya <strong>uygun teknik</strong> seçimi yapılır</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Endoskopik yöntemlerle <strong>daha az kesik</strong> ve hızlı iyileşme sağlanır</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Derin plan yüz germe tekniği ile sadece yüzeysel değil, <strong>derin dokularda da gençleşme</strong> sağlanır</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">İyileşme sonrası <strong>doğal görünüm</strong> ile yüz ifadeleriniz korunur</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-purple-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700"><strong>Boyun germe</strong> ve çene hattı düzeltme ile tam bir yenilenme sağlanır</span>
                  </li>
                </ul>

                <div className="mt-8 bg-purple-50 p-6 rounded-lg border border-purple-100">
                  <h4 className="font-semibold text-purple-700 mb-3">Yüz Germe vs. Non-Cerrahi Yöntemler</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-medium text-sm mb-2 text-purple-800">Yüz Germe</h5>
                      <ul className="text-sm space-y-2">
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-purple-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Uzun süreli kalıcılık</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-purple-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Belirgin gençleşme</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-purple-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Tek seansta sonuç</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-purple-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>8-10 yıl etkili</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-2 text-gray-600">Non-Cerrahi Yöntemler</h5>
                      <ul className="text-sm space-y-2">
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-gray-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Kısa süreli etki</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-gray-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Sınırlı iyileşme</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-gray-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Tekrarlayan seanslar</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-gray-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>6-12 ay etkili</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fiyat Karşılaştırma Bölümü */}
      <section className="py-16 bg-gradient-to-b from-purple-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ŞEFFAF FİYATLANDIRMA
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Kaliteli Hizmetin Karşılaştırması
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Bizim sunduğumuz premium yüz germe hizmeti ile piyasadaki diğer seçenekleri karşılaştırın.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-3">
                {/* Premium Hizmet - Estpital */}
                <div className="p-8 border-b md:border-b-0 md:border-r border-gray-200 bg-gradient-to-br from-purple-50 to-white">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-purple-700 mb-2">Estpital Premium</h3>
                    <div className="text-4xl font-bold text-gray-900 mb-6">70.000 TL</div>
                    <div className="text-sm text-gray-600 mb-2">Tam kapsamlı premium hizmet</div>
                    <span className="inline-block bg-purple-600 text-white text-xs px-3 py-1 rounded-full mb-6">ÖNERİLEN</span>
                  </div>
                  
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Doç. Dr. Ummahan Özaslan</strong> tarafından operasyon</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>SMAS</strong> derin plan yüz germe tekniği</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Anestezi doktoru</strong> süreç dahiliyeti</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>JCI akredite</strong> hastanede operasyon</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>2 gün</strong> hastanede konaklama</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>VIP hemşire</strong> hizmeti</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>PRP ve mezoterapi</strong> uygulamaları</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>1 yıl</strong> ücretsiz kontrol ve bakım</span>
                    </li>
                  </ul>
                  
                  <div className="mt-8 text-center">
                    <button 
                      onClick={redirectToWhatsApp}
                      className="w-full px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold"
                    >
                      Ücretsiz Konsültasyon
                    </button>
                  </div>
                </div>
                
                {/* Orta Kalite Hizmet */}
                <div className="p-8 border-b md:border-b-0 md:border-r border-gray-200">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-gray-700 mb-2">Orta Segment</h3>
                    <div className="text-4xl font-bold text-gray-900 mb-6">40.000 TL</div>
                    <div className="text-sm text-gray-600 mb-6">Sınırlı özelliklerle orta kalite</div>
                  </div>
                  
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">Uzman doktor operasyonu</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">Temel yüz germe teknikleri</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">Anestezi doktoru desteği</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">Özel hastanede operasyon</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">1 gün konaklama</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">VIP hemşire hizmeti yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">PRP ve mezoterapi yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-yellow-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                      </svg>
                      <span className="text-gray-500">6 ay kontrol ve bakım</span>
                    </li>
                  </ul>
                </div>
                
                {/* Düşük Kalite / Merdiven Altı */}
                <div className="p-8 bg-gradient-to-br from-gray-50 to-white">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-gray-700 mb-2">Düşük Segment</h3>
                    <div className="text-4xl font-bold text-gray-900 mb-6">20.000 TL</div>
                    <div className="text-sm text-gray-600 mb-2">Düşük kalite ve riskli işlem</div>
                    <span className="inline-block bg-red-600 text-white text-xs px-3 py-1 rounded-full mb-6">RİSKLİ</span>
                  </div>
                  
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Uzman olmayan doktor</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Basit cilt germe tekniği</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Anestezi doktoru yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Klinik ortamında operasyon</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Ayakta tedavi</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">VIP hemşire hizmeti yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">PRP ve mezoterapi yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Yetersiz takip hizmeti</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Öncesi ve Sonrası */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                GERÇEK SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Hastalarımızın yüz germe operasyonu öncesi ve sonrası fotoğrafları, 
                tekniklerimizin etkinliğini net bir şekilde göstermektedir.
              </p>
            </div>

            <Tabs defaultValue="case1" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="case1">Vaka 1</TabsTrigger>
                <TabsTrigger value="case2">Vaka 2</TabsTrigger>
                <TabsTrigger value="case3">Vaka 3</TabsTrigger>
              </TabsList>
              
              <TabsContent value="case1">
                <Card>
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Önce</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-before1.jpg" 
                            alt="Yüz Germe Öncesi" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=1528&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Sonra</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-after1.jpg" 
                            alt="Yüz Germe Sonrası" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1638277267352-bce68a3e4dca?q=80&w=1527&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold mb-2 text-purple-700">54 yaşında kadın hasta</h3>
                      <p className="text-gray-700">
                        SMAS tekniği ile yüz ve boyun germe operasyonu uygulanmıştır. Çene hattının belirginleştiği, 
                        boyun bölgesindeki sarkmış cildin toparlandığı ve yüzün daha genç bir görünüm kazandığı 
                        görülmektedir. Hasta, operasyon sonrası 10 gün içinde günlük yaşamına dönebilmiştir.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="case2">
                <Card>
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Önce</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-before2.jpg" 
                            alt="Yüz Germe Öncesi" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=1374&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Sonra</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-after2.jpg" 
                            alt="Yüz Germe Sonrası" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1595703013566-db8ea75d8f28?q=80&w=1470&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold mb-2 text-purple-700">60 yaşında kadın hasta</h3>
                      <p className="text-gray-700">
                        Derin plan yüz germe tekniği ile kombine boyun germe işlemi uygulanmıştır. 
                        Yüz hatlarının daha belirgin hale geldiği, nazolabial kıvrımların azaldığı ve 
                        boyun bölgesindeki sarkmaların tamamen düzeldiği görülmektedir. 
                        Hasta, operasyon sonrası 3. haftada tamamen normal görünümüne kavuşmuştur.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="case3">
                <Card>
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Önce</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-before3.jpg" 
                            alt="Yüz Germe Öncesi" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1542596768-5d1d21f1cf98?q=80&w=1374&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                      <div className="p-4">
                        <h3 className="text-xl font-bold mb-2 text-gray-800">Sonra</h3>
                        <div className="aspect-square overflow-hidden rounded-lg">
                          <img 
                            src="/facelift-after3.jpg" 
                            alt="Yüz Germe Sonrası" 
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1376&auto=format&fit=crop";
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold mb-2 text-purple-700">58 yaşında kadın hasta</h3>
                      <p className="text-gray-700">
                        Mini facelift ve SMAS germe tekniği kombine edilmiştir. Hasta, 
                        minimal iz ve kısa iyileşme süreci ile yüzünde gençleşme elde etmiştir. 
                        Özellikle orta yüz bölgesinde daha dolgun ve gergin bir görünüm sağlanmıştır. 
                        Hasta, operasyon sonrası 2 hafta içinde sosyal hayatına dönebilmiştir.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* SSS */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Yüz Germe Hakkında Merak Edilenler
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Yüz germe operasyonu öncesi ve sonrası hakkında en çok sorulan soruların cevaplarını bulabilirsiniz.
              </p>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Yüz germe operasyonu ne kadar sürer?</h3>
                <p className="text-gray-700">
                  Yüz germe operasyonu, uygulanacak tekniğe ve kapsamına bağlı olarak genellikle 2-4 saat 
                  arasında sürmektedir. Mini yüz germe işlemleri daha kısa sürerken, boyun germe ve SMAS 
                  gibi kapsamlı işlemler daha uzun sürebilir.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">İyileşme süreci nasıldır?</h3>
                <p className="text-gray-700">
                  İlk 7-10 gün içinde hafif şişlik ve morluklar olması normaldir. Dikişler genellikle 
                  5-7 gün içinde alınır. Sosyal hayata dönüş yaklaşık 2 hafta sürerken, tam iyileşme 
                  4-6 hafta içinde tamamlanır. İlk birkaç ay boyunca hafif gerginlik hissi devam edebilir.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Yüz germe operasyonu izleri görünür mü?</h3>
                <p className="text-gray-700">
                  Modern tekniklerle yapılan yüz germe operasyonlarında izler saç çizgisi içinde ve kulak 
                  arkasına gizlenir. Zamanla bu izler soluklaşır ve neredeyse görünmez hale gelir. 
                  Doç. Dr. Ummahan Özaslan'ın kullandığı özel sütür teknikleri ile minimal iz bırakılmaktadır.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Yüz germe operasyonu sonuçları ne kadar kalıcıdır?</h3>
                <p className="text-gray-700">
                  Yüz germe operasyonunun etkileri genellikle 8-10 yıl sürer. Ancak bu, kişinin cilt yapısına, 
                  yaşam tarzına, genetik faktörlere ve bakımına bağlı olarak değişebilir. Sigara kullanımı, 
                  güneşe maruz kalma ve kilo dalgalanmaları sonuçların kalıcılığını olumsuz etkileyebilir.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Yüz germe operasyonu için ideal yaş nedir?</h3>
                <p className="text-gray-700">
                  İdeal yaş aralığı genellikle 45-65 arası olsa da, kişinin cilt yapısı ve yaşlanma belirtileri 
                  daha önemlidir. Bazı hastalar 40'lı yaşlarda işlem yaptırırken, bazıları 70'li yaşlarda da 
                  başarılı sonuçlar elde edebilir. Kişiye özel değerlendirme yapılarak en doğru zamanlama belirlenir.
                </p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Operasyon sonrası yüzüm doğal görünecek mi?</h3>
                <p className="text-gray-700">
                  Doç. Dr. Ummahan Özaslan'ın uyguladığı modern teknikler, yüzünüzün gergin veya "ameliyatlı" 
                  görünmesi yerine, doğal ve dinlenmiş bir görünüm elde etmenizi sağlar. Amaç yüzünüzü değiştirmek 
                  değil, daha genç ve dinlenmiş bir haline döndürmektir.
                </p>
              </div>
            </div>
            
            <div className="mt-12 text-center">
              <p className="text-lg text-gray-700 mb-6">
                Başka sorularınız mı var? Ücretsiz konsültasyon ile tüm sorularınızı yanıtlayalım.
              </p>
              <Button 
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={redirectToWhatsApp}
              >
                WhatsApp ile İletişime Geçin
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Form Bölümü */}
      <section className="py-16 bg-gradient-to-b from-purple-50 to-white" id="contact-form">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="bg-gradient-to-br from-purple-600 to-pink-600 p-12 text-white">
                  <h2 className="text-3xl font-bold mb-6">İletişim</h2>
                  <p className="mb-8">
                    Yüz germe operasyonu hakkında bilgi almak ve özel durumunuza uygun çözümler için 
                    bizimle iletişime geçin. Size en kısa sürede dönüş yapacağız.
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <svg className="w-6 h-6 mr-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                      </svg>
                      <div>
                        <h3 className="font-semibold">Telefon</h3>
                        <p>+90 544 107 25 70</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <svg className="w-6 h-6 mr-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                      </svg>
                      <div>
                        <h3 className="font-semibold">E-posta</h3>
                        <p>info@estpital.com</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <svg className="w-6 h-6 mr-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                      </svg>
                      <div>
                        <h3 className="font-semibold">Adres</h3>
                        <p>Kozyatağı Mah. Değirmen Sok. No:18/B Kadıköy/İstanbul</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-10">
                    <h3 className="font-semibold mb-3">Bizi Takip Edin</h3>
                    <div className="flex space-x-4">
                      <a href="#" className="text-white hover:text-purple-200 transition-colors">
                        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"></path>
                        </svg>
                      </a>
                      <a href="#" className="text-white hover:text-purple-200 transition-colors">
                        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"></path>
                        </svg>
                      </a>
                      <a href="#" className="text-white hover:text-purple-200 transition-colors">
                        <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"></path>
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>
                
                <div className="p-12">
                  <h2 className="text-3xl font-bold text-gray-900 mb-6">Bize Yazın</h2>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Ad Soyad</label>
                        <input 
                          type="text" 
                          id="name" 
                          className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500" 
                          placeholder="Adınız Soyadınız"
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                        <input 
                          type="tel" 
                          id="phone" 
                          className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500" 
                          placeholder="05XX XXX XX XX"
                        />
                      </div>
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">E-posta</label>
                      <input 
                        type="email" 
                        id="email" 
                        className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500" 
                        placeholder="ornek@email.com"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Mesajınız</label>
                      <textarea 
                        id="message" 
                        rows={5}
                        className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500" 
                        placeholder="Mesajınızı yazın..."
                      ></textarea>
                    </div>
                    <div>
                      <Button 
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 rounded-md transition-colors"
                        onClick={(e) => {
                          e.preventDefault();
                          redirectToWhatsApp();
                        }}
                      >
                        Gönder
                      </Button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}