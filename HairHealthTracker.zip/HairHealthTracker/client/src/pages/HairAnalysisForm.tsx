import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import MultiStepForm from "@/components/MultiStepForm";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function HairAnalysisForm() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [formVisible, setFormVisible] = useState(false);
  
  useEffect(() => {
    // Show the form with a slight delay for animation
    const timer = setTimeout(() => {
      setFormVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  const submitAnalysisMutation = useMutation({
    mutationFn: async (formData: any) => {
      const response = await apiRequest('POST', '/api/hair-analysis', formData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Analysis submitted successfully",
        description: "Your hair analysis has been submitted. Redirecting to results...",
      });
      
      // Navigate to results page after a brief delay
      setTimeout(() => {
        setLocation(`/results/${data.id}`);
      }, 1500);
    },
    onError: (error) => {
      toast({
        title: "Submission failed",
        description: error.message || "There was an error submitting your hair analysis. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  const handleSubmit = async (formData: any) => {
    submitAnalysisMutation.mutate(formData);
  };
  
  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className={`max-w-4xl mx-auto transition-opacity duration-500 ${formVisible ? 'opacity-100' : 'opacity-0'}`}>
          <MultiStepForm onSubmit={handleSubmit} isSubmitting={submitAnalysisMutation.isPending} />
        </div>
      </div>
    </section>
  );
}
