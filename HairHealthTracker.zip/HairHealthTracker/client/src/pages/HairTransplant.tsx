import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import VideoSection from "@/components/VideoSection";

export default function HairTransplant() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Saç%20ekimi%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-teal-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-blue-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-teal-600 to-blue-600">
                  Saç Ekimi
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Sedasyonlu DHI Tekniği ile Ağrısız ve Doğal Sonuçlar
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Dr. Gizem Kağıtçı yönetiminde, hastane ortamında, derin uyku yöntemi 
                  ile ağrısız saç ekimi operasyonları gerçekleştiriyoruz. DHI (Direct Hair Implantation) 
                  tekniği ile daha hızlı iyileşme ve daha doğal sonuçlar elde ediyoruz.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-teal-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/dr-gizem-kagitci.jpg" 
                        alt="Dr. Gizem Kağıtçı" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=1374&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">DHI Tekniği</h3>
                        </div>
                        <p className="text-sm text-gray-600">Kanal açmadan doğal sonuçlar</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 15.5l-6-2.25L9 15.5m12-4.5v6.75a2.25 2.25 0 01-2.25 2.25h-15A2.25 2.25 0 011.5 17.75V11m12 4.5A4.5 4.5 0 0117.25 11h1.5a4.5 4.5 0 014.5 4.5m-9-11L12 2m0 0L9.75 4.5M12 2v5.5"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Derin Uyku</h3>
                        </div>
                        <p className="text-sm text-gray-600">Ağrısız işlem</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </section>

      {/* DHI Yöntemi Açıklaması */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                EN GELİŞMİŞ TEKNOLOJİ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                DHI Saç Ekimi Tekniği
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                DHI (Direct Hair Implantation) tekniği, saç ekiminde en gelişmiş ve doğal sonuçlar veren yöntemdir. 
                Geleneksel FUE yöntemine göre birçok üstünlük sağlayan bu teknik, saç ekiminde devrim yaratmıştır.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <img 
                  src="/dhi-technique.jpg" 
                  alt="DHI Saç Ekimi Tekniği" 
                  className="rounded-lg shadow-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1661442366637-3c2746963fbd?q=80&w=1632&auto=format&fit=crop";
                  }}
                />
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-6 text-teal-700">
                  DHI Tekniğinin Benzersiz Avantajları
                </h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Her seansta <strong>15-20%</strong> daha fazla greft ekimi yapılabilir, bu da daha yoğun bir saç çıkışı sağlar</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Daha sık ekim yapılabildiği için <strong>tamamen doğal</strong> ve fark edilmeyen sonuçlar elde edilir</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Saç derisinde <strong>kanal açma zorunluluğu olmadığı için</strong> saçların yönü ve açısı tam olarak kontrol edilebilir, böylece doğal saç çıkış yönleri sağlanır</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Kanama riski bulunmadığından <strong>adrenalin</strong> gibi kan dolaşımını baskılayıcı ilaçlar kullanılmaz, böylece saç kökleri daha sağlıklı beslenebilir</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700"><strong>İyileşme süreci çok hızlıdır</strong>, operasyon sonrası ağrı, kanama ve şişlik minimumdur, sosyal hayata dönüş çok daha erkendir</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Nekroz ve doku kaybı gibi <strong>FUE'de görülebilen riskler DHI tekniğinde yoktur</strong></span>
                  </li>
                </ul>

                <div className="mt-8 bg-teal-50 p-6 rounded-lg border border-teal-100">
                  <h4 className="font-semibold text-teal-700 mb-3">DHI vs. FUE Karşılaştırması</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-medium text-sm mb-2 text-teal-800">DHI Tekniği</h5>
                      <ul className="text-sm space-y-2">
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-teal-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Daha yoğun ekim</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-teal-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Daha az travma</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-teal-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>Daha hızlı iyileşme</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-teal-500 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                          </svg>
                          <span>%95+ yaşama oranı</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-2 text-gray-600">FUE Tekniği</h5>
                      <ul className="text-sm space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-red-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Daha seyrek ekim</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-red-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Kanal açma gerekli</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-red-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>Daha uzun iyileşme</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-4 h-4 text-red-400 mr-1 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                          <span>%70-85 yaşama oranı</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-12 text-center">
              <a href="#contact-form" className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg shadow-md hover:shadow-lg inline-flex items-center transition-all duration-300">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path>
                </svg>
                Ücretsiz DHI Konsültasyonu Alın
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Derin Uyku Yöntemi */}
      <section className="py-16 bg-gradient-to-b from-teal-50 to-blue-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Derin Uyku Yöntemi ile Ağrısız İşlem
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Saç ekimi operasyonlarında ağrı hissini tamamen ortadan kaldıran özel derin uyku yöntemimiz 
                sayesinde rahat ve konforlu bir deneyim yaşarsınız.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex flex-col justify-center">
                  <h3 className="text-2xl font-semibold mb-6 text-teal-700">
                    Derin Uyku Yöntemi Nasıl Çalışır?
                  </h3>
                  <p className="text-gray-700 mb-6">
                    Saç ekimi operasyonunun en ağrılı aşaması olan anestezi uygulaması sırasında, 
                    hastalarımıza özel sedasyonla kısa süreli derin uyku uygulanır. Bu 15-20 dakikalık 
                    uyku sırasında tüm anestezi işlemleri tamamlanır.
                  </p>
                  <p className="text-gray-700 mb-6">
                    Hasta uyandiğında, anestezi işlemi çoktan tamamlanmış olur ve operasyonun 
                    geri kalanı tamamen ağrısız bir şekilde devam eder.
                  </p>
                  <div className="bg-teal-50 p-4 rounded-lg border border-teal-100">
                    <h4 className="font-semibold text-teal-700 mb-2">Derin Uyku Yönteminin Avantajları:</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Tamamen ağrısız anestezi uygulaması</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Anestezi korkusu olan hastalar için ideal</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Operasyon süresince daha rahat bir deneyim</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Uzman anestezi ekibi gözetiminde güvenli uygulama</span>
                      </li>
                    </ul>
                  </div>
                </div>
                <div>
                  <img 
                    src="/sedation-method.jpg" 
                    alt="Derin Uyku Yöntemi" 
                    className="rounded-lg shadow-lg w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1631815588090-d1bcbe9a8545?q=80&w=1632&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Profili */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <img 
                  src="/assets/dr-gizem-kagitci.jpg" 
                  alt="Dr. Gizem Kağıtçı" 
                  className="rounded-lg shadow-lg"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=1374&auto=format&fit=crop";
                  }}
                />
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <img 
                    src="/assets/before-case1.jpg" 
                    alt="Dr. Gizem Kağıtçı ile Hasta" 
                    className="rounded-md shadow h-24 w-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1612396981920-3d899595936a?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <img 
                    src="/assets/after-case1.jpg" 
                    alt="Dr. Gizem Kağıtçı Kliniği" 
                    className="rounded-md shadow h-24 w-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1468&auto=format&fit=crop";
                    }}
                  />
                  <img 
                    src="/assets/dr-gizem-kagitci.jpg" 
                    alt="Dr. Gizem Kağıtçı Konsültasyon" 
                    className="rounded-md shadow h-24 w-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=1480&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div>
                <div className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
                  UZMAN HEKİM
                </div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">
                  Dr. Gizem Kağıtçı
                </h2>
                <p className="text-teal-600 text-xl mb-6">Saç Ekimi ve Plastik Cerrahi Uzmanı</p>
                
                <div className="bg-gray-50 p-4 rounded-lg mb-6 flex items-center">
                  <div className="mr-4 text-teal-600">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-gray-800 font-medium">DHI Tekniğinin Öncüsü</p>
                    <p className="text-gray-600 text-sm">Türkiye'de DHI teknolojisini geliştiren ve yaygınlaştıran öncü hekimlerden biridir.</p>
                  </div>
                </div>
                
                <p className="text-gray-700 mb-6">
                  Dr. Gizem Kağıtçı, plastik, rekonstrüktif ve estetik cerrahi alanında uluslararası deneyime sahip bir uzmandır. 
                  Saç ekimi konusunda özellikle DHI tekniği ile yaptığı başarılı operasyonlar sayesinde binlerce hastanın hayatını değiştirmiştir.
                </p>
                
                <div className="bg-teal-50 p-5 rounded-lg mb-6 border border-teal-100">
                  <h3 className="font-semibold text-teal-700 mb-3">Neden Dr. Gizem Kağıtçı?</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700 text-sm">DHI teknolojisinde uzmanlık ve sürekli eğitim</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700 text-sm">Her hasta için kişiselleştirilmiş tedavi planı</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700 text-sm">Ücretsiz detaylı konsültasyon ve uzun süreli takip</span>
                    </li>
                  </ul>
                </div>
                

                <div className="bg-blue-50 p-4 rounded-lg mb-6">
                  <h3 className="font-semibold text-blue-700 mb-2">Dr. Gizem Kağıtçı'nın Yaklaşımı</h3>
                  <p className="text-gray-700 text-sm">
                    "Her hasta benzersizdir ve herkesin kendine özgü saç yapısı ve ihtiyaçları vardır. Amacım, DHI tekniğinin üstün avantajlarını 
                    kullanarak her hastaya özel, doğal ve kalıcı sonuçlar sunmaktır. Saç ekimi sadece teknik bir işlem değil, aynı zamanda
                    sanatsal bir yaklaşım gerektiren bir süreçtir."
                  </p>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <svg key={i} className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                        </svg>
                      ))}
                    </div>
                    <span className="ml-2 text-gray-600 text-sm">5.0/5.0 (1200+ Değerlendirme)</span>
                  </div>
                  <a 
                    href="https://www.instagram.com/dr.gizemkagitci"
                    target="_blank"
                    rel="noopener noreferrer" 
                    className="flex items-center text-pink-600 hover:text-pink-700"
                  >
                    <svg className="w-5 h-5 mr-1" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                    </svg>
                    Instagram
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fiyat Karşılaştırma Bölümü */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ŞEFFAF FİYATLANDIRMA
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Kaliteli Hizmetin Karşılaştırması
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Bizim sunduğumuz premium saç ekimi hizmeti ile piyasadaki diğer seçenekleri karşılaştırın.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="grid grid-cols-1 md:grid-cols-2">
                {/* Premium Hizmet - Estpital */}
                <div className="p-8 border-b md:border-b-0 md:border-r border-gray-200 bg-gradient-to-br from-teal-50 to-white">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-teal-700 mb-2">Estpital Premium</h3>
                    <div className="text-4xl font-bold text-gray-900 mb-6">50.000 TL</div>
                    <div className="text-sm text-gray-600 mb-2">Tam kapsamlı premium hizmet</div>
                    <span className="inline-block bg-teal-600 text-white text-xs px-3 py-1 rounded-full mb-6">ÖNERİLEN</span>
                  </div>
                  
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800">Operasyon boyunca <strong>doktor kontrolü</strong></span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Deep Sleep</strong> sedasyon ile ağrısız işlem</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Anestezi doktoru</strong> süreç dahiliyeti</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800">Sadece <strong>DHI yöntemi</strong> ile üstün kalite</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800">Her işlemde <strong>yeni kalem uçları</strong></span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Orijinal PRP tüpleri</strong> ile zengin PRP</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>Zengin mezoterapi</strong> içerikleri</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-600 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-800"><strong>1 yıl</strong> ücretsiz kontrol ve bakım</span>
                    </li>
                  </ul>
                  
                  <div className="mt-8 text-center">
                    <button 
                      onClick={redirectToWhatsApp}
                      className="w-full px-6 py-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors font-semibold"
                    >
                      Ücretsiz Konsültasyon
                    </button>
                  </div>
                </div>
                
                {/* Düşük Kalite / Alt Segment */}
                <div className="p-8 bg-gradient-to-br from-gray-50 to-white">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-gray-700 mb-2">Alt Segment</h3>
                    <div className="text-4xl font-bold text-gray-900 mb-6">15.000 TL</div>
                    <div className="text-sm text-gray-600 mb-2">Düşük kalite ve yetersiz özellikler</div>
                    <span className="inline-block bg-red-600 text-white text-xs px-3 py-1 rounded-full mb-6">YETERSİZ</span>
                  </div>
                  
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Doktor kontrolü yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Ağrılı işlem</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Anestezi doktoru yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Sadece FUE yöntemi</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Kalem uçları değiştirilmiyor</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">PRP uygulaması yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Mezoterapi yok</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-red-500 mt-0.5 mr-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                      </svg>
                      <span className="text-gray-500">Kontrol ve bakım yok</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Video Bölümü */}
      <VideoSection id="videos" />
      
      {/* Öncesi ve Sonrası */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                GERÇEK SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Hastalarımızın saç ekimi öncesi ve sonrası fotoğrafları, 
                DHI tekniğimizin etkinliğini net bir şekilde göstermektedir.
              </p>
            </div>

            <Tabs defaultValue="case1" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-8">
                <TabsTrigger value="case1">Vaka 1</TabsTrigger>
                <TabsTrigger value="case2">Vaka 2</TabsTrigger>
                <TabsTrigger value="case3">Vaka 3</TabsTrigger>
              </TabsList>
              <TabsContent value="case1">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/before-case1.jpg"
                          alt="Saç Ekimi Öncesi - Vaka 1"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1582550945154-66ea8fff25e1?q=80&w=1470&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-1 rounded-full font-medium shadow-md">
                          ÖNCE
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Öncesi</h3>
                        <p className="text-gray-600">35 yaşında erkek hasta, ileri derecede saç dökülmesi.</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <span className="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Saç Çizgisi Geriliği</span>
                          <span className="inline-block bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Kellik</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/after-case1.jpg"
                          alt="Saç Ekimi Sonrası - Vaka 1"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1633332755192-727a05c4013d?q=80&w=1480&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-1 rounded-full font-medium">
                          Sonrası
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Sonrası (12 Ay)</h3>
                        <p className="text-gray-600">4500 greft DHI tekniği ile saç ekimi. Doğal saç çizgisi ve yoğunluk.</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                          <span className="inline-block bg-teal-100 text-teal-800 text-xs px-2 py-1 rounded">Doğal Görünüm</span>
                          <span className="inline-block bg-teal-100 text-teal-800 text-xs px-2 py-1 rounded">%95+ Başarı</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="case2">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/before-case2.jpg"
                          alt="Saç Ekimi Öncesi - Vaka 2"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1612396981385-cfd6e9d38944?q=80&w=1470&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-1 rounded-full font-medium">
                          Öncesi
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Öncesi</h3>
                        <p className="text-gray-600">42 yaşında erkek hasta, tepe bölgesinde belirgin saç kaybı.</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/after-case2.jpg"
                          alt="Saç Ekimi Sonrası - Vaka 2"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?q=80&w=1534&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-1 rounded-full font-medium">
                          Sonrası
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Sonrası (10 Ay)</h3>
                        <p className="text-gray-600">3800 greft DHI tekniği ile saç ekimi. Tepe bölgesinde tam kapama.</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="case3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/before-case3.jpg"
                          alt="Saç Ekimi Öncesi - Vaka 3"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1612396981547-81c13c070a09?q=80&w=1470&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-1 rounded-full font-medium">
                          Öncesi
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Öncesi</h3>
                        <p className="text-gray-600">29 yaşında erkek hasta, saç çizgisi gerilemiş.</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-0">
                      <div className="relative pt-[56.25%]">
                        <img
                          src="/after-case3.jpg"
                          alt="Saç Ekimi Sonrası - Vaka 3"
                          className="absolute inset-0 w-full h-full object-cover rounded-t-lg"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?q=80&w=1374&auto=format&fit=crop";
                          }}
                        />
                        <div className="absolute top-4 left-4 bg-green-500 text-white px-4 py-1 rounded-full font-medium">
                          Sonrası
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="font-semibold text-gray-900 mb-2">Operasyon Sonrası (8 Ay)</h3>
                        <p className="text-gray-600">2500 greft DHI tekniği ile saç çizgisi yenileme. Genç ve doğal görünüm.</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
                Ücretsiz Konsültasyon
              </h2>
              <p className="text-xl text-gray-600">
                Size özel saç ekimi planı için uzmanlarımızla iletişime geçin.
              </p>
            </div>

            <div className="bg-gradient-to-r from-teal-500 to-blue-500 p-1 rounded-xl">
              <div className="bg-white rounded-lg p-8">
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Adınız Soyadınız
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                        placeholder="Adınız Soyadınız"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                        Telefon Numaranız
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                        placeholder="05XX XXX XX XX"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      E-posta Adresiniz
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      placeholder="ornek@email.com"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Mesajınız
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                      placeholder="Saç ekimi hakkında bilgi almak istiyorum..."
                    ></textarea>
                  </div>
                  <div className="flex justify-center">
                    <Button 
                      className="w-full md:w-auto bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white px-8 py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      Ücretsiz Konsültasyon Talep Et
                    </Button>
                  </div>
                </form>
              </div>
            </div>

            <div className="mt-16 text-center">
              <p className="text-gray-600 mb-6">
                Daha hızlı bir yanıt için bizi hemen arayabilirsiniz.
              </p>
              <a 
                href="tel:+902121234567" 
                className="text-2xl font-bold text-teal-600 hover:text-teal-700 transition-colors flex items-center justify-center"
              >
                <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path>
                </svg>
                0212 123 45 67
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Whatsapp Sabit Buton */}
      <div className="fixed bottom-6 right-6 z-50">
        <button 
          onClick={redirectToWhatsApp}
          className="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center"
        >
          <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
          </svg>
        </button>
      </div>
    </div>
  );
}