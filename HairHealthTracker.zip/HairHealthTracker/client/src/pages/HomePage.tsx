import { useLocation } from "wouter";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "../components/ServicesSection";
import DoctorsSection from "../components/DoctorsSection";
import TestimonialsSection from "../components/TestimonialsSection";
import FAQSection from "@/components/FAQSection";
import ContactSection from "../components/ContactSection";
import VideoSection from "../components/VideoSection";
import ProcedureCategorySection from "@/components/ProcedureCategorySection";

export default function HomePage() {
  const [, setLocation] = useLocation();
  
  const startConsultation = () => {
    setLocation("/consultation");
  };

  // Yüz Estetiği İşlemleri
  const faceProcedures = [
    {
      id: "facelift",
      name: "Tam Yüz Germe",
      route: "/procedures/facelift",
      image: "/assets/procedures/facelift-hero.jpg",
      shortDesc: "Yüz ve boyunda kapsamlı gençleştirme"
    },
    {
      id: "mini-facelift",
      name: "Mini Yüz Germe",
      route: "/procedures/mini-facelift",
      image: "/assets/procedures/mini-facelift-hero.jpg",
      shortDesc: "Alt yüz ve çene hattı gençleştirme"
    },
    {
      id: "blepharoplasty",
      name: "Göz Kapağı Estetiği",
      route: "/procedures/blepharoplasty",
      image: "/assets/procedures/blepharoplasty-hero.jpg",
      shortDesc: "Yorgun göz görünümünü giderme"
    },
    {
      id: "rhinoplasty",
      name: "Burun Estetiği",
      route: "/procedures/rhinoplasty",
      image: "/assets/procedures/rhinoplasty-hero.jpg",
      shortDesc: "Burun şekillendirme"
    },
    {
      id: "liplift",
      name: "Dudak Kaldırma",
      route: "/procedures/liplift",
      image: "/assets/procedures/liplift-hero.jpg",
      shortDesc: "Dudak görünümünü gençleştirme"
    },
    {
      id: "lipodem-treatment",
      name: "Lipödem Tedavisi",
      route: "/procedures/lipodem-treatment",
      image: "/assets/procedures/lipodem-hero.jpg",
      shortDesc: "Vaser liposuction ile lipödem tedavisi"
    }
  ];

  // Saç Estetiği İşlemleri
  const hairProcedures = [
    {
      id: "hair-transplant",
      name: "Saç Ekimi",
      route: "/procedures/hair-transplant",
      image: "/assets/procedures/hairtransplant-hero.jpg",
      shortDesc: "Kalıcı saç çözümü"
    }
  ];

  return (
    <div className="bg-gray-50">
      <HeroSection onStartAnalysis={startConsultation} />
      <ServicesSection id="services" />
      
      {/* Yüz Estetiği Kategorisi */}
      <ProcedureCategorySection 
        title="Yüz Estetiği ve Cerrahi İşlemler"
        subtitle="Doğal görünümlü, yenilikçi ve kişiye özel yüz estetiği çözümleri sunuyoruz."
        doctor={{
          name: "Doç. Dr. Ummahan Özaslan",
          title: "Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı",
          image: "/assets/doctors/dr-ummahan-ozaslan.jpg"
        }}
        procedures={faceProcedures}
        bgColor="bg-gradient-to-b from-white to-teal-50"
        accentColor="bg-teal-600"
      />
      
      {/* Saç Estetiği Kategorisi */}
      <ProcedureCategorySection 
        title="Saç Estetiği ve Saç Ekimi"
        subtitle="En ileri tekniklerle kalıcı ve doğal saç çözümleri."
        doctor={{
          name: "Dr. Gizem Kağıtçı",
          title: "Saç Ekimi ve Saç Estetiği Uzmanı",
          image: "/assets/doctors/dr-gizem-kagitci.jpg"
        }}
        procedures={hairProcedures}
        bgColor="bg-gradient-to-b from-teal-50 to-blue-50"
        accentColor="bg-blue-600"
      />

      <DoctorsSection id="doctors" />
      <TestimonialsSection id="testimonials" />
      <FAQSection id="faq" />
      <ContactSection id="contact" />
    </div>
  );
}
