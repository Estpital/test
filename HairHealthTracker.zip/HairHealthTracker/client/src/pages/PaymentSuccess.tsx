import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export default function PaymentSuccess() {
  const { toast } = useToast();
  const [orderNumber, setOrderNumber] = useState<string>("");
  
  useEffect(() => {
    // Sepeti temizle
    localStorage.removeItem("cart");
    
    // Rastgele sipariş numarası oluştur
    const randomOrderNumber = 'EST' + Math.floor(100000 + Math.random() * 900000);
    setOrderNumber(randomOrderNumber);
    
    // Başarılı ödeme bildirimi göster
    toast({
      title: "Ödeme Başarılı!",
      description: "Siparişiniz başarıyla oluşturuldu.",
    });
  }, [toast]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-100 flex items-center justify-center py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-lg mx-auto">
          <Card className="border-green-100 shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-green-500 to-teal-500 p-6 text-white text-center">
              <div className="w-16 h-16 bg-white rounded-full text-green-500 flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h1 className="text-3xl font-bold">Teşekkürler!</h1>
              <p className="mt-2 opacity-90">Ödemeniz başarıyla alındı</p>
            </div>
            
            <CardContent className="space-y-6 pt-6">
              <div className="text-center">
                <CardTitle className="text-2xl mb-2">Siparişiniz Onaylandı</CardTitle>
                <CardDescription>
                  Sipariş detayları e-posta adresinize gönderilecektir.
                </CardDescription>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-500">Sipariş Numarası:</span>
                  <span className="font-medium">{orderNumber}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Tarih:</span>
                  <span className="font-medium">{new Date().toLocaleDateString('tr-TR')}</span>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h3 className="font-medium mb-2 text-gray-800">Ne olacak?</h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    <span>Sipariş onayınız e-posta adresinize gönderilecektir.</span>
                  </li>
                  <li className="flex gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <span>Siparişiniz 24 saat içinde hazırlanıp kargoya verilecektir.</span>
                  </li>
                  <li className="flex gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207" />
                    </svg>
                    <span>Siparişinizle ilgili herhangi bir sorunuz olursa bizimle iletişime geçebilirsiniz.</span>
                  </li>
                </ul>
              </div>
            </CardContent>
            
            <CardFooter className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
              <Button 
                className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600"
                onClick={() => window.location.href = "/shop"}
              >
                Alışverişe Devam Et
              </Button>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.print()}
              >
                Sipariş Bilgisini Yazdır
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}