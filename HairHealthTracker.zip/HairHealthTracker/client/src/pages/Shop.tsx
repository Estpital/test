import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

// Must De Qen ürünleri
const products = [
  // Kategori: Saç Serumu
  {
    id: 1,
    name: "Hair Repair Serum",
    category: "serum",
    price: 40, // 40 Euro
    image: "/assets/products/hair-repair-serum.jpg",
    description: "Saç dökülmesini durdurmak, hacimli ve yoğun saçlara kavuşmak isteyenler için geliştirilmiş bir saç dökülme karşıtı serumdur.",
    stockStatus: "in-stock",
    rating: 4.8,
    reviews: 127,
    features: [
      "Saç dökülmesini engeller",
      "Saç köklerini güçlendirir",
      "Saç tellerini kalınlaştırır",
      "Yeni saç çıkışını hızlandırır"
    ],
    usage: "Serumdan 4-5 damla alın ve doğrudan saç derisine uygulayın. Parmak uçlarınızla nazikçe masaj yapın. En az 15-20 dakika yıkamayın ve durulamayın."
  },
  {
    id: 2,
    name: "Hair Repair Serum Sprey",
    category: "spray",
    price: 40, // 40 Euro
    image: "/assets/products/hair-repair-serum-sprey.jpg",
    description: "Saç dökülmelerine karşı geliştirilmiş yeni bir formüldür.",
    stockStatus: "in-stock",
    rating: 4.9,
    reviews: 85,
    features: [
      "Saç dökülmesine karşı etkili",
      "Saç köklerini besler",
      "Yenilikçi formül",
      "Hızlı emilim"
    ],
    usage: "Temiz saç derisine 3-4 damlayı tamamen emilmesi için parmaklarınızla masaj yaparak uygulayın. Durulamadan 2 gün saç derisinde bırakınız. 2 gün sonra saçları yıkayınız ve aynı şekilde temiz saç derisine tekrar uygulayınız."
  },
  // Kategori: Saç Vitamin
  {
    id: 3,
    name: "Hair Vitamine",
    category: "vitamin",
    price: 40, // 40 Euro
    image: "/assets/products/hair-vitamine.jpg",
    description: "Ağızda dağılan formu ile ürünün hızla kana karışmasını sağlar. Böylece saç köklerinin ihtiyaç duyduğu vitamin ve mineraller hızla saç köküne taşınır.",
    stockStatus: "in-stock",
    rating: 4.7,
    reviews: 103,
    features: [
      "Ağızda hızla dağılan tablet",
      "Saç köklerini besler",
      "Vitamin ve mineral takviyesi",
      "Dil altı kullanım"
    ],
    usage: "11 yaş üstü çocuklar ve yetişkinler için günde 1 tablet eriyene kadar dil altında tutularak tüketilmesi tavsiye edilir."
  },
  {
    id: 4,
    name: "Derma Roller System",
    category: "tools",
    price: 20, // 20 Euro
    image: "/assets/products/derma-roller-system.jpg",
    description: "Saç dökülmesi problemi ve zayıflamış saçları nazikçe temizler ve saç kaybını azaltır. İçeriğindeki bileşenler saç köklerinin derinlemesine beslenmesine yardımcı olur.",
    stockStatus: "in-stock",
    rating: 4.6,
    reviews: 94,
    features: [
      "Saç dökülmesini azaltır",
      "Saç köklerini besler",
      "Nazik temizleme",
      "Günlük kullanıma uygun"
    ],
    usage: "Günlük kullanıma uygundur. Islak saça uygulayın. Kullanım sırasında köpüğe dönüşür, köpüğü cildinize yaymak ve cildine beslemek için parmak uçlarınız ile hafif dokunuşlar ile uygulayın. 4-5 sprey cildiniz için yeterlidir. 3-4 dakika bekletin ve ardından durulayın."
  },
  // Kategori: Saç Bakım Seti
  {
    id: 5,
    name: "3 Aylık Mezoterapili Set",
    category: "set",
    price: 300, // 300 Euro
    image: "/assets/products/3-aylik-mezoterapili-set.jpg",
    description: "Saç dökülmelerine karşı geliştirilmiş yeni bir formüldür.",
    stockStatus: "in-stock",
    rating: 4.8,
    reviews: 76,
    features: [
      "2 x Saç Dökülmesine Karşı Şampuan",
      "1 x Saç Vitamini",
      "1 x Saç Onarıcı Serum",
      "1 x Saç Mezoterapi Spreyi",
      "3 x Saç Serumu (Mezoterapi)"
    ]
  },
  {
    id: 6,
    name: "6 Aylık Mezoterapili Set",
    category: "set",
    price: 500, // 500 Euro
    image: "/assets/products/6-aylik-mezoterapili-set.jpg",
    description: "Saç dökülmelerine karşı geliştirilmiş yeni bir formüldür.",
    stockStatus: "in-stock",
    rating: 4.9,
    reviews: 62,
    features: [
      "4 x Saç Dökülmesine Karşı Şampuan",
      "3 x Saç Vitamini",
      "1 x Saç Onarıcı Serum",
      "3 x Saç Mezoterapi Spreyi",
      "5 x Saç Serumu (Mezoterapi)"
    ]
  },
  {
    id: 7,
    name: "Meso Hair Serum Set",
    category: "set",
    price: 200, // 200 Euro
    image: "/assets/products/meso-hair-serum-set.jpg",
    description: "Sağlıklı, güzel ve parlak saçlara kavuşmanız için saç köklerini canlandırmak ve saçları canlandırmak amacıyla geliştirilmiştir. Vitamin, enzim, hormon ve bitki özlerini bir araya getiren formülü ile saçlarınızı canlandırır.",
    stockStatus: "in-stock",
    rating: 4.8,
    reviews: 58,
    features: [
      "Saç köklerini canlandırır",
      "Vitamin ve enzim içerir",
      "Bitki özleri içerir",
      "Derma Roller System ile birlikte"
    ],
    usage: "Temiz saç derisine 3-4 damla serum uygulayın ve parmaklarınızla masaj yaparak emilmesini sağlayın. Serumu durulamadan 2 gün saç derisinde bırakın. 2 gün sonra saçı yıkayın ve yıkamadan sonra tekrar uygulayın. Saç ekimi yaptırdıysanız ekimden 1 ay sonra uygulamaya başlayın."
  }
];

// Sepet türü
interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

export default function Shop() {
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Yerel depolamadan sepeti yükleme
  useEffect(() => {
    const savedCart = localStorage.getItem("cart");
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    }
  }, []);

  // Sepete ekleme
  const addToCart = (product: any) => {
    setCartItems((prevItems) => {
      // Ürün sepette var mı kontrol et
      const existingItem = prevItems.find((item) => item.id === product.id);
      
      let newCart;
      if (existingItem) {
        // Eğer ürün zaten sepette ise, miktarını artır
        newCart = prevItems.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        // Eğer ürün sepette değilse, yeni ürün olarak ekle
        newCart = [...prevItems, { ...product, quantity: 1 }];
      }
      
      // Sepeti yerel depolamaya kaydet
      localStorage.setItem("cart", JSON.stringify(newCart));
      
      toast({
        title: "Ürün sepete eklendi",
        description: `${product.name} sepetinize eklendi.`,
      });
      
      return newCart;
    });
  };

  // Sepetten ürün çıkarma
  const removeFromCart = (productId: number) => {
    setCartItems((prevItems) => {
      const newCart = prevItems.filter((item) => item.id !== productId);
      localStorage.setItem("cart", JSON.stringify(newCart));
      return newCart;
    });
    
    toast({
      title: "Ürün sepetten çıkarıldı",
      description: "Ürün sepetinizden çıkarıldı.",
      variant: "destructive",
    });
  };

  // Ürün miktarını güncelleme
  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setCartItems((prevItems) => {
      const newCart = prevItems.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      );
      localStorage.setItem("cart", JSON.stringify(newCart));
      return newCart;
    });
  };

  // Sepetin toplam fiyatını hesaplama
  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  // Filtrelenmiş ürünleri alma
  const getFilteredProducts = () => {
    return products.filter((product) => {
      // Kategori filtresi
      const categoryMatch = selectedCategory === "all" || product.category === selectedCategory;
      
      // Arama filtresi
      const searchMatch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return categoryMatch && searchMatch;
    });
  };

  // Checkout işlemi
  const goToCheckout = () => {
    if (cartItems.length === 0) {
      toast({
        title: "Sepetiniz boş",
        description: "Ödeme yapmak için sepetinize ürün ekleyin.",
        variant: "destructive",
      });
      return;
    }
    
    // Kullanıcıyı checkout sayfasına yönlendir
    window.location.href = "/checkout";
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-100">
      {/* Header */}
      <section className="pt-16 pb-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-teal-600 to-blue-600">
              Must De Qen Ürünleri
            </h1>
            <p className="text-xl text-gray-600">
              Saç sağlığı ve bakımı için geliştirilmiş profesyonel ürünler
            </p>
          </div>
        </div>
      </section>

      {/* Ana İçerik */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-12 gap-8">
            {/* Filtreler (Solda) */}
            <div className="col-span-12 lg:col-span-3">
              <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <h2 className="text-xl font-bold mb-4 text-gray-800">Kategoriler</h2>
                <div className="space-y-2">
                  <button 
                    onClick={() => setSelectedCategory("all")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "all" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Tüm Ürünler
                  </button>
                  <button 
                    onClick={() => setSelectedCategory("serum")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "serum" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Saç Serumu
                  </button>
                  <button 
                    onClick={() => setSelectedCategory("spray")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "spray" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Saç Spreyi
                  </button>
                  <button 
                    onClick={() => setSelectedCategory("vitamin")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "vitamin" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Saç Vitamini
                  </button>
                  <button 
                    onClick={() => setSelectedCategory("tools")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "tools" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Saç Bakım Aletleri
                  </button>
                  <button 
                    onClick={() => setSelectedCategory("set")}
                    className={`w-full py-2 px-3 text-left rounded-md ${selectedCategory === "set" ? "bg-teal-100 text-teal-700" : "hover:bg-gray-100"}`}
                  >
                    Saç Bakım Seti
                  </button>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-md mb-6">
                <h2 className="text-xl font-bold mb-4 text-gray-800">Arama</h2>
                <Input 
                  type="text" 
                  placeholder="Ürün ara..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
              </div>

              <div className="bg-gradient-to-br from-teal-500 to-blue-600 p-6 rounded-lg text-white">
                <h3 className="text-xl font-semibold mb-3">Ücretsiz Kargo</h3>
                <p className="mb-4">100 € ve üzeri alışverişlerinizde kargo ücretsiz!</p>
                <Button 
                  variant="secondary" 
                  className="w-full bg-white text-teal-600 hover:bg-gray-100"
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                >
                  Alışverişe Başla
                </Button>
              </div>
            </div>

            {/* Ürün Listesi (Sağda) */}
            <div className="col-span-12 lg:col-span-9">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">
                  {selectedCategory === "all" ? "Tüm Ürünler" : 
                   selectedCategory === "hair-tonic" ? "Saç Toniği" :
                   selectedCategory === "shampoo" ? "Şampuan" :
                   selectedCategory === "serum" ? "Saç Serumu" :
                   selectedCategory === "spray" ? "Saç Spreyi" : "Saç Bakım Seti"}
                </h2>
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2"
                  onClick={() => setIsCartOpen(true)}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
                  </svg>
                  Sepet ({cartItems.reduce((total, item) => total + item.quantity, 0)})
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {getFilteredProducts().map((product) => (
                  <Card key={product.id} className="overflow-hidden h-full flex flex-col">
                    <div className="relative h-64 overflow-hidden bg-gray-100">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://placehold.co/400x400?text=Must+De+Qen";
                        }}
                      />
                      <Badge className="absolute top-2 right-2 bg-teal-500">
                        {product.price} €
                      </Badge>
                    </div>
                    <CardHeader className="flex-1">
                      <div className="flex items-center gap-1 text-yellow-500 mb-2">
                        {Array(5).fill(0).map((_, i) => (
                          <svg key={i} xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-gray-300'}`} viewBox="0 0 20 20" fill="currentColor">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
                      </div>
                      <CardTitle className="text-xl">{product.name}</CardTitle>
                      <CardDescription className="line-clamp-2 mt-2">{product.description}</CardDescription>
                    </CardHeader>
                    <CardFooter>
                      <Button 
                        className="w-full bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600"
                        onClick={() => addToCart(product)}
                      >
                        Sepete Ekle
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>

              {getFilteredProducts().length === 0 && (
                <div className="bg-white p-8 rounded-lg shadow-md text-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h3 className="text-xl font-semibold text-gray-700 mb-2">Ürün Bulunamadı</h3>
                  <p className="text-gray-500">Arama kriterlerinize uygun ürün bulunamadı. Lütfen farklı bir arama yapın veya filtreleri sıfırlayın.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Sepet Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            {/* Arkaplan overlay */}
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" onClick={() => setIsCartOpen(false)}></div>

            {/* Modal içeriği */}
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div className="sm:flex sm:items-start">
                  <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                    <h3 className="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                      Alışveriş Sepeti
                    </h3>
                    <div className="mt-4">
                      {cartItems.length === 0 ? (
                        <div className="text-center py-8">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                          </svg>
                          <p className="text-gray-500">Sepetiniz boş</p>
                        </div>
                      ) : (
                        <div>
                          <div className="max-h-96 overflow-y-auto">
                            {cartItems.map((item) => (
                              <div key={item.id} className="flex items-center py-4 border-b">
                                <img 
                                  src={item.image} 
                                  alt={item.name} 
                                  className="w-16 h-16 object-cover rounded"
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.src = "https://placehold.co/400x400?text=Must+De+Qen";
                                  }}
                                />
                                <div className="ml-4 flex-1">
                                  <h4 className="text-sm font-medium text-gray-800">{item.name}</h4>
                                  <p className="text-sm text-gray-500">{item.price} €</p>
                                  <div className="flex items-center mt-2">
                                    <button 
                                      className="w-6 h-6 bg-gray-200 rounded flex items-center justify-center"
                                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    >
                                      -
                                    </button>
                                    <span className="mx-2 text-sm">{item.quantity}</span>
                                    <button 
                                      className="w-6 h-6 bg-gray-200 rounded flex items-center justify-center"
                                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    >
                                      +
                                    </button>
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <p className="font-medium">{item.price * item.quantity} TL</p>
                                  <button 
                                    className="text-red-500 mt-2 text-sm"
                                    onClick={() => removeFromCart(item.id)}
                                  >
                                    Kaldır
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="mt-4 border-t pt-4">
                            <div className="flex justify-between">
                              <span className="font-medium">Toplam:</span>
                              <span className="font-bold">{calculateTotal()} TL</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <Button
                  className="w-full sm:w-auto bg-gradient-to-r from-teal-500 to-blue-500 hover:from-teal-600 hover:to-blue-600"
                  onClick={goToCheckout}
                  disabled={cartItems.length === 0}
                >
                  Ödemeye Geç
                </Button>
                <Button
                  variant="outline"
                  className="mt-3 w-full sm:mt-0 sm:ml-3 sm:w-auto"
                  onClick={() => setIsCartOpen(false)}
                >
                  Alışverişe Devam Et
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Neden Bizi Seçmelisiniz */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Neden Must De Qen?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Must De Qen, saç sağlığı konusunda uzmanlaşmış bir markadır. Ürünlerimiz bilimsel araştırmalarla desteklenen formüllerle üretilmektedir.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Kanıtlanmış Etkinlik</h3>
              <p className="text-gray-600">
                Ürünlerimiz dermatologlar tarafından test edilmiş ve etkinliği kanıtlanmıştır. Klinik çalışmalarla desteklenen formüller kullanıyoruz.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Doğal İçerikler</h3>
              <p className="text-gray-600">
                Ürünlerimizde doğal ve yenilikçi içerikler kullanıyoruz. Paraben, sülfat ve silikon içermeyen formüller geliştiriyoruz.
              </p>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-lg shadow-md text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">Ücretsiz Danışmanlık</h3>
              <p className="text-gray-600">
                Ürün seçiminde kararsız kaldıysanız, uzmanlarımız size ücretsiz danışmanlık hizmeti sunabilir. Saç tipinize en uygun ürünü öneririz.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Müşteri Yorumları */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Müşteri Yorumları</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Ürünlerimizi kullanan müşterilerimizin gerçek deneyimleri ve görüşleri
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center gap-1 text-yellow-500 mb-4">
                {Array(5).fill(0).map((_, i) => (
                  <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 fill-current" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-600 mb-4 italic">
                "Must DHT Blocker Saç Toniği kullanmaya başladıktan 2 ay sonra saç dökülmem durdu ve yeni saçlar çıkmaya başladı. Kesinlikle tavsiye ediyorum."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3 flex items-center justify-center">
                  <span className="text-gray-700 font-medium">MA</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Mehmet A.</h4>
                  <p className="text-sm text-gray-500">35 yaşında</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center gap-1 text-yellow-500 mb-4">
                {Array(5).fill(0).map((_, i) => (
                  <svg key={i} xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${i < 5 ? 'fill-current' : 'text-gray-300'}`} viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-600 mb-4 italic">
                "Saç ekimi sonrası bakım için Must Hair Transplant Care Kit kullandım. İyileşme sürecim çok rahat geçti ve şu an saçlarım harika görünüyor."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3 flex items-center justify-center">
                  <span className="text-gray-700 font-medium">AY</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Ali Y.</h4>
                  <p className="text-sm text-gray-500">41 yaşında</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center gap-1 text-yellow-500 mb-4">
                {Array(5).fill(0).map((_, i) => (
                  <svg key={i} xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${i < 4 ? 'fill-current' : 'text-gray-300'}`} viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <p className="text-gray-600 mb-4 italic">
                "Must Biotin Şampuan ve Must Hair Serum kombinasyonu saçlarımda muhteşem bir etki yarattı. Daha parlak ve dolgun saçlara kavuştum."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 bg-gray-200 rounded-full mr-3 flex items-center justify-center">
                  <span className="text-gray-700 font-medium">SD</span>
                </div>
                <div>
                  <h4 className="font-medium text-gray-800">Selin D.</h4>
                  <p className="text-sm text-gray-500">29 yaşında</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}