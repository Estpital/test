import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function BlepharoplastyPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Göz%20kapağı%20estetiği%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-teal-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-teal-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-cyan-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-teal-600 to-cyan-600">
                  Göz Kapağı Estetiği
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Gözlerde Genç ve Dinlenmiş Görünüm
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde uygulanan göz kapağı estetiği (blefaroplasti) 
                  operasyonları ile göz çevresindeki yorgun ve yaşlı görünümden kurtulun. 
                  Alt ve üst göz kapaklarındaki sarkma, torbalanma ve kırışıklıkların düzeltilmesiyle
                  daha genç, dinamik ve dinlenmiş bir görünüm elde edin.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-teal-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/blepharoplasty-hero.jpg" 
                        alt="Göz Kapağı Estetiği" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1557891393-50022a9498e2?q=80&w=1974&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Hızlı İyileşme</h3>
                        </div>
                        <p className="text-sm text-gray-600">7-10 gün içinde</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-cyan-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-cyan-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Minimal İz</h3>
                        </div>
                        <p className="text-sm text-gray-600">Doğal kıvrımlarda gizlenir</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">1-2 saat</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Lokal anestezi + sedasyon</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">Gerekmez (günübirlik)</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">7-10 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">2-3 ay</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha genç ve dinlenmiş görünüm</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Göz çevresi kırışıklıklarında azalma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genişlemiş göz görüş alanı</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Minimal izler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Artan özgüven</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Göz çevresinde sarkma ve torbalanma olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yorgun ve yaşlı göz görünümü olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Görüş alanı daralmış olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genellikle 35 yaş üstü kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genel sağlık durumu iyi olanlar</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Göz Kapağı Estetiği Teknikleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                BLEFAROPLASTİ TEKNİKLERİ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Göz Kapağı Estetiği Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Her göz yapısına ve ihtiyaca göre özelleştirilen göz kapağı estetiği teknikleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-teal-700 mb-4">Üst Göz Kapağı Estetiği</h3>
                  <p className="text-gray-700 mb-4">
                    Üst göz kapağındaki fazla deri ve yağ dokusunun alınmasıyla, sarkık göz 
                    kapaklarının düzeltildiği ve daha canlı bir bakış elde edildiği tekniktir. 
                    Doğal göz kıvrımında gizlenen bir kesi ile uygulanır.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Görüş alanını genişletir</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha açık ve canlı bakış</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Göz makyajı uygulama kolaylığı</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/upper-blepharoplasty.jpg" 
                      alt="Üst Göz Kapağı Estetiği" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1551125625-aa7d542b9ff7?q=80&w=1974&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-teal-700 mb-4">Alt Göz Kapağı Estetiği</h3>
                  <p className="text-gray-700 mb-4">
                    Alt göz kapağındaki torbalanma ve çukurlaşmaların düzeltildiği, 
                    göz altı morluk ve halkalarının giderildiği tekniktir. Göz kapağı içinden 
                    (transkonjonktival) veya dışından (transkutanöz) yapılabilir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Yorgun göz altı görünümünü giderir</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha düz ve pürüzsüz göz altı bölgesi</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Transkonjonktival teknikte dışarıdan iz yok</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/lower-blepharoplasty.jpg" 
                      alt="Alt Göz Kapağı Estetiği" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1576859958301-0066e582c7ee?q=80&w=1974&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-teal-700 mb-4">Kombine Blefaroplasti</h3>
                <p className="text-gray-700 mb-4">
                  Hem üst hem alt göz kapaklarının aynı seansta düzeltildiği, yüz gençleştirme 
                  etkisinin maksimize edildiği kapsamlı tekniktir. Göz çevresinin tamamen 
                  yenilenmesini sağlar.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Operasyon Öncesi:</h4>
                    <ul className="space-y-2 mb-4">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Detaylı göz ve yüz analizi</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Göz sağlığı kontrolü</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Kişiselleştirilmiş planlanma</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Operasyon Sonrası:</h4>
                    <ul className="space-y-2 mb-4">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Soğuk kompres uygulaması</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">İlk 2-3 gün yüksek yastıkta uyuma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Göz damlası ve özel bakım</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/blepharoplasty-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1586763239867-4d58a26349f8?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    2 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">54 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Üst göz kapağı blefaroplastisi</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/blepharoplasty-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1586763239867-4d58a26349f8?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    3 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">48 Yaş, Erkek Hasta</h3>
                  <p className="text-gray-600">Alt göz kapağı blefaroplastisi</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/blepharoplasty-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1586763239867-4d58a26349f8?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    4 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">62 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Kombine blefaroplasti</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Detayları */}
      <section className="py-16 bg-teal-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="/assets/doctors/dr-ummahan-ozaslan.jpg" 
                    alt="Doç. Dr. Ummahan Özaslan" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-12">
                <h2 className="text-3xl font-bold mb-4 text-gray-900">Doç. Dr. Ummahan Özaslan</h2>
                <h3 className="text-xl text-teal-700 mb-4">Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı</h3>
                <p className="text-gray-700 mb-6">
                  Doç. Dr. Ummahan Özaslan, göz kapağı estetiği alanında 15 yılı aşkın deneyime sahiptir. 
                  Uluslararası plastik cerrahi derneklerinin aktif üyesi olan Dr. Özaslan, 
                  özellikle minimal invaziv ve doğal görünümlü göz çevresi gençleştirme teknikleri konusunda uzmanlaşmıştır.
                </p>
                <p className="text-gray-700 mb-6">
                  Yüzlerce başarılı blefaroplasti operasyonu gerçekleştiren Dr. Özaslan, her hastanın yüz yapısına 
                  ve beklentilerine uygun, doğal ve harmonik sonuçlar elde etmek için kişiselleştirilmiş 
                  teknikler kullanmaktadır.
                </p>
                <div className="flex space-x-4">
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700 text-white"
                    onClick={redirectToWhatsApp}
                  >
                    Doktor ile İletişime Geç
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Göz kapağı estetiği ameliyatı ağrılı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiği (blefaroplasti) ameliyatı genellikle lokal anestezi ve sedasyon altında yapılır, dolayısıyla işlem sırasında herhangi bir ağrı hissedilmez. Ameliyat sonrası ilk 24-48 saat içinde hafif bir rahatsızlık, gerginlik ve hafif bir yanma hissi olabilir, ancak bu genellikle reçete edilen ağrı kesiciler ve soğuk kompres uygulamaları ile kolayca kontrol altına alınabilir. Çoğu hasta, beklediğinden daha az ağrı yaşadığını belirtir. İlk birkaç gün gözlerde kuruluk ve ışığa karşı hassasiyet görülebilir, bu normal bir durumdur ve geçicidir. Blefaroplasti, plastik cerrahi operasyonları arasında en az ağrılı olanlardan biridir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Göz kapağı estetiği sonrası iz kalır mı?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiğinde kesiler stratejik bölgelere yerleştirildiği için izler genellikle minimal ve fark edilmesi zordur. Üst göz kapağı estetiğinde kesi, doğal göz kıvrımına yerleştirilir ve göz açıkken tamamen gizlenir. Alt göz kapağı estetiğinde ise iki yaklaşım kullanılabilir: Transkonjonktival yaklaşımda, kesi göz kapağının iç yüzeyine yapıldığı için dışarıdan hiçbir iz kalmaz. Transkutanöz yaklaşımda ise kesi alt kirpiklerin hemen altına yerleştirilir ve zamanla neredeyse görünmez hale gelir. Ameliyat sonrası izlerin iyileşmesi kişiden kişiye değişebilir, ancak çoğu hastada izler 6-12 ay içinde soluklaşır ve fark edilmesi zorlaşır. İz bakımı için güneşten korunmak ve doktorun önerdiği kremler kullanmak önemlidir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Göz kapağı estetiği sonuçları kalıcı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiği (blefaroplasti) sonuçları kalıcıdır, ancak yaşlanma sürecini tamamen durduramaz. Üst göz kapağı estetiği genellikle 10-15 yıl veya daha uzun süre etkisini korur. Alt göz kapağı estetiği ise genellikle daha uzun süreli, hatta ömür boyu süren sonuçlar verebilir. Ancak, doğal yaşlanma sürecine bağlı olarak ciltte zaman içinde yeni sarkma ve gevşemeler oluşabilir. Sonuçların uzun ömürlü olması için güneşten korunma, sağlıklı beslenme, sigara içmeme ve düzenli cilt bakımı gibi faktörler önemlidir. Bazı durumlarda, 10-15 yıl sonra ikinci bir işlem gerekebilir. Ancak ilk işlem genellikle daha kapsamlı olduğundan, ikinci işlem daha minimal ve daha kısa iyileşme süreli olacaktır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Göz kapağı estetiği sonrası iyileşme süreci nasıldır?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiği sonrası iyileşme süreci genellikle şu şekilde ilerler: İlk 24-48 saat içinde şişlik ve morarma en yoğun seviyededir, bu süreçte soğuk kompres uygulaması önerilir. İlk hafta boyunca gözlerde gerginlik, kuruluk ve hafif yanma hissi olabilir, göz damlası kullanımı bu semptomları hafifletir. 5-7 gün sonra dikişler alınır. İlk 10-14 gün içinde şişlikler ve morarmalar büyük oranda azalır, bu süre sonunda sosyal hayata dönmek mümkündür. 2-3 hafta sonra hafif egzersizlere başlanabilir. 4-6 hafta sonra tam fiziksel aktiviteye dönüş mümkündür. Şişliklerin tamamen geçmesi ve nihai sonucun görülmesi 2-3 ay sürebilir. Bu süreçte gözlerin aşırı yorulmasından, göz makyajından ve lenslerin kullanımından belirli bir süre kaçınmak gerekir. Her hastanın iyileşme süreci farklıdır ve doktorunuz tarafından önerilen bakım talimatlarına uymak önemlidir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Göz kapağı estetiği göz sağlığımı etkiler mi?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiği (blefaroplasti), doğru uygulandığında göz sağlığını olumsuz etkilemez, hatta bazı durumlarda iyileştirebilir. Şiddetli üst göz kapağı sarkması (pitozis) görüş alanını kısıtlayabilir ve bu durumda blefaroplasti görüş alanını genişleterek fonksiyonel bir iyileşme sağlar. Ancak, her cerrahi işlemde olduğu gibi, blefaroplastinin de bazı riskleri vardır. Nadir görülen komplikasyonlar arasında geçici veya kalıcı göz kuruluğu, göz kapaklarının tam kapanamaması, asimetri ve çok nadiren görme sorunları yer alır. Bu riskleri minimize etmek için cerrah seçimi çok önemlidir. Ayrıca, kuru göz sendromu olan hastalar için özel önlemler alınması gerekebilir. Operasyon öncesi detaylı bir göz muayenesi ve gerekirse göz doktoru konsültasyonu yapılması, potansiyel risklerin belirlenmesi ve minimuma indirilmesi açısından önemlidir. Doğru hasta seçimi, dikkatli cerrahi planlama ve uzman bir cerrah ile göz kapağı estetiği, genellikle güvenli ve memnuniyet verici sonuçlar sağlar.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Göz kapağı estetiği için ideal yaş nedir?</AccordionTrigger>
                <AccordionContent>
                  Göz kapağı estetiği (blefaroplasti) için belirli bir yaş sınırı yoktur. İhtiyaç ve uygunluk, kişinin fiziksel durumuna, genetik faktörlerine ve beklentilerine bağlıdır. Genellikle göz kapağı problemleri 35-40 yaş civarında belirginleşmeye başlar, bu nedenle çoğu blefaroplasti hastası 40 yaş ve üzerindedir. Ancak, genetik faktörler nedeniyle bazı kişilerde daha erken yaşlarda göz kapağı sarkması veya torbalanması görülebilir ve bu kişiler daha genç yaşta operasyondan faydalanabilir. Öte yandan, sağlık durumu iyi olan 70'li veya 80'li yaşlardaki hastalar da güvenle blefaroplasti yaptırabilir. Fonksiyonel blefaroplasti (görüş alanını etkileyen göz kapağı sarkması düzeltme) söz konusu olduğunda, yaş önemli bir faktör değildir. Her potansiyel adayın bireysel değerlendirmesi, genel sağlık durumu, göz sağlığı ve beklentileri göz önünde bulundurularak yapılmalıdır.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/facelift-hero.jpg" 
                      alt="Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Yüz Germe</h3>
                      <p className="text-white/80">Kapsamlı gençleştirme</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/rhinoplasty-hero.jpg" 
                      alt="Burun Estetiği" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Burun Estetiği</h3>
                      <p className="text-white/80">Harmonik yüz oranları</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/endoscopic-hero.jpg" 
                      alt="Endoskopik Alın Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Endoskopik Alın Germe</h3>
                      <p className="text-white/80">Minimal izli kaş kaldırma</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Göz Kapağı Estetiği Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="blepharoplasty" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}