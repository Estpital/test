import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function FaceLiftPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Yüz%20germe%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-teal-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-teal-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-blue-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-teal-600 to-blue-600">
                  Tam Yüz Germe
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Modern Tekniklerle Gençleşme ve Doğal Sonuçlar
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde, hastane ortamında, 
                  tam yüz germe operasyonları ile yaşlanma belirtilerini azaltırken doğal ve genç 
                  bir görünüm elde ediyoruz. Minimal izler ve hızlı iyileşme süreleri 
                  ile yenilenmiş bir görünüme kavuşun.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-teal-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/facelift-hero.jpg" 
                        alt="Tam Yüz Germe" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-teal-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Modern Teknik</h3>
                        </div>
                        <p className="text-sm text-gray-600">Minimal izlerle doğal sonuçlar</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Hızlı İyileşme</h3>
                        </div>
                        <p className="text-sm text-gray-600">Ortalama 10-14 gün</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">4-5 saat</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Genel anestezi</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">1 gece</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">10-14 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">2-3 ay</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yüz ve boyun bölgesindeki sarkmalar giderilir</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Derin kırışıklıklar azalır</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Çene hattı belirginleşir</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>10 yıla kadar kalıcı sonuçlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Doğal görünümlü, "gergin" değil "dinlenmiş" bir ifade</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-teal-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>40-70 yaş arası kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yüz ve boyunda belirgin sarkma olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genel sağlık durumu iyi olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Sigara kullanmayanlar veya bırakanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-teal-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Gerçekçi beklentileri olanlar</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Yüz Germe Teknikleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                TEKNİKLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Tam Yüz Germe Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Her hastanın yüz yapısı ve ihtiyaçlarına göre özelleştirilen farklı teknikler kullanıyoruz
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex">
                <img 
                  src="/assets/procedures/facelift-technique.jpg" 
                  alt="SMAS Tekniği" 
                  className="rounded-lg shadow-lg w-full object-cover"
                  style={{ maxHeight: "400px" }}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                  }}
                />
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-teal-700">
                  SMAS Tekniği (Deep Plane Facelift)
                </h3>
                <p className="text-gray-700 mb-6">
                  SMAS (Yüzeysel Müsküloponörotik Sistem), yüz ve boyun kaslarını saran doku tabakasıdır. Deep Plane tekniği ile bu tabaka ve üzerindeki cilt birlikte kaldırılır, daha doğal ve uzun süreli sonuçlar elde edilir.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Daha doğal görünüm</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Daha uzun süreli kalıcılık (8-10 yıl)</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Orta ve alt yüz için ideal çözüm</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-teal-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Gizli izler ve minimal iz kalma riski</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/facelift-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    3 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">58 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">SMAS Tekniği ile tam yüz germe uygulaması</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/facelift-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    6 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">62 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Deep Plane tekniği ve boyun germe kombinasyonu</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/facelift-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-teal-600 text-white text-xs px-2 py-1 rounded">
                    1 yıl sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">55 Yaş, Erkek Hasta</h3>
                  <p className="text-gray-600">Erkek yüz anatomisine özel yüz germe ve gıdı liposuction kombinasyonu</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Detayları */}
      <section className="py-16 bg-teal-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="/assets/doctors/dr-ummahan-ozaslan.jpg" 
                    alt="Doç. Dr. Ummahan Özaslan" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-12">
                <h2 className="text-3xl font-bold mb-4 text-gray-900">Doç. Dr. Ummahan Özaslan</h2>
                <h3 className="text-xl text-teal-700 mb-4">Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı</h3>
                <p className="text-gray-700 mb-6">
                  Doç. Dr. Ummahan Özaslan, yüz germe cerrahisi alanında 15 yılı aşkın deneyime sahiptir. 
                  Uluslararası estetik cerrahi derneklerinin aktif üyesi olan Dr. Özaslan, 
                  özellikle doğal sonuçlu yüz gençleştirme teknikleri konusunda uzmanlaşmıştır.
                </p>
                <p className="text-gray-700 mb-6">
                  Yüzlerce başarılı yüz germe operasyonu gerçekleştiren Dr. Özaslan, her hastaya özel yaklaşımı ve
                  güncel teknikleri kullanarak doğal ve uzun süreli sonuçlar elde etmektedir.
                </p>
                <div className="flex space-x-4">
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700 text-white"
                    onClick={redirectToWhatsApp}
                  >
                    Doktor ile İletişime Geç
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Yüz germe operasyonu kalıcı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Yüz germe operasyonu, yaşlanma sürecini durduramamakla birlikte 8-10 yıl kadar kalıcı sonuçlar sağlar. SMAS ve Deep Plane teknikleri gibi modern yaklaşımlar, daha uzun süreli ve doğal sonuçlar elde etmemizi sağlamaktadır. Düzenli cilt bakımı, güneşten korunma ve sağlıklı yaşam tarzı sonuçların kalıcılığını artırır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Operasyon sonrası iyileşme süreci nasıldır?</AccordionTrigger>
                <AccordionContent>
                  Operasyon sonrası ilk 24-48 saat içinde şişlik ve hafif ağrı normaldir. İlk hafta boyunca şişlikler ve morluklar azalmaya başlar. 10-14 gün içinde dikişler alınır ve sosyal hayata dönüş mümkün olur. Tam iyileşme ise 2-3 ay sürer. İyileşme sürecinde doktor kontrollerinin aksatılmaması ve verilen tavsiyelere uyulması çok önemlidir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Yüz germe operasyonunun riskleri nelerdir?</AccordionTrigger>
                <AccordionContent>
                  Her cerrahi işlem gibi yüz germe operasyonunun da bazı riskleri vardır. Bunlar arasında enfeksiyon, kanama, skar oluşumu, geçici sinir hasarı ve asimetri sayılabilir. Ancak uzman bir estetik cerrah tarafından, uygun teknikle yapılan operasyonlarda komplikasyon oranı oldukça düşüktür. Hasta seçimi ve detaylı değerlendirme, riskleri minimize etmede büyük önem taşır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Hangi yaşta yüz germe operasyonu olmak uygundur?</AccordionTrigger>
                <AccordionContent>
                  Yüz germe operasyonu için ideal yaş aralığı genellikle 40-70'tir. Ancak bu kişiden kişiye değişebilir. Önemli olan yaştan ziyade, kişinin yüzündeki yaşlanma belirtilerinin derecesidir. Yüz ve boyun bölgesinde belirgin sarkma, derin kırışıklıklar ve elastikiyet kaybı yaşayan kişiler için uygun bir seçenektir. Genç hastalarda daha az invaziv yöntemleri tercih ediyoruz.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Botoks veya dolgu yerine neden yüz germe tercih edilmelidir?</AccordionTrigger>
                <AccordionContent>
                  Botoks ve dolgu gibi uygulamalar, hafif ve orta dereceli yaşlanma belirtileri için iyi sonuçlar verse de, belirgin cilt sarkması durumunda yetersiz kalır. Yüz germe operasyonu, cilt ve alttaki kas dokusunu yeniden konumlandırdığı için daha dramatik ve uzun süreli sonuçlar sağlar. Ayrıca tek seansta tüm yüz yapısını yeniden şekillendirme imkanı sunar.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Yüz germe operasyonu izleri görünür mü?</AccordionTrigger>
                <AccordionContent>
                  Modern yüz germe tekniklerinde izler genellikle saç içine, kulak arkasına ve kulak kıvrımlarına gizlenir. Bu nedenle günlük hayatta fark edilmez. İzler zamanla soluklaşır ve çoğu hastada 6-12 ay içinde neredeyse görünmez hale gelir. Uygun yara bakımı ve güneşten korunma, izlerin olumlu iyileşmesinde büyük rol oynar.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/mini-facelift-hero.jpg" 
                      alt="Mini Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Mini Yüz Germe</h3>
                      <p className="text-white/80">Daha az invaziv, hızlı iyileşme süreci</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/necklift-hero.jpg" 
                      alt="Boyun Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Boyun Germe</h3>
                      <p className="text-white/80">Gıdı ve boyun sarkmasına çözüm</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/eyelid-hero.jpg" 
                      alt="Göz Kapağı Estetiği" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Göz Kapağı Estetiği</h3>
                      <p className="text-white/80">Yorgun görünümden kurtulun</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-teal-50 text-teal-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Yüz Germe Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="facelift" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}