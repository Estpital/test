import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function LipLiftPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Dudak%20kaldırma%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-pink-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-pink-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-rose-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-pink-600 to-rose-600">
                  Dudak Kaldırma
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Daha Genç ve Dolgun Dudak Görünümü
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde, üst dudak uzunluğunun kısaltılması ve 
                  dudak dolgunluğunun artırılması için uygulanan dudak kaldırma (lip lift) operasyonu. 
                  Yaşlanma ile uzayan üst dudağınızı yeniden şekillendirerek daha genç, çekici ve dengeli bir 
                  dudak-burun oranına kavuşun.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-pink-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/liplift-hero.jpg" 
                        alt="Dudak Kaldırma" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=1976&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Hızlı Sonuç</h3>
                        </div>
                        <p className="text-sm text-gray-600">Şişlikler 10-14 gün içinde iner</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-rose-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Mini İz</h3>
                        </div>
                        <p className="text-sm text-gray-600">Burun altında gizlenir</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-pink-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">45-60 dakika</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Lokal anestezi</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">Gerekmez (günübirlik)</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">7-10 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">3-4 hafta</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-pink-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Üst dudak uzunluğunu kısaltır</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Dudaklara doğal dolgunluk kazandırır</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Dinç ve genç görünüm sağlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Dolgu enjeksiyonuna göre daha kalıcı sonuç</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>İz burun altına gizlenir</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-pink-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yaşa bağlı üst dudak uzaması olan kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Doğuştan uzun üst dudağı olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Gülümsediğinde üst dişleri görünmeyenler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Dolgu enjeksiyonları ile tatmin olmamış kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha dolgun ve genç dudak isteyen herkes</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Dudak Kaldırma Teknikleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-pink-50 text-pink-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DUDAK KALDIRMA TEKNİKLERİ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Lip Lift Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Her yüz yapısına ve ihtiyaca göre özelleştirilen dudak kaldırma teknikleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-pink-700 mb-4">Bullhorn Lip Lift</h3>
                  <p className="text-gray-700 mb-4">
                    Burun tabanı ile üst dudak arasında, burun delikleri altında "boğa boynuzu" 
                    şeklinde bir kesi yapılarak uygulanan en yaygın dudak kaldırma tekniğidir. 
                    Üst dudak kısaltılarak daha dolgun ve genç bir görünüm sağlanır.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Burun altında gizlenen iz</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">En yaygın ve güvenilir teknik</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">2-5 mm dudak kısaltması</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/bullhorn-liplift.jpg" 
                      alt="Bullhorn Lip Lift" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1596451190630-186aff535bf2?q=80&w=1974&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-pink-700 mb-4">İtalyan Lip Lift</h3>
                  <p className="text-gray-700 mb-4">
                    Burun delikleri içerisinden yapılan kesilerle uygulanan, dışarıdan herhangi 
                    bir iz bırakmayan tekniktir. Daha hafif bir kaldırma etkisi sağlar ve 
                    minimal iz tercih edenler için idealdir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Görünür iz bırakmaz</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha hafif düzeltme sağlar</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">1-3 mm dudak kısaltması</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/italian-liplift.jpg" 
                      alt="İtalyan Lip Lift" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1558507334-57300f59f0bd?q=80&w=1974&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-pink-700 mb-4">Dudak Yükseltme Öncesi ve Sonrası Farklar</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Öncesi:</h4>
                    <ul className="space-y-2 mb-4">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span className="text-gray-700">Uzun üst dudak</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span className="text-gray-700">Gülümsemede üst dişlerin görünmemesi</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span className="text-gray-700">İnce ve yaşlı görünen dudaklar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-gray-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span className="text-gray-700">Yorgun ve düşük dudak görünümü</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Sonrası:</h4>
                    <ul className="space-y-2 mb-4">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Kısaltılmış, daha estetik üst dudak</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Gülümsemede üst dişlerin görünmesi</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Daha dolgun ve genç görünen dudaklar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-pink-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Daha canlı ve çekici dudak ifadesi</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-pink-50 text-pink-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/liplift-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1558507334-57300f59f0bd?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-pink-600 text-white text-xs px-2 py-1 rounded">
                    3 hafta sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">38 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Bullhorn tekniği ile dudak kaldırma</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/liplift-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1558507334-57300f59f0bd?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-pink-600 text-white text-xs px-2 py-1 rounded">
                    1 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">42 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">İtalyan tekniği ile dudak kaldırma</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/liplift-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1558507334-57300f59f0bd?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-pink-600 text-white text-xs px-2 py-1 rounded">
                    2 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">35 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Rinoplasti ile kombine dudak kaldırma</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Detayları */}
      <section className="py-16 bg-pink-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="/assets/doctors/dr-ummahan-ozaslan.jpg" 
                    alt="Doç. Dr. Ummahan Özaslan" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-12">
                <h2 className="text-3xl font-bold mb-4 text-gray-900">Doç. Dr. Ummahan Özaslan</h2>
                <h3 className="text-xl text-pink-700 mb-4">Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı</h3>
                <p className="text-gray-700 mb-6">
                  Doç. Dr. Ummahan Özaslan, dudak estetiği ve yüz gençleştirme alanında 15 yılı aşkın deneyime sahiptir. 
                  Uluslararası estetik cerrahi derneklerinin aktif üyesi olan Dr. Özaslan, 
                  özellikle doğal görünümlü dudak şekillendirme teknikleri konusunda uzmanlaşmıştır.
                </p>
                <p className="text-gray-700 mb-6">
                  Yüzlerce başarılı dudak kaldırma operasyonu gerçekleştiren Dr. Özaslan, her hastanın yüz yapısına ve 
                  özelliklerine uygun, doğal ve estetik sonuçlar elde etmek için özel teknikler kullanmaktadır.
                </p>
                <div className="flex space-x-4">
                  <Button 
                    className="bg-pink-600 hover:bg-pink-700 text-white"
                    onClick={redirectToWhatsApp}
                  >
                    Doktor ile İletişime Geç
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-pink-50 text-pink-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Dudak kaldırma (lip lift) operasyonu ağrılı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Dudak kaldırma operasyonu lokal anestezi altında yapıldığı için işlem sırasında ağrı hissedilmez. İşlem sonrası ilk 24-48 saat içinde hafif bir rahatsızlık, gerginlik ve şişlik olabilir, ancak bu genellikle reçete edilen ağrı kesicilerle kolayca kontrol altına alınabilir. Çoğu hasta, beklediğinden daha az ağrı yaşadığını belirtir. İyileşme sürecinde burun altında gerginlik hissi normal olup zamanla azalır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Dudak kaldırma sonrası iz kalır mı?</AccordionTrigger>
                <AccordionContent>
                  Dudak kaldırma operasyonunda kesi genellikle burun altına, burun delikleri tabanına gizlenir. Bu iz başlangıçta pembe-kırmızı olsa da, zamanla soluklaşır ve çoğu hastada 6-12 ay içinde neredeyse görünmez hale gelir. İtalyan lip lift tekniğinde ise kesiler burun delikleri içinden yapıldığı için dışarıdan görülebilir bir iz kalmaz. İyileşme sürecinde güneşten korunmak ve doktorun önerdiği iz bakım kremlerini kullanmak izin iyileşmesini olumlu etkiler.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Dudak kaldırma operasyonu sonuçları kalıcı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Evet, dudak kaldırma operasyonu sonuçları kalıcıdır. Cerrahi olarak çıkarılan cilt dokusu bir daha yerine konamaz. Ancak, yaşlanma süreci devam ettiği için zaman içinde üst dudakta yeniden bir miktar uzama olabilir, bu genellikle 10-15 yıl içinde minimal düzeydedir. Dudak dolgusu gibi geçici çözümlerin aksine, dudak kaldırma operasyonu tek seansta kalıcı sonuç sağlar ve tekrar uygulanması gerekmez.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Dudak kaldırma ve dudak dolgusu arasındaki fark nedir?</AccordionTrigger>
                <AccordionContent>
                  Dudak kaldırma (lip lift) cerrahi bir işlemdir ve üst dudağın uzunluğunu kısaltarak dudakların daha dolgun ve genç görünmesini sağlar. Üst dudak ile burun arası mesafeyi azaltır ve dudaklara doğal bir dolgunluk kazandırır. Sonuçları kalıcıdır. Dudak dolgusu ise dudaklara hyalüronik asit içeren dolgu maddeleri enjekte edilerek hacim kazandıran geçici bir işlemdir. Dolgu enjeksiyonları dudak uzunluğunu değil, yalnızca hacmini artırır ve etkisi genellikle 6-12 ay sürer. Birçok hasta, her iki yöntemi kombine ederek daha kapsamlı sonuçlar elde edebilir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>İyileşme süreci ne kadar sürer? Ne zaman normal aktivitelere dönebilirim?</AccordionTrigger>
                <AccordionContent>
                  Dudak kaldırma operasyonu sonrası ilk 24-48 saat içinde şişlik ve morarma normaldir. İlk hafta boyunca şişlikler ve hafif morluklar azalmaya başlar. Dikişler genellikle 5-7 gün sonra alınır. 7-10 gün içinde sosyal hayata dönülebilir, makyaj yapılabilir. Tam iyileşme ise 3-4 hafta sürer. İlk iki hafta yüksek yastıkta uyumak, buz kompres uygulamak ve ağzınızı çok açmaktan kaçınmak (büyük lokmalar yemek veya çok gülmek) iyileşmeyi hızlandırır. Spor ve ağır fiziksel aktiviteler için 2-3 hafta beklemek önerilir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Dudak kaldırma işlemi için uygun yaş aralığı nedir?</AccordionTrigger>
                <AccordionContent>
                  Dudak kaldırma işlemi için belirli bir yaş sınırı yoktur. Genellikle 30'lu yaşlarda başlayan ve yaşla artan üst dudak uzaması şikayeti olan kişiler için uygundur. Yaşlanmaya bağlı dudak uzaması genellikle 40'lı ve 50'li yaşlarda belirginleşir, ancak bazı kişilerde doğuştan uzun üst dudak olabilir ve bu kişiler daha genç yaşlarda da bu operasyondan faydalanabilir. Üst yaş sınırı ise kişinin genel sağlık durumuna bağlıdır. Sağlık durumu iyi olan 60-70 yaşındaki hastalarda bile güvenle uygulanabilir.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-pink-50 text-pink-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/rhinoplasty-hero.jpg" 
                      alt="Burun Estetiği" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Burun Estetiği</h3>
                      <p className="text-white/80">Yüz oranlarını düzenleme</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/facelift-hero.jpg" 
                      alt="Tam Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Tam Yüz Germe</h3>
                      <p className="text-white/80">Kapsamlı gençleştirme</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/fillers-hero.jpg" 
                      alt="Dudak Dolgusu" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Dudak Dolgusu</h3>
                      <p className="text-white/80">Cerrahi olmayan dolgunlaştırma</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-pink-50 text-pink-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Dudak Kaldırma Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="liplift" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}