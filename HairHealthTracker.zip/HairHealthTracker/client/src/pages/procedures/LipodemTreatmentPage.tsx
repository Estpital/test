import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function LipodemTreatmentPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Lipödem%20tedavisi%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-amber-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-orange-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-amber-600 to-orange-600">
                  Lipödem Tedavisi
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Ağrısız ve Sağlıklı Bir Vücut İçin
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde gerçekleştirilen Vaser Liposuction 
                  tekniği ile lipödem hastalığınızdan kurtulun. Ağrı, şişlik ve hareket kısıtlılığı 
                  gibi yaşam kalitenizi düşüren semptomları azaltarak konforlu bir yaşama kavuşun.
                  Lipödem tedavisi sonrası lenf drenaj tedavileri ile uzun süreli sonuçlar elde edin.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-amber-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/lipodem-hero.jpg" 
                        alt="Lipödem Tedavisi" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1589394815804-964ed0be2eb5?q=80&w=1974&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Tedavi Etkin</h3>
                        </div>
                        <p className="text-sm text-gray-600">Kalıcı sonuçlar</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Minimal İz</h3>
                        </div>
                        <p className="text-sm text-gray-600">Modern cerrahi teknikler</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-amber-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">2-4 saat</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Genel anestezi</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">1 gece</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">10-14 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">2-3 ay</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Kompresyon Kıyafeti</h4>
                        <p className="text-gray-600">4-6 hafta</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-amber-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Ağrı ve hassasiyette azalma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Hareket kabiliyetinde artış</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Vücut oranlarında iyileşme</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Lenf drenajında iyileşme</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yaşam kalitesinde artış</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Psikolojik iyileşme</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-amber-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Klinik olarak lipödem tanısı almış kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Bacak ve kollarda simetrik şişlik yaşayanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Dokunma ile ağrı hissedenler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Diyet ve egzersizle kilo vermesine rağmen belirli bölgelerde incelme olmayanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genel sağlık durumu iyi olanlar</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Lipödem Hastalığı Hakkında */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                LIPÖDEM HAKKINDA
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Lipödem Nedir?
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Lipödem, vücudun bazı bölgelerinde simetrik yağ birikimi ve şişlik ile karakterize edilen kronik bir hastalıktır
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-12">
              <div className="p-6">
                <p className="text-gray-700 mb-6">
                  Lipödem, yanlışlıkla obezite veya lenfödem olarak teşhis edilen, genellikle kadınları etkileyen 
                  kronik bir hastalıktır. Vücudun alt kısmında (bacaklar, kalçalar) ve bazen kollarında anormal ve 
                  simetrik yağ birikimi ile karakterizedir. Bu durum ağrı, hassasiyet ve kolay morarma gibi semptomlar 
                  ile kendini gösterir.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                  <div>
                    <h3 className="text-xl font-bold text-amber-700 mb-4">Belirtileri</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Bacaklarda, kalçalarda ve kollarda simetrik şişlik</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Dokunma ile ağrı ve hassasiyet</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Kolay morarma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">Vücudun üst ve alt kısmı arasında orantısızlık</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700">"Portakal kabuğu" görünümünde cilt dokusu</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold text-amber-700 mb-4">Evreleri</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700"><strong>Evre 1:</strong> Cilt yüzeyi pürüzsüz, deri altında küçük nodüller var</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700"><strong>Evre 2:</strong> Ciltte düzensizlikler, portakal kabuğu görünümü başlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700"><strong>Evre 3:</strong> Belirgin deri katlantıları, bacaklarda büyük çıkıntılar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span className="text-gray-700"><strong>Evre 4:</strong> Lipödem ve lenfödemin birleşimi, şiddetli şişlik</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <p className="text-gray-700">
                  Lipödem genellikle kilo alıp vermekten etkilenmez. Diyet ve egzersizle kilo verilse bile, lipödem 
                  ile etkilenen bölgelerdeki yağ dokusu genellikle aynı kalır. Lipödem sadece fiziksel değil, aynı zamanda 
                  psikolojik etkileri de olan bir hastalıktır. Vücut imajı sorunları, özgüven eksikliği ve sosyal 
                  izolasyon yaygın olarak görülür.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-amber-700 mb-4">Lipödem ve Obezite Arasındaki Farklar</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Özellik</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lipödem</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Obezite</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Dağılım</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Simetrik, genellikle bacaklar ve kollarda</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Tüm vücutta yaygın</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Ağrı</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Genellikle var, dokunmaya hassas</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Genellikle yok</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Diyet Yanıtı</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Etkilenen bölgeler diyet ve egzersize dirençli</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Diyet ve egzersizle kilo verilir</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Morarma</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Kolay morarma eğilimi</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Normal</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Vücut Oranları</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Vücudun üst ve alt kısmı arasında orantısızlık</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Genellikle orantılı</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tedavi Seçenekleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                TEDAVİ YAKLAŞIMIMIZ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Lipödem Tedavi Seçenekleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Lipödem için kapsamlı ve kişiselleştirilmiş tedavi yaklaşımımız
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-amber-700 mb-4">Vaser Liposuction</h3>
                  <p className="text-gray-700 mb-4">
                    Vaser Liposuction tekniği, ultrasonik enerji kullanarak lipödem hastalarındaki anormal yağ
                    dokusunu hedefleyen ileri bir yöntemdir. Geleneksel liposuction'a göre daha hassas
                    ve daha az travmatiktir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Ultrasonik teknoloji ile seçici yağ dokusu çıkarımı</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Kan damarları ve lenf kanallarını koruyarak daha güvenli operasyon</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha az morarma ve şişlik</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha hızlı iyileşme süreci</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/vaser-liposuction.jpg" 
                      alt="Vaser Liposuction" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1551076805-e1869033e561?q=80&w=1932&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-amber-700 mb-4">Manuel Lenf Drenajı (MLD)</h3>
                  <p className="text-gray-700 mb-4">
                    Manuel Lenf Drenajı, özel hafif masaj teknikleri kullanarak lenf sisteminin çalışmasını 
                    iyileştiren terapötik bir yaklaşımdır. Lipödem tedavisinde cerrahi sonrası veya cerrahi olmayan
                    bir tedavi seçeneği olarak kullanılabilir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Sıvı birikmesini azaltır</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Ağrı ve rahatsızlığı hafifletir</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Bağışıklık sistemini destekler</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Haftada 1-2 seans önerilir</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/lymphatic-drainage.jpg" 
                      alt="Manuel Lenf Drenajı" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=1974&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-amber-700 mb-4">Kompresyon Giysileri</h3>
                  <p className="text-gray-700 mb-4">
                    Özel olarak tasarlanmış kompresyon giysileri, lipödem ile etkilenen bölgelere basınç
                    uygulayarak şişliği azaltır ve dolaşımı iyileştirir. Hem cerrahi sonrası hem de
                    konservatif tedavi olarak kullanılır.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Dokuları destekler</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Ağrıyı azaltır</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Günlük kullanım için önerilir</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-amber-700 mb-4">Kilo Yönetimi ve Egzersiz</h3>
                  <p className="text-gray-700 mb-4">
                    Lipödem kilo vermekle düzelmese de, sağlıklı bir kilo ve düzenli
                    egzersiz semptomların yönetiminde önemlidir. Özellikle su içi egzersizler ve düşük 
                    etkili aerobik aktiviteler faydalıdır.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Anti-inflamatuar diyet</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Su içi egzersizler</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-amber-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Yürüyüş ve hafif ağırlık çalışmaları</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/lipodem-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=1740&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-amber-600 text-white text-xs px-2 py-1 rounded">
                    3 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">36 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Evre 2 Lipödem, Bacak ve Kalça Vaser Liposuction</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/lipodem-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=1740&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-amber-600 text-white text-xs px-2 py-1 rounded">
                    6 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">42 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Evre 3 Lipödem, Tam Bacak ve Kol Vaser Liposuction</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/lipodem-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?q=80&w=1740&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-amber-600 text-white text-xs px-2 py-1 rounded">
                    4 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">29 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Evre 2 Lipödem, Kol Vaser Liposuction</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Detayları */}
      <section className="py-16 bg-amber-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="/assets/doctors/dr-ummahan-ozaslan.jpg" 
                    alt="Doç. Dr. Ummahan Özaslan" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-12">
                <h2 className="text-3xl font-bold mb-4 text-gray-900">Doç. Dr. Ummahan Özaslan</h2>
                <h3 className="text-xl text-amber-700 mb-4">Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı</h3>
                <p className="text-gray-700 mb-6">
                  Doç. Dr. Ummahan Özaslan, lipödem tedavisi alanında 15 yılı aşkın deneyime sahiptir. 
                  Uluslararası plastik cerrahi derneklerinin aktif üyesi olan Dr. Özaslan, 
                  özellikle Vaser Liposuction tekniği ile lipödem tedavisinde uzmanlaşmıştır.
                </p>
                <p className="text-gray-700 mb-6">
                  Yüzlerce başarılı lipödem tedavisi gerçekleştiren Dr. Özaslan, her hastanın durumuna
                  özel olarak planlanmış, kapsamlı tedavi programları sunmaktadır. Sadece cerrahi tedavi değil,
                  aynı zamanda lenf drenajı, kompresyon tedavisi ve lifestyle değişikliklerini içeren bütünsel
                  bir yaklaşım benimsemektedir.
                </p>
                <div className="flex space-x-4">
                  <Button 
                    className="bg-amber-600 hover:bg-amber-700 text-white"
                    onClick={redirectToWhatsApp}
                  >
                    Doktor ile İletişime Geç
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Lipödem tedavisi için kimler uygundur?</AccordionTrigger>
                <AccordionContent>
                  Lipödem tedavisi için en uygun adaylar klinik olarak lipödem tanısı almış kişilerdir. Genellikle bacaklarda ve kollarda simetrik yağ birikimi, dokunma ile ağrı, kolay morarma ve diyet/egzersizle gitmeyen şişlik gibi belirtileri olan hastalar tedaviden fayda görebilir. Cerrahi tedavi (Vaser Liposuction) için genel anestezi alabilecek kadar sağlıklı olmak önemlidir. Aktif enfeksiyonu, ciddi kalp veya akciğer hastalığı olanlar, pıhtılaşma bozukluğu olan hastalar veya hamileler için cerrahi tedavi uygun olmayabilir. Her hasta için kişiselleştirilmiş bir değerlendirme yapılması esastır. Konservatif tedaviler (manuel lenf drenajı, kompresyon giysileri) ise daha geniş bir hasta grubuna uygulanabilir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Vaser Liposuction neden geleneksel liposuction'dan daha etkilidir?</AccordionTrigger>
                <AccordionContent>
                  Vaser Liposuction, lipödem tedavisinde geleneksel liposuction'a göre daha etkilidir çünkü ultrasonik enerji kullanarak yağ hücrelerini seçici olarak hedefler. Bu ultrasonik teknoloji, lipödemli dokudaki yağ hücrelerini bir çeşit emülsiyon haline getirerek daha nazik ve daha az travmatik bir şekilde çıkarılmalarını sağlar. Geleneksel liposuction'ın aksine, Vaser teknolojisi kan damarlarına, sinirlere ve lenf kanallarına daha az zarar verir, bu da lipödem hastalarında özellikle önemlidir çünkü bu hastalarda zaten lenf sistemi bozuklukları olabilir. Vaser tekniği, daha az kanama, morarma ve şişlik sağlayarak iyileşme sürecini hızlandırır. Ayrıca, Vaser daha hassas çalışabildiği için, cilt altındaki yağ dokusunun seçici olarak çıkarılmasına ve aynı zamanda cilt tonunun daha düzgün olmasına olanak tanır. Bu, lipödem hastalarında görülen 'portakal kabuğu' görünümünün iyileştirilmesine yardımcı olur.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Lipödem tedavisi sonrası iyileşme süreci nasıldır?</AccordionTrigger>
                <AccordionContent>
                  Lipödem için Vaser Liposuction tedavisi sonrası iyileşme süreci genellikle şu şekildedir: İlk 24-48 saat içinde operasyon bölgesinde şişlik, morarma ve hafif bir rahatsızlık hissi olması normaldir. İlk hafta boyunca özel kompresyon giysileri giymeniz gerekecektir, bu giysiler 4-6 hafta boyunca günün büyük kısmında kullanılmalıdır. Çoğu hasta 1-2 hafta içinde günlük aktivitelerine ve işe dönebilir, ancak ağır fiziksel aktivitelerden 4-6 hafta kaçınmak gerekir. İyileşmeyi hızlandırmak için operasyondan birkaç gün sonra başlayan manuel lenf drenajı seansları önerilir. Tam iyileşme ve nihai sonuçların görülmesi 3-6 ay sürebilir, çünkü şişlik tamamen inmesi ve dokular yeni şekillerine uyum sağlaması zaman alır. İyileşme sürecinde düzenli olarak doktor kontrollerine gitmek, önerilen kompresyon giysilerini kullanmak ve manuel lenf drenajı seanslarına katılmak uzun vadeli sonuçların başarısı için kritik öneme sahiptir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Lipödem tedavisi sonuçları kalıcı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Lipödem tedavisi sonuçları, özellikle Vaser Liposuction ile yapılan cerrahi müdahale, büyük ölçüde kalıcıdır. Çıkarılan yağ hücreleri vücuttan kalıcı olarak uzaklaştırılır ve bu spesifik hücreler geri gelmez. Ancak, lipödem kronik bir hastalık olduğu için, kalan yağ hücreleri zaman içinde büyüyebilir ve semptomlar yeniden ortaya çıkabilir. Sonuçların kalıcılığını maksimize etmek için cerrahi sonrası bakım ve yaşam tarzı değişiklikleri kritik öneme sahiptir. Düzenli manuel lenf drenajı tedavileri, kompresyon giysilerinin kullanımı, sağlıklı beslenme ve uygun egzersiz programı uzun vadeli başarı için önemlidir. Bazı hastalar, yıllar içinde ek tedavi seanslarına ihtiyaç duyabilir, özellikle de daha ileri evrelerdeki lipödem vakaları. Cerrahi sonrası düzenli takip muayeneleri ve semptomların yönetimi için kapsamlı bir yaklaşım, sonuçların uzun ömürlü olmasını sağlar.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Lipödem tedavisi ile ne kadar kilo kaybedilir?</AccordionTrigger>
                <AccordionContent>
                  Lipödem tedavisi, öncelikle kilo kaybı için değil, hastalıkla ilişkili anormal yağ birikimini azaltmak ve semptomları iyileştirmek için yapılır. Vaser Liposuction ile çıkarılan yağ miktarı hastanın durumuna ve etkilenen bölgelerin sayısına ve büyüklüğüne bağlı olarak değişir. Tipik olarak, tek bir seansta 2-5 litre yağ çıkarılabilir, bu da yaklaşık 2-5 kg'a denk gelir. Ancak bu rakam bölgeye ve hastaya göre değişebilir. Önemli olan nokta, lipödem tedavisinin amacının kilogram cinsinden kayıp değil, ağrının azaltılması, hareket kabiliyetinin artırılması ve yaşam kalitesinin iyileştirilmesi olduğudur. Aslında, lipödem hastalarının çoğu, diyet ve egzersizle kilo vermiş olsalar bile etkilenen bölgelerde değişiklik görmediklerini bildirirler. Tedavi sonrası, genel vücut şekli daha orantılı hale gelir ve hastalar genellikle daha küçük kıyafet bedenleri giyebilirler, ancak skala üzerindeki ağırlık dramatik şekilde değişmeyebilir. En büyük değişimler genellikle fiziksel rahatsızlık, ağrı ve hareket kısıtlamalarının azalmasında görülür.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Lipödem tedavisi sonrası kompresyon giysilerine ne kadar süre ihtiyaç vardır?</AccordionTrigger>
                <AccordionContent>
                  Lipödem tedavisi sonrası kompresyon giysilerinin kullanım süresi hastanın özel durumuna ve tedavinin türüne göre değişir, ancak genel bir çerçeve sunabiliriz. Vaser Liposuction sonrası ilk 1-2 gün boyunca 24 saat kompresyon önerilir. Sonraki 4-6 hafta boyunca, kompresyon giysilerinin günde en az 12-23 saat kullanılması tavsiye edilir. Bu süre, iyileşmeyi destekler, şişliği azaltır ve cildin yeni şekline uyum sağlamasına yardımcı olur. İlk 6 hafta sonrasında, hastanın durumuna bağlı olarak kompresyon süresi azaltılabilir, genellikle günde 8-12 saat veya sadece aktivite sırasında kullanım önerilir. Bazı hastalar, özellikle de semptomların devam ettiği durumlarda, uzun vadede de kompresyon giysilerinden fayda görmeye devam ederler. Bu durumlarda, gün içinde veya semptomların kötüleştiği zamanlarda (örneğin uzun süre ayakta kalma veya seyahat sırasında) kompresyon giysileri kullanılabilir. Kompresyon giysilerinin kullanımı, düzenli kontroller sırasında doktor tarafından değerlendirilmeli ve hastanın ihtiyaçlarına göre ayarlanmalıdır.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/vaser-lipo-hero.jpg" 
                      alt="Vaser Liposuction" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Vaser Liposuction</h3>
                      <p className="text-white/80">Vücut şekillendirme</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/tummy-tuck-hero.jpg" 
                      alt="Karın Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Karın Germe</h3>
                      <p className="text-white/80">Düz karın görünümü</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/mommy-makeover-hero.jpg" 
                      alt="Mommy Makeover" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Mommy Makeover</h3>
                      <p className="text-white/80">Doğum sonrası vücut yenileme</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-amber-50 text-amber-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Lipödem Tedavisi Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="lipodem" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}