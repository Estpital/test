import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function MiniFaceLiftPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Mini%20yüz%20germe%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-rose-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-rose-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-orange-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-rose-600 to-orange-600">
                  Mini Yüz Germe
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Daha Az İnvaziv Yöntemle Hızlı İyileşme
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Mini yüz germe, daha sınırlı kesi ve daha kısa iyileşme süresi ile hafif ve orta düzeydeki 
                  yüz sarkmaları için ideal bir çözümdür. Uzman ekibimiz tarafından uygulanan 
                  mini yüz germe ile doğal sonuçlar elde edin, sosyal hayatınıza kısa sürede dönün.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-rose-600 to-orange-600 hover:from-rose-700 hover:to-orange-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-rose-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/mini-facelift-hero.jpg" 
                        alt="Mini Yüz Germe" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-rose-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Hızlı İyileşme</h3>
                        </div>
                        <p className="text-sm text-gray-600">Sadece 7-10 günde</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Minimal İz</h3>
                        </div>
                        <p className="text-sm text-gray-600">Daha küçük kesiler</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-rose-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">2-3 saat</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Lokal anestezi + sedasyon</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">Genellikle gerekmez (Günübirlik)</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">7-10 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">1-2 ay</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-rose-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha kısa operasyon süresi</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha hızlı iyileşme</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha az ağrı ve morarma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genellikle lokal anestezi yeterli</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha küçük kesiler ve minimal iz</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-rose-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>35-55 yaş arası kişiler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Hafif-orta derece yüz sarkması olanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Özellikle alt yüz ve çene hattında sorun yaşayanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha kısa iyileşme süresi isteyenler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-rose-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Tam yüz germe için çok genç, botoks ve dolgular için çok ileri aşamada olanlar</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mini Yüz Germe Teknikleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-rose-50 text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                TEKNİKLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Mini Yüz Germe Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Minimal müdahale ile maksimum sonuç için uygulanan özel teknikler
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex">
                <img 
                  src="/assets/procedures/mini-facelift-technique.jpg" 
                  alt="S-Lift Tekniği" 
                  className="rounded-lg shadow-lg w-full object-cover"
                  style={{ maxHeight: "400px" }}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                  }}
                />
              </div>
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-rose-700">
                  S-Lift ve MACS Lift Teknikleri
                </h3>
                <p className="text-gray-700 mb-6">
                  Mini yüz germe operasyonlarında genellikle S-Lift veya MACS (Minimal Access Cranial Suspension) Lift teknikleri kullanılır. Bu teknikler, daha kısa kesiler ile yüzün alt kısmı ve çene hattına odaklanan, daha az invaziv çözümlerdir.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-rose-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Kulak önünde S şeklinde veya daha kısa kesiler</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-rose-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">SMAS dokusunun özel askılama teknikleri</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-rose-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">Alt yüz ve çene hattına odaklanma</span>
                  </li>
                  <li className="flex items-start">
                    <svg className="w-6 h-6 text-rose-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-gray-700">4-6 yıl kalıcı sonuçlar</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-rose-50 text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/mini-facelift-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs px-2 py-1 rounded">
                    2 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">45 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">S-Lift tekniği ile mini yüz germe uygulaması</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/mini-facelift-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs px-2 py-1 rounded">
                    3 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">50 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">MACS-Lift tekniği ve boyun germe kombinasyonu</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/mini-facelift-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs px-2 py-1 rounded">
                    6 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">42 Yaş, Erkek Hasta</h3>
                  <p className="text-gray-600">Erkek anatomisine özel mini yüz germe</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tam Yüz Germe ile Mini Yüz Germe Karşılaştırması */}
      <section className="py-16 bg-rose-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-white text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                KARŞILAŞTIRMA
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Tam Yüz Germe vs Mini Yüz Germe
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                İhtiyacınıza en uygun tekniği seçmek için karşılaştırma
              </p>
            </div>

            <div className="bg-white rounded-xl overflow-hidden shadow-lg">
              <div className="grid grid-cols-1 md:grid-cols-3">
                <div className="p-6 bg-white">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Karşılaştırma Kriterleri</h3>
                  <ul className="space-y-6">
                    <li className="font-medium text-gray-700">Operasyon Süresi</li>
                    <li className="font-medium text-gray-700">Anestezi Tipi</li>
                    <li className="font-medium text-gray-700">İyileşme Süresi</li>
                    <li className="font-medium text-gray-700">Kalıcılık</li>
                    <li className="font-medium text-gray-700">Etki Alanı</li>
                    <li className="font-medium text-gray-700">İdeal Yaş Grubu</li>
                    <li className="font-medium text-gray-700">İz / Kesi</li>
                  </ul>
                </div>
                
                <div className="p-6 bg-rose-50 border-t md:border-t-0 md:border-l border-gray-200">
                  <h3 className="text-lg font-semibold text-rose-700 mb-4">Mini Yüz Germe</h3>
                  <ul className="space-y-6">
                    <li className="text-gray-700">2-3 saat</li>
                    <li className="text-gray-700">Lokal anestezi + sedasyon</li>
                    <li className="text-gray-700">7-10 gün</li>
                    <li className="text-gray-700">4-6 yıl</li>
                    <li className="text-gray-700">Alt yüz ve çene hattı</li>
                    <li className="text-gray-700">35-55 yaş</li>
                    <li className="text-gray-700">Minimal kesiler (kulak önünde)</li>
                  </ul>
                </div>
                
                <div className="p-6 bg-teal-50 border-t md:border-t-0 md:border-l border-gray-200">
                  <h3 className="text-lg font-semibold text-teal-700 mb-4">Tam Yüz Germe</h3>
                  <ul className="space-y-6">
                    <li className="text-gray-700">4-5 saat</li>
                    <li className="text-gray-700">Genel anestezi</li>
                    <li className="text-gray-700">10-14 gün</li>
                    <li className="text-gray-700">8-10 yıl</li>
                    <li className="text-gray-700">Tüm yüz, boyun ve şakak bölgesi</li>
                    <li className="text-gray-700">40-70 yaş</li>
                    <li className="text-gray-700">Daha uzun kesiler (saç içi, kulak önü ve arkası)</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="mt-8 text-center">
              <Button 
                className="bg-rose-600 hover:bg-rose-700 text-white"
                onClick={() => {
                  const form = document.getElementById('contact-form');
                  if (form) {
                    form.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                Size Uygun Tekniği Öğrenmek İçin Ücretsiz Konsültasyon Alın
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-rose-50 text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Mini yüz germe ile tam yüz germe arasındaki fark nedir?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe, tam yüz germenin daha az invaziv bir versiyonudur. Daha küçük kesiler kullanılır ve genellikle alt yüz ve çene hattına odaklanır. Operasyon süresi daha kısa, iyileşme dönemi daha hızlıdır ve genellikle lokal anestezi altında yapılabilir. Tam yüz germe ise daha kapsamlı bir işlemdir, daha uzun kesiler gerektirir, tüm yüz ve boynu etkiler, genel anestezi altında yapılır ve iyileşme süreci daha uzundur.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Mini yüz germe sonuçları ne kadar sürer?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe sonuçları genellikle 4-6 yıl kadar kalıcıdır. Bu süre kişinin cildi, yaşam tarzı, genetik yapısı, güneşe maruz kalma düzeyi ve yaşlanma hızı gibi faktörlere bağlı olarak değişebilir. Düzenli cilt bakımı, güneş koruması kullanmak ve sağlıklı bir yaşam tarzı sürdürmek sonuçların daha uzun süre kalıcı olmasına yardımcı olur.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>İyileşme süreci nasıldır? İşe ne zaman dönebilirim?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe sonrası ilk 24-48 saat içinde hafif şişlik ve morarma görülebilir. Çoğu hasta 7-10 gün içinde sosyal hayatına ve işine dönebilir. Dikişler genellikle 5-7 gün sonra alınır. Tam iyileşme ise 1-2 ay sürer. İyileşme sürecinde hafif aktivitelere izin verilirken, ağır fiziksel aktivitelerden 2-3 hafta kaçınılmalıdır. Makyaj genellikle dikişler alındıktan sonra yapılabilir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Mini yüz germe ameliyatı izleri görünür mü?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe ameliyatında kesiler stratejik olarak kulak önüne ve bazen saç çizgisine gizlenir. Doğru cerrahi teknik ve uygun yara bakımı ile bu izler genellikle birkaç ay içinde oldukça soluklaşır ve fark edilmesi zorlaşır. İzlerin görünürlüğü kişinin cilt yapısına, iyileşme kapasitesine ve operasyon sonrası bakımına bağlıdır. Güneşten korunma ve doktorunuzun önerdiği kremler, izlerin olumlu iyileşmesinde büyük rol oynar.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Mini yüz germe ağrılı bir işlem midir?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe genellikle lokal anestezi ve sedasyon altında yapıldığı için operasyon sırasında ağrı hissedilmez. Operasyon sonrası ilk 24-48 saat içinde hafif bir rahatsızlık hissi ve gerginlik olabilir, ancak bu genellikle reçete edilen ağrı kesicilerle kolayca kontrol altına alınabilir. Çoğu hasta, mini yüz germeyi tam yüz germeye göre daha az rahatsız edici bir operasyon olarak tanımlar ve ağrının beklentilerinden daha az olduğunu belirtir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Mini yüz germe için ideal yaş nedir?</AccordionTrigger>
                <AccordionContent>
                  Mini yüz germe için ideal yaş genellikle 35-55 arasıdır. Bu yaş grubundaki kişilerde genellikle hafif ile orta derecede cilt sarkması ve elastikiyet kaybı görülür, ancak henüz tam yüz germe gerektirecek kadar ileri düzeyde değildir. Daha genç hastalarda botoks ve dolgular gibi non-invaziv yöntemler tercih edilirken, daha ileri yaşta ve daha belirgin sarkması olan hastalarda tam yüz germe daha uygun olabilir. Kesin uygunluk kişinin cilt durumuna ve beklentilerine göre değişir.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-rose-50 text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/facelift-hero.jpg" 
                      alt="Tam Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Tam Yüz Germe</h3>
                      <p className="text-white/80">Kapsamlı gençleştirme çözümü</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/necklift-hero.jpg" 
                      alt="Boyun Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Boyun Germe</h3>
                      <p className="text-white/80">Gıdı ve boyun sarkmasına çözüm</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/liquid-facelift-hero.jpg" 
                      alt="Sıvı Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Sıvı Yüz Germe</h3>
                      <p className="text-white/80">Dolgu ile cerrahi olmayan gençleştirme</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-rose-50 text-rose-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Mini Yüz Germe Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="mini-facelift" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}