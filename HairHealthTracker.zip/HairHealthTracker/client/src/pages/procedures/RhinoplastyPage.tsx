import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProcedureContactForm from "@/components/ProcedureContactForm";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Link } from "wouter";

export default function RhinoplastyPage() {
  // WhatsApp'a yönlendirme fonksiyonu
  const redirectToWhatsApp = () => {
    window.open("https://wa.me/905441072570?text=Burun%20estetiği%20operasyonu%20hakkında%20bilgi%20almak%20istiyorum", "_blank");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-50">
      {/* Hero Section */}
      <section className="pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        {/* Dekoratif arka plan öğeleri */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-purple-100 rounded-full opacity-50 blur-3xl"></div>
        <div className="absolute top-1/2 -left-24 w-72 h-72 bg-indigo-100 rounded-full opacity-40 blur-3xl"></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 md:pr-12">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
                  Burun Estetiği
                </h1>
                <h2 className="text-2xl md:text-3xl font-light text-gray-700 mb-6">
                  Doğal ve Harmonik Görünüm
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Uzman doktorumuz Doç. Dr. Ummahan Özaslan yönetiminde uygulanan rinoplasti operasyonları ile 
                  hem estetik görünümünüzü iyileştirin hem de nefes alma problemlerinizi çözün. 
                  Burun yapınızın yüzünüzle uyumlu ve doğal görünmesini sağlarken, fonksiyonel sorunları da ortadan kaldırıyoruz.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button 
                    className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300"
                    onClick={() => {
                      const form = document.getElementById('contact-form');
                      if (form) {
                        form.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                  >
                    Ücretsiz Konsültasyon Alın
                  </Button>
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 text-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center"
                    onClick={redirectToWhatsApp}
                  >
                    <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                    </svg>
                    WhatsApp ile İletişim
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-12 md:mt-0">
                <div className="relative">
                  <div className="absolute inset-0 bg-purple-200 rounded-full opacity-20 blur-3xl transform -translate-x-10 translate-y-10"></div>
                  <div className="relative z-10 flex flex-col">
                    <div className="flex justify-center items-center bg-white rounded-lg shadow-xl p-1 mb-4">
                      <img 
                        src="/assets/procedures/rhinoplasty-hero.jpg" 
                        alt="Burun Estetiği" 
                        className="rounded-lg w-full h-auto"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://images.unsplash.com/photo-1523263685509-57c1d050d19b?q=80&w=1450&auto=format&fit=crop";
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Doğal Sonuçlar</h3>
                        </div>
                        <p className="text-sm text-gray-600">Yüzünüzle uyumlu tasarım</p>
                      </div>
                      <div className="bg-white rounded-lg shadow-md p-3">
                        <div className="flex items-center mb-2">
                          <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                            <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                          </div>
                          <h3 className="font-medium text-gray-900">Çift Fayda</h3>
                        </div>
                        <p className="text-sm text-gray-600">Estetik ve fonksiyonel</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Detaylı Bilgi Kartı */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto mb-16">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Operasyon Bilgileri */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-purple-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                      </svg>
                      Operasyon Bilgileri
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium text-gray-700">Operasyon Süresi</h4>
                        <p className="text-gray-600">2-3 saat</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Anestezi</h4>
                        <p className="text-gray-600">Genel anestezi</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Hastanede Kalış</h4>
                        <p className="text-gray-600">1 gece</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">İş/Sosyal Hayata Dönüş</h4>
                        <p className="text-gray-600">10-14 gün</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-700">Tam İyileşme</h4>
                        <p className="text-gray-600">6-12 ay</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Avantajlar */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-purple-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      Avantajları
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Yüz hatlarınızla uyumlu burun yapısı</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Daha kolay ve rahat nefes alma</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Özgüven artışı</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Kalıcı sonuçlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genç ve dinamik görünüm</span>
                      </li>
                    </ul>
                  </div>
                  
                  {/* İdeal Aday */}
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-purple-700 flex items-center">
                      <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                      </svg>
                      İdeal Aday
                    </h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Burun görünümünden memnun olmayanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Nefes alma sorunları yaşayanlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Burun travması/kırığı geçirenler</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>18 yaş üstü, kemik gelişimi tamamlananlar</span>
                      </li>
                      <li className="flex items-start">
                        <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                        </svg>
                        <span>Genel sağlık durumu iyi olanlar</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Burun Estetiği Teknikleri */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                RİNOPLASTİ TEKNİKLERİ
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Burun Estetiği Teknikleri
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Her yüz yapısına ve ihtiyaca göre özelleştirilen burun estetiği teknikleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-purple-700 mb-4">Açık Teknik Rinoplasti</h3>
                  <p className="text-gray-700 mb-4">
                    Burun deliklerini ayıran kıkırdak (kolumella) üzerinden küçük bir kesi yapılarak 
                    burnun iç yapısına daha geniş bir erişim sağlanan tekniktir. Karmaşık burun sorunlarında 
                    ve ikincil (revizyon) rinoplastilerde tercih edilir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Karmaşık yapısal değişimler için ideal</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Detaylı şekillendirme imkanı</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Minimâl ve zamanla kaybolabilen iz</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/open-rhinoplasty.jpg" 
                      alt="Açık Teknik Rinoplasti" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1515377905703-c4788e51af15?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-purple-700 mb-4">Kapalı Teknik Rinoplasti</h3>
                  <p className="text-gray-700 mb-4">
                    Tüm kesilerin burun içinden yapıldığı, dışarıdan görünür iz bırakmayan tekniktir. 
                    Daha az şişlik ve daha hızlı iyileşme sağlayan bu yöntem, basit burun sorunları için 
                    idealdir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Dışarıdan görünür iz bırakmaz</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha hızlı iyileşme süreci</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Daha az travma ve şişlik</span>
                    </li>
                  </ul>
                  <div className="flex justify-end">
                    <img 
                      src="/assets/procedures/closed-rhinoplasty.jpg" 
                      alt="Kapalı Teknik Rinoplasti" 
                      className="w-32 h-32 object-cover rounded-lg shadow-md"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1560331470-4737edb84771?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-purple-700 mb-4">Yapısal Rinoplasti</h3>
                  <p className="text-gray-700 mb-4">
                    Burnun doğal yapısını koruyarak ve destekleyerek şekillendiren, 
                    uzun vadeli sonuçlar ve daha doğal görünüm sağlayan modern bir tekniktir.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Doğal görünüm</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Uzun vadeli stabilite</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Fonksiyonel sorunları da çözer</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-bold text-purple-700 mb-4">Etnik Rinoplasti</h3>
                  <p className="text-gray-700 mb-4">
                    Farklı etnik grupların kendine özgü burun yapısını ve özelliklerini koruyarak, 
                    kültürel kimliği muhafaza eden ancak estetik görünümü iyileştiren özel bir yaklaşımdır.
                  </p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Etnik özellikleri korur</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Kültürel kimliğe saygılı</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="w-5 h-5 text-purple-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Kişiselleştirilmiş sonuçlar</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Önce / Sonra Görselleri */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SONUÇLAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Öncesi ve Sonrası
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Hastalarımızın rızası ile paylaşılan gerçek öncesi ve sonrası görselleri
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/rhinoplasty-before-after-1.jpg" 
                    alt="Hasta 1 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-purple-600 text-white text-xs px-2 py-1 rounded">
                    6 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">28 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Açık teknik ile kemer düzeltme ve uç incelme</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/rhinoplasty-before-after-2.jpg" 
                    alt="Hasta 2 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-purple-600 text-white text-xs px-2 py-1 rounded">
                    1 yıl sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">35 Yaş, Erkek Hasta</h3>
                  <p className="text-gray-600">Kapalı teknik ile kemer düzeltme ve burun deliği küçültme</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="relative">
                  <img 
                    src="/assets/results/rhinoplasty-before-after-3.jpg" 
                    alt="Hasta 3 - Önce/Sonra" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?q=80&w=1974&auto=format&fit=crop";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-purple-600 text-white text-xs px-2 py-1 rounded">
                    8 ay sonra
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">24 Yaş, Kadın Hasta</h3>
                  <p className="text-gray-600">Yapısal rinoplasti ile fonksiyonel ve estetik düzeltme</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Doktor Detayları */}
      <section className="py-16 bg-purple-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/3 mb-8 md:mb-0">
                <div className="rounded-lg overflow-hidden shadow-xl">
                  <img 
                    src="/assets/doctors/dr-ummahan-ozaslan.jpg" 
                    alt="Doç. Dr. Ummahan Özaslan" 
                    className="w-full h-auto"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1470&auto=format&fit=crop";
                    }}
                  />
                </div>
              </div>
              <div className="md:w-2/3 md:pl-12">
                <h2 className="text-3xl font-bold mb-4 text-gray-900">Doç. Dr. Ummahan Özaslan</h2>
                <h3 className="text-xl text-purple-700 mb-4">Plastik, Rekonstrüktif ve Estetik Cerrahi Uzmanı</h3>
                <p className="text-gray-700 mb-6">
                  Doç. Dr. Ummahan Özaslan, burun estetiği alanında 15 yılı aşkın deneyime sahiptir. 
                  Uluslararası plastik cerrahi derneklerinin aktif üyesi olan Dr. Özaslan, 
                  özellikle fonksiyonel ve estetik burun cerrahisinde uzmandır.
                </p>
                <p className="text-gray-700 mb-6">
                  Yüzlerce başarılı rinoplasti operasyonu gerçekleştiren Dr. Özaslan, her hastanın yüz yapısına 
                  ve beklentilerine uygun, doğal ve fonksiyonel sonuçlar elde etmek için kişiselleştirilmiş 
                  teknikler kullanmaktadır.
                </p>
                <div className="flex space-x-4">
                  <Button 
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                    onClick={redirectToWhatsApp}
                  >
                    Doktor ile İletişime Geç
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sıkça Sorulan Sorular */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                SIKÇA SORULAN SORULAR
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Merak Edilenler
              </h2>
            </div>

            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>Burun estetiği (rinoplasti) ameliyatı ağrılı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Burun estetiği ameliyatı genel anestezi altında yapıldığı için ameliyat sırasında herhangi bir ağrı hissedilmez. Ameliyat sonrası ilk 24-48 saat içinde hafif bir rahatsızlık, dolgunluk hissi ve baş ağrısı olabilir, ancak bu genellikle reçete edilen ağrı kesicilerle kolayca kontrol altına alınabilir. Çoğu hasta, beklediklerinden daha az ağrı yaşadıklarını belirtir. Aslında, burun estetiği sonrası rahatsızlık genellikle ağrıdan çok burun tıkanıklığı ve alçı/tampon nedeniyle nefes almada zorluk şeklinde hissedilir. Tamponlar genellikle 24-48 saat sonra, alçı ise 7-10 gün sonra çıkarılır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger>Burun estetiği sonrası iyileşme süreci nasıldır?</AccordionTrigger>
                <AccordionContent>
                  Burun estetiği sonrası iyileşme süreci genellikle şu şekilde ilerler: İlk 24-48 saat içinde burun içinde tamponlar bulunabilir ve bu süreçte ağızdan nefes almanız gerekebilir. 7-10 gün boyunca burun üzerinde alçı veya splint bulunur ve bu süre zarfında yüzde şişlik ve morluklar görülebilir. Alçı çıkarıldıktan sonra sosyal ortamlara dönüş mümkündür, ancak şişlikler birkaç hafta daha devam edebilir. İlk 6-8 hafta boyunca burna darbe gelmesinden kaçınmalı ve ağır fiziksel aktivitelerden uzak durmalısınız. Şişliklerin büyük kısmı 3-4 ay içinde geçer, ancak burnun nihai şeklini alması 1 yıla kadar sürebilir. Bu süreçte düzenli kontroller yapılacak ve doktorunuz tarafından özel bakım önerileri sunulacaktır.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3">
                <AccordionTrigger>Burun estetiği sonuçları kalıcı mıdır?</AccordionTrigger>
                <AccordionContent>
                  Evet, burun estetiği sonuçları kalıcıdır. Ancak, burunun nihai şeklini alması için yaklaşık 1 yıl gerekmektedir çünkü şişlikler tamamen inmesi ve dokular yeni şekline uyum sağlaması zaman alır. Yaşlanma süreciyle birlikte burunda küçük değişiklikler olabilir, ancak bu estetik operasyonla elde edilen sonucu önemli ölçüde etkilemez. Dikkat edilmesi gereken bir nokta, ameliyat sonrası travma veya yaralanmalardan korunmaktır, çünkü bunlar burun yapısına zarar verebilir. Bazı durumlarda, özellikle karmaşık vakalarda veya ilk ameliyattan memnun kalınmadığında revizyon rinoplastisi gerekebilir. Bu nedenle, deneyimli bir cerrah seçmek ve gerçekçi beklentilere sahip olmak önemlidir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-4">
                <AccordionTrigger>Burun estetiği ve septoplasti arasındaki fark nedir?</AccordionTrigger>
                <AccordionContent>
                  Burun estetiği (rinoplasti) ve septoplasti birbirinden farklı ama bazen birlikte uygulanan cerrahi işlemlerdir. Rinoplasti, burnun dış görünümünü değiştirmeye odaklanan estetik bir ameliyattır. Burun boyutu, şekli, eğriliği, uç yapısı ve burun delikleri gibi özellikleri değiştirerek yüz harmonisini iyileştirmeyi amaçlar. Septoplasti ise burun içindeki kıkırdak ve kemik bölmeyi (septum) düzeltmeye odaklanan fonksiyonel bir ameliyattır. Eğri septum nefes almayı zorlaştırabilir, horlama, uyku apnesi ve sürekli sinüs enfeksiyonlarına yol açabilir. Birçok hasta hem estetik hem de fonksiyonel sorunlar yaşadığından, septoplasti ve rinoplasti genellikle "septorinonplasti" adı verilen tek bir operasyonda birleştirilir. Bu kombinasyon, hem görünümü iyileştirir hem de nefes alma sorunlarını çözer.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-5">
                <AccordionTrigger>Burun estetiği için ideal yaş nedir?</AccordionTrigger>
                <AccordionContent>
                  Burun estetiği için ideal yaş, kişinin fiziksel ve duygusal olgunluğuna bağlıdır. Genel olarak, burun estetiği için kadınlarda 15-16 yaş, erkeklerde 16-17 yaş alt sınır olarak kabul edilir. Bu yaşlar, burun dahil yüz kemiklerinin büyümesinin çoğunlukla tamamlandığı dönemlerdir. Ancak her birey farklı hızda geliştiği için, cerrahın değerlendirmesi önemlidir. Yetişkinler için üst yaş sınırı yoktur; sağlık durumu iyi olan her yaştan yetişkin burun estetiği yaptırabilir. Özellikle nefes alma sorunları yaşayan yaşlı hastalar da fonksiyonel rinoplastiden faydalanabilir. Sadece fiziksel olgunluk değil, duygusal olgunluk da önemlidir. Hasta, operasyonun riskleri, sınırlamaları ve gerçekçi sonuçları hakkında bilgilendirilmiş bir karar verebilmelidir.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-6">
                <AccordionTrigger>Burun estetiği öncesinde nelere dikkat edilmelidir?</AccordionTrigger>
                <AccordionContent>
                  Burun estetiği öncesinde şunlara dikkat edilmelidir: Ameliyattan en az 2 hafta önce sigara ve alkol kullanımını bırakmalısınız çünkü bunlar iyileşmeyi geciktirir ve komplikasyon riskini artırır. Aspirin, ibuprofen gibi kan sulandırıcı ilaçları ve bazı bitkisel takviyeleri (sarımsak, ginkgo biloba, yeşil çay vb.) doktorunuzun önerdiği süre boyunca kullanmayı bırakmalısınız. Ameliyat gününde makyaj yapmamak, oje sürmemek ve takı takmamak gerekir. Ameliyat sonrası ilk günlerde yüksek yastıkta yatmanız gerektiğinden, evinizde gerekli düzenlemeleri yapın. Ameliyat sonrası birkaç gün sizinle ilgilenecek bir refakatçi ayarlayın. Doktorunuzun önerdiği tüm tahlilleri yaptırın ve sonuçları zamanında teslim edin. Son olarak, ameliyat öncesi tüm sorularınızı doktorunuza sorun ve beklentilerinizi gerçekçi bir şekilde belirleyin.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </section>

      {/* İlgili İşlemler */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                DİĞER İŞLEMLER
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                İlgilenebileceğiniz Diğer İşlemler
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/facelift-hero.jpg" 
                      alt="Yüz Germe" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Yüz Germe</h3>
                      <p className="text-white/80">Kapsamlı gençleştirme</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/blepharoplasty-hero.jpg" 
                      alt="Göz Kapağı Estetiği" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Göz Kapağı Estetiği</h3>
                      <p className="text-white/80">Genç ve dinlenmiş bakış</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="block group">
                <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 group-hover:-translate-y-2">
                  <div className="relative h-64">
                    <img 
                      src="/assets/procedures/liplift-hero.jpg" 
                      alt="Dudak Kaldırma" 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = "https://images.unsplash.com/photo-1513690277738-c9bc7eb2a992?q=80&w=1470&auto=format&fit=crop";
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">Dudak Kaldırma</h3>
                      <p className="text-white/80">Daha dolgun ve genç dudaklar</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* İletişim Formu */}
      <section id="contact-form" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <div className="inline-block bg-purple-50 text-purple-700 px-4 py-1 rounded-full font-medium text-sm mb-3">
                ÜCRETSİZ KONSÜLTASYON
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Burun Estetiği Hakkında Bilgi Alın
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mt-4">
                Uzmanlarımız sizinle iletişime geçerek sorularınızı yanıtlasın
              </p>
            </div>

            <ProcedureContactForm defaultProcedure="rhinoplasty" className="shadow-xl" />
          </div>
        </div>
      </section>
    </div>
  );
}