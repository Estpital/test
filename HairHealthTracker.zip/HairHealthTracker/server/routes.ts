import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertHairAnalysisSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import Stripe from "stripe";

// Stripe yapılandırması
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api
  
  // Stripe Ödeme İşlemi Endpointi
  app.post("/api/create-payment-intent", async (req: Request, res: Response) => {
    try {
      const { amount, items } = req.body;

      if (!amount || amount <= 0 || !items || !Array.isArray(items)) {
        return res.status(400).json({ message: "Geçersiz sepet bilgisi" });
      }

      // Kargo ücretini ekle (1000 TL üzeri alışverişlerde ücretsiz kargo)
      const shippingFee = amount >= 1000 ? 0 : 35;
      const totalAmount = amount + shippingFee;

      // Ödeme niyeti oluştur
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(totalAmount * 100), // Kuruş cinsinden (TL * 100)
        currency: "try",
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          order_items: JSON.stringify(items.map((item: any) => ({
            id: item.id,
            name: item.name,
            quantity: item.quantity,
            price: item.price,
          }))),
        },
      });

      res.json({
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error: any) {
      console.error("Ödeme niyeti oluşturma hatası:", error);
      res.status(500).json({
        message: error.message || "Ödeme işlemi başlatılırken bir hata oluştu",
      });
    }
  });

  // Hair Analysis submission endpoint
  app.post("/api/hair-analysis", async (req: Request, res: Response) => {
    try {
      // Validate the request body
      const validatedData = insertHairAnalysisSchema.parse(req.body);
      
      // Create the hair analysis in storage
      const analysis = await storage.createHairAnalysis(validatedData);
      
      // Return the analysis ID for future reference
      res.status(201).json({ 
        id: analysis.id,
        message: "Hair analysis submitted successfully", 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        console.error("Error submitting hair analysis:", error);
        res.status(500).json({ message: "Failed to submit hair analysis" });
      }
    }
  });
  
  // Get analysis results by ID
  app.get("/api/hair-analysis/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid analysis ID" });
      }
      
      const analysis = await storage.getHairAnalysisById(id);
      if (!analysis) {
        return res.status(404).json({ message: "Analysis not found" });
      }
      
      res.json(analysis);
    } catch (error) {
      console.error("Error fetching analysis:", error);
      res.status(500).json({ message: "Failed to fetch analysis results" });
    }
  });
  
  // Get analysis results by email (could be used for returning customers)
  app.get("/api/hair-analysis/email/:email", async (req: Request, res: Response) => {
    try {
      const email = req.params.email;
      const analyses = await storage.getHairAnalysisByEmail(email);
      
      res.json(analyses);
    } catch (error) {
      console.error("Error fetching analyses by email:", error);
      res.status(500).json({ message: "Failed to fetch analysis results" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
