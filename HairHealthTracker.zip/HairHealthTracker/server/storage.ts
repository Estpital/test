import { users, type User, type InsertUser, hairAnalysis, type HairAnalysis, type InsertHairAnalysis } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Hair Analysis Methods
  createHairAnalysis(analysis: InsertHairAnalysis): Promise<HairAnalysis>;
  getHairAnalysisById(id: number): Promise<HairAnalysis | undefined>;
  getHairAnalysisByEmail(email: string): Promise<HairAnalysis[]>;
  generateRecommendations(analysisId: number): Promise<HairAnalysis>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private hairAnalyses: Map<number, HairAnalysis>;
  currentUserId: number;
  currentAnalysisId: number;

  constructor() {
    this.users = new Map();
    this.hairAnalyses = new Map();
    this.currentUserId = 1;
    this.currentAnalysisId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async createHairAnalysis(analysis: InsertHairAnalysis): Promise<HairAnalysis> {
    const id = this.currentAnalysisId++;
    
    // Ensure phone is never undefined (make it null instead)
    const phone = analysis.phone === undefined ? null : analysis.phone;
    
    // Create a valid HairAnalysis object with all required fields explicitly set
    const newAnalysis: HairAnalysis = {
      id,
      age: analysis.age,
      gender: analysis.gender,
      hairLoss: analysis.hairLoss,
      hairLossTime: analysis.hairLossTime,
      pattern: analysis.pattern,
      familyHistory: analysis.familyHistory,
      scalpCondition: analysis.scalpCondition,
      scalpIssues: analysis.scalpIssues,
      washFrequency: analysis.washFrequency,
      stressLevel: analysis.stressLevel,
      healthConditions: analysis.healthConditions,
      weightChanges: analysis.weightChanges,
      firstName: analysis.firstName,
      lastName: analysis.lastName,
      email: analysis.email,
      phone: phone,
      country: analysis.country,
      marketingConsent: analysis.marketingConsent === undefined ? false : analysis.marketingConsent,
      photoUrls: analysis.photoUrls || null,
      recommendedTreatments: null,
      analysisResults: null,
      createdAt: analysis.createdAt || new Date().toISOString()
    };
    this.hairAnalyses.set(id, newAnalysis);
    
    // Generate recommendations right away
    return this.generateRecommendations(id);
  }
  
  async getHairAnalysisById(id: number): Promise<HairAnalysis | undefined> {
    return this.hairAnalyses.get(id);
  }
  
  async getHairAnalysisByEmail(email: string): Promise<HairAnalysis[]> {
    return Array.from(this.hairAnalyses.values()).filter(
      (analysis) => analysis.email === email,
    );
  }
  
  async generateRecommendations(analysisId: number): Promise<HairAnalysis> {
    const analysis = this.hairAnalyses.get(analysisId);
    if (!analysis) {
      throw new Error("Analysis not found");
    }
    
    // Generate recommendations based on the analysis data
    const updatedAnalysis: HairAnalysis = { 
      ...analysis,
      recommendedTreatments: this.getRecommendedTreatments(analysis),
      analysisResults: this.getAnalysisResults(analysis)
    };
    
    this.hairAnalyses.set(analysisId, updatedAnalysis);
    return updatedAnalysis;
  }
  
  private getRecommendedTreatments(analysis: HairAnalysis): any {
    // This would contain logic to determine the best treatments based on the analysis
    // For now, we're returning a simplified version
    const treatments = [
      {
        id: 1,
        name: "FUE Hair Transplantation",
        description: "A minimally invasive procedure to restore hair density in thinning areas. Our advanced techniques ensure natural-looking results with minimal recovery time.",
        imageUrl: "https://images.unsplash.com/photo-1562004760-aceed7bb0fe3?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
      },
      {
        id: 2,
        name: "PRP Therapy",
        description: "PRP (Platelet-Rich Plasma) therapy uses your body's natural growth factors to stimulate hair follicles, improve blood supply to the scalp, and enhance hair thickness.",
        imageUrl: "https://pixabay.com/get/g5e0820bc14ece697d75718ad2c5e9370041c5709e757db3c9cbd1719347409727933734980f4b25eea773ca5401f8b43d563993a24109c73a816b14df25bc788_1280.jpg"
      }
    ];
    
    // Add additional treatments based on specific conditions
    if (analysis.scalpCondition === "dry" || analysis.scalpIssues.includes("dandruff")) {
      treatments.push({
        id: 3,
        name: "Scalp Health Therapy",
        description: "Specialized treatments to improve scalp health, reduce inflammation, and create an optimal environment for hair growth.",
        imageUrl: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
      });
    }
    
    if (analysis.stressLevel === "high" || analysis.stressLevel === "severe") {
      treatments.push({
        id: 4,
        name: "Medical Hair Therapy",
        description: "Our specialized medical treatments include FDA-approved medications, custom formulated topical solutions, and advanced hair growth stimulants.",
        imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
      });
    }
    
    return treatments;
  }
  
  private getAnalysisResults(analysis: HairAnalysis): any {
    // Generate an analysis based on the user's responses
    let pattern = "Unknown";
    let factors = [];
    let progression = "Unknown";
    
    // Determine hair loss pattern
    if (analysis.pattern === "receding") {
      pattern = "Androgenetic alopecia with receding hairline";
    } else if (analysis.pattern === "crown") {
      pattern = "Androgenetic alopecia with crown thinning";
    } else if (analysis.pattern === "overall") {
      pattern = "Diffuse thinning throughout the scalp";
    } else if (analysis.pattern === "widening") {
      pattern = "Female pattern hair loss with widening part line";
    } else if (analysis.pattern === "edges") {
      pattern = "Traction alopecia affecting the hairline/edges";
    } else if (analysis.pattern === "patchy") {
      pattern = "Patchy hair loss, possibly alopecia areata";
    }
    
    // Determine contributing factors
    if (analysis.familyHistory === "father" || analysis.familyHistory === "mother" || analysis.familyHistory === "both") {
      factors.push("Genetic predisposition (family history)");
    }
    
    if (analysis.gender === "male" && (analysis.pattern === "receding" || analysis.pattern === "crown")) {
      factors.push("Hormonal factors (DHT sensitivity)");
    }
    
    if (analysis.scalpCondition !== "normal") {
      factors.push(`Scalp condition (${analysis.scalpCondition})`);
    }
    
    if (analysis.stressLevel === "high" || analysis.stressLevel === "severe") {
      factors.push(`Lifestyle factors (${analysis.stressLevel} stress levels)`);
    }
    
    if (analysis.healthConditions.includes("thyroid") || analysis.healthConditions.includes("hormonal")) {
      factors.push("Medical conditions (hormonal imbalance)");
    }
    
    // Determine progression
    if (analysis.hairLossTime === "less-than-6-months") {
      progression = "Your hair loss is in an early stage with excellent potential for improvement with proper treatment.";
    } else if (analysis.hairLossTime === "6-months-to-1-year") {
      progression = "Your hair loss is in an early to moderate stage with good potential for improvement with proper treatment.";
    } else if (analysis.hairLossTime === "1-3-years") {
      progression = "Your hair loss is in a moderate stage with potential for improvement with proper treatment.";
    } else if (analysis.hairLossTime === "more-than-3-years") {
      progression = "Your hair loss is in an advanced stage. While treatment can help, you may need more comprehensive solutions like hair transplantation.";
    }
    
    return {
      pattern,
      factors,
      progression
    };
  }
}

export const storage = new MemStorage();
