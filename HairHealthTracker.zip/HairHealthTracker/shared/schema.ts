import { pgTable, text, serial, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Hair Analysis Schemas

export const hairAnalysis = pgTable("hair_analysis", {
  id: serial("id").primaryKey(),
  // Basic Info
  age: text("age").notNull(),
  gender: text("gender").notNull(),
  hairLoss: text("hair_loss").notNull(),
  hairLossTime: text("hair_loss_time").notNull(),
  
  // Hair Loss Pattern
  pattern: text("pattern").notNull(),
  familyHistory: text("family_history").notNull(),
  
  // Hair & Scalp Condition
  scalpCondition: text("scalp_condition").notNull(),
  scalpIssues: text("scalp_issues").notNull(),
  washFrequency: text("wash_frequency").notNull(),
  
  // Lifestyle & Health
  stressLevel: text("stress_level").notNull(),
  healthConditions: text("health_conditions").notNull(),
  weightChanges: text("weight_changes").notNull(),
  
  // Contact Info
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  country: text("country").notNull(),
  marketingConsent: boolean("marketing_consent").default(false),
  
  // Uploaded photo paths (stored as JSON)
  photoUrls: json("photo_urls"),
  
  // Results
  recommendedTreatments: json("recommended_treatments"),
  analysisResults: json("analysis_results"),
  
  // Timestamp
  createdAt: text("created_at").notNull().default(new Date().toISOString()),
});

export const insertHairAnalysisSchema = createInsertSchema(hairAnalysis).omit({
  id: true,
  recommendedTreatments: true,
  analysisResults: true,
});

export type InsertHairAnalysis = z.infer<typeof insertHairAnalysisSchema>;
export type HairAnalysis = typeof hairAnalysis.$inferSelect;
